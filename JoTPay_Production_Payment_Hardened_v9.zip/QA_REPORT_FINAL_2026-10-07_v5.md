# JoTPay Production QA — v5

## Scope
- Added a system-level "الكل" category to every primary section: top-up, cards/subscriptions, followers, accounts.
- "الكل" is display/filter-only and cannot be assigned as a product category.
- Top-up package cards remain strictly scoped to `sectionId=top-up`.
- Top-up publishing requires exactly 7 packages.
- Cards/subscriptions are single-product purchases with no quantity field; customer input is optional and configurable as Username, ID, Number/phone, Email, or none.
- Followers retain quantity-based purchasing and the global +30% quantity bonus.
- Account products are single-product purchases with no quantity field; customer target is optional unless explicitly configured by the admin.
- Currency defaults/normalization use `$` instead of `USD` in product publishing and account listing submission.
- No demo/mock runtime data was added.

## Automated checks
- `node --check` passed for every JavaScript file.
- `node --check` passed for every Netlify `.mjs` function.
- No `تصفح المزيد` / `browseMore` references remain in runtime source.
- Source file count remains 41.
- ZIP archive integrity checked after packaging.
