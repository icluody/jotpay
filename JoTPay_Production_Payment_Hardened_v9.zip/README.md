# JoTPay — Final Production Build

منصة JoTPay جاهزة للنشر على Netlify مع Firebase/Firestore للمصادقة والبيانات، وCloudinary للصور، وواجهة RTL متعددة اللغات.

## الأقسام النهائية
1. شحن عملات
2. بطاقات واشتراكات
3. شراء متابعين
4. شراء حسابات

## أهم ما تم إصلاحه في هذه النسخة
- توحيد اللغة على الصفحة الرئيسية وصفحات الخدمات والطلبات والمحفظة والحساب والدعم وعرض الحساب وتسجيل الدخول.
- إضافة إعدادات اللغة والمظهر إلى الصفحات الداخلية أيضًا، مع إعادة تحميل آمنة بعد تغيير اللغة لضمان إعادة بناء النصوص الديناميكية.
- إصلاح النصوص الثابتة التي كانت تبقى بالعربية عند تغيير اللغة.
- توحيد حد حساب التاجر إلى 650$ في الواجهة والخادم وقواعد Firestore.
- منع الخصم المكرر الناتج عن الضغط المتكرر على زر الشراء باستخدام idempotency key.
- جعل شراء بطاقات الشحن يعتمد على باقات المنتج المخزنة في Firestore فقط.
- فرض وجود 7 باقات شحن كاملة للخدمات من نوع شحن العملات على الخادم.
- التحقق الخادمي من سعر الباقة والكمية الأساسية ونسبة الزيادة.
- عرض الكمية النهائية بعد المكافأة مع شريط زيادة نظيف.
- إصلاح مسار شراء المنتج ومسار بطاقات الشحن وإدخال المعرف/اسم المستخدم.
- إضافة شراء التاجر المخصص بحد أدنى 650$ وزيادة 20% مع إعادة التحقق على الخادم.
- منع إعادة استخدام TX Hash نفسه في طلبات USDT-TRC20.
- جعل الحظر المؤقت المنتهي لا يمنع المستخدم بعد انتهاء مدته في مسارات الشراء والشحن.
- جعل مكافأة أول تمويل تعتمد على حالة بانر المكافأة المنشور ونسبته.
- حماية تحديثات طلبات الشحن من تغيير المبلغ أو TX Hash أو مالك الطلب.
- السماح للمدير المخوّل بتسجيل قيد اعتماد الشحن مع بقاء تعديل الرصيد نفسه محكومًا بالصلاحيات.
- إبقاء Firebase Storage خارج المشروع واعتماد Cloudinary للصور.
- إزالة منطق localStorage كبديل لقاعدة البيانات؛ localStorage مخصص لتفضيلات اللغة والمظهر.
- الإبقاء على المنتجات الشائعة للمنتجات التي يحددها المدير كـ featured فقط.
- تحسين صفحات الهاتف وتدفق النشر الإداري والباقات.
- عدم الادعاء بأن تسليم العملات الخارجية يتم تلقائيًا بدون مزود fulfillment حقيقي؛ الطلب المدفوع يبقى pending حتى المعالجة الفعلية.

## التشغيل على Netlify
اضبط متغيرات البيئة:
- `FIREBASE_SERVICE_ACCOUNT_JSON`
- `CLOUDINARY_URL` باستخدام سر Cloudinary جديد بعد تدوير السر الذي تم كشفه سابقًا.
- عنوان USDT-TRC20 الحقيقي داخل إعدادات المتجر في Firestore.
- `NOWPAYMENTS_API_KEY` مفتاح API من NOWPayments (الخادم فقط).
- `NOWPAYMENTS_IPN_SECRET` المفتاح السري لـ IPN من NOWPayments (الخادم فقط).
- `PUBLIC_SITE_URL` النطاق العام لـ JoTPay، مثل `https://example.com`.
- `NOWPAYMENTS_IPN_URL` اختياري؛ إن لم تضبطه سيُستخدم `PUBLIC_SITE_URL/api/nowpayments-ipn`.

بعد تعديل متغيرات البيئة أنشئ Deploy جديد.

## NOWPayments — شحن المحفظة تلقائياً
- تمت إضافة `/api/nowpayments-create` لإنشاء فاتورة دفع من الخادم فقط.
- تمت إضافة `/api/nowpayments-ipn` لاستقبال إشعارات الدفع والتحقق من توقيع `x-nowpayments-sig` بـ HMAC-SHA512.
- لا يُضاف الرصيد عند `waiting` أو `confirming` أو `partially_paid`؛ الاعتماد التلقائي يتم فقط عند `finished`.
- معالجة IPN والرصيد والـ ledger ذرية وقابلة لإعادة الإرسال دون مضاعفة الرصيد.
- واجهة المحفظة تحتفظ بالشحن اليدوي القديم، وأضيف إليها زر الدفع التلقائي بدون تغيير هيكل الصفحة.
- الدفع عبر NOWPayments يفتح فاتورة/صفحة دفع خارجية، ويمكن للعميل اختيار العملة المتاحة هناك، بينما محفظة السحب المضبوطة في NOWPayments تبقى USDT-TRC20.


## ملاحظة مهمة عن الشحن الخارجي
المحفظة والخصم وتسجيل الطلبات والـ ledger تعمل على الخادم بشكل ذري. أما تنفيذ الشحن الخارجي لمزود الألعاب/الخدمات فلا يتم تزويره: يحتاج API/مزود fulfillment حقيقي قبل تحويل حالة الطلب إلى مكتمل تلقائيًا.

## Production Upgrade 2026-10-07
- الشراء أصبح Purchase Request حقيقيًا: خصم ذري من المحفظة + Order + Wallet Ledger، بدون fulfillment خارجي وهمي.
- تمت إضافة Confirmation Modal وSuccess Modal مع Order ID وحالة Pending.
- تمت إضافة حماية duplicate purchase قصيرة خادميًا بجانب idempotency.
- صفحة الطلبات ولوحة الإدارة تتحدثان لحظيًا عبر Firestore listeners.
- تم دعم refunded مع رد الرصيد وledger ذري وبصلاحيات Owner/Manager.
- تم تحويل نشر المنتجات إلى Multi-Step Publishing Wizard من 8 خطوات.
- منتجات شحن العملات تعرض 7 بطاقات بالضبط مع Base Quantity وحساب تلقائي وManual Override.
- السعر أخضر وعدد العملات برتقالي في واجهات بطاقات الشحن.
- الحظر أصبح مراقبًا لحظيًا مع Block Modal وسبب الحظر وحماية Firestore للمسارات الحساسة.
- تقرير التدقيق المحدث موجود في `QA_REPORT_FINAL_2026-10-07.md`.


## Production Hardening 2026-10-07 — v7
- Public catalog delivery no longer depends on the visitor being authenticated: active categories, products and banners are served through a dedicated read-only public catalog function, with Firestore public-read fallback.
- Authentication remains required only for purchase, wallet and other account-sensitive actions.
- Added a visible retry state when the public catalog cannot be loaded instead of silently presenting an empty store.
- Admin order details now show order ID, customer, service, amount, requested/delivered quantity, payment state, fulfillment state, target/username, package, source and creation time.
- Added an explicit manual fulfillment workflow in Admin: pending → processing → completed, with an audit entry and customer notification. No fake external fulfillment is performed.
- Refined the seven recharge cards with a restrained, realistic card treatment while preserving their existing layout and hierarchy.
- JavaScript/module syntax validation passed across all JS/MJS files.
