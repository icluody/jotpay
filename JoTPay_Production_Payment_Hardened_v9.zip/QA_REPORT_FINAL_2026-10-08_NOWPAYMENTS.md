# JoTPay Production Payment Hardening — NOWPayments
Date: 2026-10-08

## Scope
Payment-layer hardening only. Existing page structure, styling and business UI were preserved.

## Implemented
- Added server-side NOWPayments invoice creation at `/api/nowpayments-create`.
- API key is read only from Netlify environment variables and is never embedded in frontend code.
- Added `/api/nowpayments-ipn` with `x-nowpayments-sig` HMAC-SHA512 verification.
- IPN processing is idempotent: a repeated `finished` notification cannot credit the wallet twice.
- Wallet credit, payment status and wallet ledger are committed atomically in one Firestore transaction.
- Only the `finished` provider status credits the JoTPay wallet; waiting/confirming/partially_paid are not treated as success.
- Failed, expired and refunded provider statuses are recorded without crediting the wallet.
- Added authenticated/idempotent invoice creation with a 10 USD minimum and 100,000 USD maximum.
- Preserved the existing manual USDT-TRC20 TX-hash flow as a fallback.
- Added the new payment action to the existing wallet card without redesigning the page.
- Added Netlify redirects and environment-variable documentation.
- Added success/cancel return handling in the wallet page.

## Validation
- Node syntax check: PASS for all 22 JS/MJS files.
- No NOWPayments API/IPN secret was hardcoded into source.
- Existing public catalog and authenticated purchase paths were not removed or replaced.

## Required live configuration
Set in Netlify:
- `NOWPAYMENTS_API_KEY`
- `NOWPAYMENTS_IPN_SECRET`
- `PUBLIC_SITE_URL`
- optionally `NOWPAYMENTS_IPN_URL`

Then deploy and enter the exact public IPN URL in NOWPayments:
`https://YOUR_DOMAIN/api/nowpayments-ipn`

## Live smoke test
Use a small real test payment after deployment:
1. Log in.
2. Open Wallet.
3. Enter a test amount.
4. Click the NOWPayments payment button.
5. Complete the crypto payment.
6. Verify NOWPayments shows the payment as finished.
7. Verify JoTPay wallet balance increases exactly once.
8. Verify one `walletLedger` deposit exists.
9. Send/replay an identical IPN test if supported and verify balance does not increase again.

## Important business/compliance note
JoTPay credits are stored value/internal platform balance. The payment processor must permit the actual business model. Do not describe the product to NOWPayments or any future provider as ordinary physical goods if that is not accurate.
