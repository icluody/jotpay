# JoTPay Final QA — 2026-10-06

## Implemented
- Server-side wallet purchase with Firebase Admin transaction.
- Atomic wallet debit + order + wallet ledger.
- Top-up packages remain exactly seven per coin-top-up service.
- Top-up flow: package -> target/username -> confirmation -> wallet debit -> order.
- Merchant custom top-up flow with 20% bonus and $650 minimum enforced server-side.
- USDT-TRC20 wallet funding requests with transaction hash and admin approval.
- First eligible wallet funding applies the published first-funding bonus percentage to the credited balance and records the bonus in the ledger.
- Admin broadcast notifications and user-specific notifications.
- Temporary/permanent application-level user bans with reason and expiry fields.
- Public product browsing without authentication; authentication is required only to complete a purchase.
- Four canonical sections and all requested subcategories retained.
- Popular section now requires explicit admin `featured=true`.
- Product images are optional; Cloudinary remains the image upload path.
- Admin product publishing has a step-by-step flow with Next / Back / Skip controls.
- Admin UI receives mobile sizing improvements.
- Login/first-funding banner no longer depends on a language change to render.
- Missing UI strings were routed through i18n keys to prevent Arabic text from remaining when another language is selected.

## Security
- No Cloudinary API secret is stored in client assets.
- The previously exposed Cloudinary secret is not included in this package; rotate it before production use.
- Server functions require a Firebase service account environment variable.
- USDT address is configured by the owner in the admin settings; no wallet address or private key is hard-coded.

## Important non-demo behavior
JoTPay does not falsely mark an external coin delivery as completed when no external fulfillment provider/API has been configured. A paid top-up creates a real paid/pending order and debits the wallet atomically. The admin can process/complete/cancel the fulfillment from Orders. To automate delivery to a third-party platform, the corresponding provider API credentials and API contract must be configured.
