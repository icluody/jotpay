# JoTPay Production Hardening QA — v7
Date: 2026-10-07

## Scope
Static production audit and targeted hardening of the supplied JoTPay source archive. Existing visual structure was preserved; changes were limited to reliability, public catalog delivery, order administration, and restrained recharge-card styling.

## Findings and fixes

### 1. Public catalog visibility
**Finding:** The client was dependent on direct Firestore public queries. Although the Firestore rules already allow reads of active products/banners/categories, any client-side query/rules/deployment issue could silently produce an empty storefront.

**Fix:** Added `netlify/functions/public-catalog.mjs` and `/api/public-catalog`. It exposes only active public catalog data and contains no customer/admin data. Client code uses it first and falls back to direct Firestore reads.

**Result:** Product and offer display is explicitly public and independent of login. Login is still required only when initiating protected actions such as purchase.

### 2. Purchase / manual fulfillment
**Finding:** The purchase backend already creates a real order and ledger entry atomically and deliberately leaves external fulfillment pending. The admin page had order editing, but the order modal did not expose enough fulfillment context for reliable manual processing.

**Fix:** Expanded the admin order modal with customer, target, package, amount, quantities, payment, fulfillment, source and timestamp details. Added explicit manual fulfillment guidance and state handling:
`pending` → `processing` → `completed`.

**Result:** A successful wallet purchase is a real pending order visible to authorized admins. The platform does not pretend to call an external fulfillment provider.

### 3. Seven recharge cards
**Finding:** The existing seven-card layout worked but had a visually stronger/less restrained treatment than requested.

**Fix:** Preserved the existing dimensions/layout and added subtle depth, neutral borders, restrained bonus badges, clearer price/coin hierarchy, and less decorative hover behavior.

### 4. Duplicate purchase / server integrity
Existing protections were rechecked and preserved:
- server-side idempotency key
- short duplicate fingerprint lock
- atomic wallet debit + order + ledger
- product/package validation
- minimum purchase validation
- merchant minimum validation only in merchant custom flow
- exactly seven active top-up packages required server-side
- pending fulfillment instead of fake delivery

### 5. Security / access boundaries
Rechecked:
- public catalog contains only active public records
- admin order updates remain governed by Firestore roles
- refund remains restricted to owner/manager
- customer purchase remains authenticated
- sensitive collections are not exposed through the public catalog endpoint

## Automated checks
- JS/MJS syntax: PASS for all source modules.
- Public catalog function present: PASS.
- Netlify public catalog redirect present: PASS.
- Firestore active-product public read rule present: PASS.
- Admin real-time order listener present: PASS.
- Manual fulfillment UI present: PASS.
- Server exactly-7 top-up validation present: PASS.

## Deployment note
This archive has been code-audited and patched locally. A final live smoke test still needs to be performed after deployment with the production Firebase/Netlify environment:
1. Open the home page in a private/incognito session.
2. Verify products and offers appear before login.
3. Log in, fund the wallet, and purchase one product.
4. Confirm the order appears in Admin immediately.
5. Move it to Processing, perform the real external/manual shipment, then mark Completed.
6. Confirm the customer sees the updated status.

## Files added/changed
- `src/netlify/functions/public-catalog.mjs`
- `src/netlify.toml`
- `src/assets/js/api.js`
- `src/assets/js/home.js`
- `src/assets/js/admin.js`
- `src/assets/css/admin.css`
- `src/assets/css/main.css`
- `src/README.md`
