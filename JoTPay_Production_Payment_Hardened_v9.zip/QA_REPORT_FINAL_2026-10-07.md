# JoTPay — Production Upgrade QA Report — 2026-10-07

## نطاق التدقيق
تم إجراء تدقيق عميق على مسار الشراء، المحفظة، الطلبات، الحظر، لوحة الإدارة، نشر المنتجات، بطاقات شحن العملات، Cloudinary، Firestore Rules، i18n، Netlify، وواجهات الهاتف.

## مشاكل عالية/حرجة تم إصلاحها في الكود
1. الشراء كان يبدأ مباشرة من زر الشراء بدون نافذة تأكيد موحدة.
2. الصفحة الرئيسية وصفحة الخدمات كانتا تستخدمان مسارين مختلفين للشراء.
3. نجاح الشراء كان يعرض رسالة ثم يعيد التوجيه بدلاً من نافذة نجاح تحتوي رقم الطلب والحالة.
4. بيانات Order كانت تفتقد `total` في مسار الشراء الخادمي، ما جعل الإدارة/صفحة الطلبات تعرض إجماليات غير صحيحة.
5. `unitPrice` في Order كان يُسجل أحيانًا كالإجمالي بدل سعر الوحدة/الباقة.
6. حماية idempotency كانت تمنع بعض التكرارات فقط؛ تمت إضافة قفل قصير خادمي للتكرارات المتزامنة بين التبويبات/الأجهزة.
7. لم تكن حالات الطلب تتضمن `refunded` في واجهة المستخدم.
8. لم يكن رد المبلغ للـ refund عملية مالية ذرية مع ledger؛ تمت إضافة transaction مع قيد refund وصلاحية مناسبة.
9. قواعد Firestore للطلبات كانت تسمح بتعديل حقول أكثر من اللازم؛ تم حصر التعديل في حقول الحالة/الملاحظة/الاسترداد المسموحة.
10. قواعد المنتجات لم تكن تفرض وجود الصورة عند نشر المنتج ولا 7 بطاقات عند منتج شحن العملات؛ تمت إضافة تحقق قواعد أساسي.
11. المستخدم المحظور كان يعتمد بدرجة كبيرة على مراقبة الواجهة؛ تمت إضافة listener مباشر على مستند المستخدم مع Block Modal وتسجيل خروج.
12. بعض الصفحات الداخلية لم تكن تبدأ مراقبة حالة الحساب؛ تم ربط `common.js` مع Auth initialization.
13. محاولة تسجيل الدخول بحساب محظور لم تكن تعرض Modal موحدًا مع سبب الحظر؛ تم إصلاحها.
14. العمليات الحساسة للمستخدم المحظور لم تكن مقيدة بشكل كافٍ في Firestore Rules؛ تمت إضافة `customerActive()` لمسارات الإنشاء/التعديل الحساسة.
15. لوحة الطلبات لم تكن توفر فلاتر حقيقية؛ تمت إضافة بحث وفلاتر حالة فعلية.
16. لوحة الإدارة لم تكن تستقبل الطلبات الجديدة بشكل حي؛ تمت إضافة Firestore listener للطلبات.
17. صفحة طلبات المستخدم لم تكن تعكس تغيير الحالة فورًا؛ تمت إضافة listener حي للطلبات.
18. النشر كان Form واحدًا طويلًا؛ تمت إعادة بنائه إلى Publishing Wizard من 8 خطوات متتابعة مع حفظ البيانات بين الخطوات.
19. إعدادات شحن العملات لم تكن تعرض تجربة نشر متدرجة؛ تمت إضافة خطوة مستقلة لإعداد البطاقات السبع ومعاينتها.
20. حساب البطاقات كان يعرض قيمًا قابلة للتعديل دون تمييز واضح بين Automatic وManual Override؛ تم تثبيت هذا المفهوم والحفاظ على override.
21. إدخال كمية البطاقة الأولى أصبح المصدر التلقائي لبقية البطاقات وفق الصيغة المطلوبة.
22. واجهة بطاقات الشحن تم تحسين تمييز السعر باللون الأخضر والكمية باللون البرتقالي.
23. إلغاء Wizard أثناء التحرير أصبح يعرض تأكيدًا بدلاً من فقدان البيانات مباشرة.
24. نجاح النشر أصبح يعتمد على اكتمال Firestore write قبل إغلاق الـ Wizard وإظهار Success Modal.
25. إزالة `confirm()` من حذف العناصر الإدارية واستبدالها بنافذة تأكيد داخلية.

## Recharge Card Engine
عدد البطاقات: **7 بالضبط**.

| # | السعر | البونص |
|---|---:|---:|
| 1 | $9.90 | 0% |
| 2 | $19.90 | 3% |
| 3 | $49.90 | 5% |
| 4 | $99.90 | 7% |
| 5 | $199.00 | 10% |
| 6 | $499.00 | 15% |
| 7 | $999.00 | 20% |

الحساب:
`baseQuantity × (cardPrice / 9.90)` ثم إضافة نسبة البونص.

تم اختبار الصيغة حسابيًا مع: 100، 500، 1000، 5000، 10000، 99999.

## Purchase
مسار الشراء النهائي:

`Product → Option/Quantity → Target عند الحاجة → Confirmation → Server Validation → Atomic Wallet Deduction + Order + Ledger → Success Modal → Orders`

لا يوجد تنفيذ fulfillment خارجي أو API شحن تلقائي داخل المسار.

## Blocking
- مراقبة مباشرة لمستند المستخدم.
- Block Modal.
- عرض سبب الحظر.
- رفض تسجيل الدخول للحساب المحظور.
- منع العمليات الحساسة في Firestore Rules للحساب المحظور.
- دعم الحظر المؤقت المنتهي وفق وقت الانتهاء.

## اختبارات آلية منفذة
- جميع ملفات JavaScript/ESM وNetlify Functions: `node --check` PASS.
- فحص duplicate IDs في جميع HTML: PASS.
- فحص Netlify TOML: PASS.
- لا توجد `alert()` أو `confirm()` تشغيلية في JavaScript: PASS.
- لا توجد Firebase Storage upload APIs: PASS.
- لا توجد localhost/127.0.0.1 في الملفات التشغيلية: PASS.
- لا توجد مسارات fulfillment خارجية مضافة: PASS.

## ملاحظة إنتاجية
تم التحقق من الكود والتهيئة محليًا داخل الحزمة، لكن الاختبار الحي النهائي مع Firebase/Cloudinary/Netlify يتطلب بيئة الإنتاج الفعلية ومتغيرات Netlify السرية (`FIREBASE_SERVICE_ACCOUNT_JSON` و`CLOUDINARY_URL`). لم يتم اختلاق نجاح اتصال حي غير متاح في بيئة التدقيق.

## الملف النهائي
`JoTPay_Final_Production_FIXED.zip`

## Final verification — 2026-10-07
- Removed the homepage "Browse more / تصفح المزيد" feature reference; no active UI reference remains.
- Public catalog access is enforced at Firestore rules level for active categories/products/banners; no customer authentication is required to browse.
- Purchase remains authentication-required and is validated server-side through the Netlify function.
- Global 30% offer is implemented as additional delivered quantity, not a price discount. Product price remains unchanged.
- Top-up package bonus strip is rendered only when the package bonus is greater than 0; zero bonus produces no bonus strip.
- Added `Number` to the homepage configured customer-input flow so Username/ID/Number/Email are all honored consistently.
- Banner CTA localization accepts both Arabic spellings `استفد من العرض` and `استفيد من العرض`, and published banner translations are selected by the user's active language.
- Default/admin product currency is normalized to `$`; legacy `USD` values are normalized when edited/saved.
- Wallet purchases enforce a minimum charge of $10 server-side.
- Successful authentication updates the UI without forcing a full-page reload.
- All JavaScript/ESM and Netlify function files pass `node --check`.
- Final ZIP integrity test passes.
