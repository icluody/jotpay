# JoTPay QA / 2026-10-02

## Implemented fixes
- Replaced the old ImgBB image uploader with a protected Cloudinary upload path through Netlify Functions.
- Cloudinary credentials are server-side only; the browser never receives the API secret.
- First-login red 30% ticker is backed by an atomic Firestore marker so it appears once per account.
- Public catalog is restricted to exactly three sections: الشحن / شراء متابعين / شراء حسابات.
- Owner bootstrap migrates legacy category references and deactivates legacy category documents.
- Firestore rules prevent new products/orders from using non-canonical categories.
- Product publishing is organized into service basics, offer/image, and publishing controls, with guided price presets.
- Added image preview, direct-image URL support, Cloudinary upload, draft vs publish behavior, popularity/featured/sort controls.
- Added a dedicated popular-services section on the storefront.
- Removed public catalog fallback to localStorage; localStorage is reserved for theme/language preferences.
- Removed an invalid support mailto target and linked customers to the working support page instead.

## Static validation performed
- All JavaScript and Netlify Function files pass `node --check` on Node 22.
- JSON/TOML configuration parses successfully.
- All HTML files parse and referenced local assets exist.
- All relative JavaScript imports resolve.
- No `alert()` placeholder calls remain.
- No ImgBB / `img-upload` references remain.
- No Firebase Storage upload API calls are present.
- The supplied Cloudinary secret is not present in the project files.
- No legacy executable category identifiers are present in the public/admin code.
- 18 language locales are present in the translation file.

## Required live deployment configuration
Set these Netlify environment variables before testing Cloudinary uploads:
- `CLOUDINARY_URL` using a newly rotated Cloudinary API secret.
- `FIREBASE_SERVICE_ACCOUNT_JSON` containing a Firebase service-account JSON for the JoTPay project.
Create a new deploy after changing environment variables.

## Important limitation
The 30% ticker is promotional UI only. This build does not autonomously credit wallet value or execute a real top-up/payment settlement. A real payment/fulfillment backend must be connected before treating the 30% amount as an actual monetary credit.


## 2026-10-03 additional QA
- Updated catalog model to four primary sections and hierarchical subcategories.
- Updated admin product publishing to choose section then subcategory.
- Updated public catalog filtering and product listing page.
- Updated Firestore rules to validate section/subcategory relationships.
- JavaScript syntax checks passed after patch.
