# JoTPay Final QA — v6

## Requested changes
- Merchant minimum `$650` applies only to the merchant custom purchase flow for JoTPay platform coins.
- Normal product purchases are no longer blocked by the merchant `$650` rule.
- Merchant custom platform-coin purchases have no recipient/target field and credit the merchant wallet directly.
- The `/products` services page was removed from the project.
- `/products` is permanently redirected to `/` to prevent broken legacy links.
- Dedicated service-browsing buttons/navigation were removed.
- The homepage "تصفح المنتجات" button was removed.
- Top-up cards received a final responsive visual treatment and remain scoped to the top-up section only.

## Validation
- JavaScript/module syntax checks: PASS.
- `products.html` absent: PASS.
- No `/products` UI links or `products.html` runtime references: PASS.
- Merchant `$650` check exists only inside `packageId === 'merchant-custom'`: PASS.
- Merchant custom flow bypasses product target/input validation: PASS.
- Top-up server validation still requires exactly 7 active top-up packages: PASS.
- Source file count: 41.
