import { setLanguage, getCurrentLanguage, t, initLanguageSelect } from './i18n.js';
import { initTheme, applyTheme } from './theme.js';
import { initAuth } from './auth.js';

function ensureGlobalSettings(){
  if(document.getElementById('settings-modal')) return;
  const end=document.querySelector('.site-header .header-side.end');
  if(end){const b=document.createElement('button');b.id='settings-btn';b.className='icon-btn';b.type='button';b.setAttribute('aria-label',t('settings'));b.innerHTML='<i class="fa-solid fa-gear"></i>';end.prepend(b);}
  const modal=document.createElement('div');modal.id='settings-modal';modal.className='modal-backdrop hidden';modal.innerHTML=`<div class="modal-card"><div class="modal-head"><div><h2 data-i18n="settings">${t('settings')}</h2><p class="muted" data-i18n="settingsDescription">${t('settingsDescription')}</p></div><button id="close-settings" class="icon-btn" type="button" aria-label="${t('close')}"><i class="fa-solid fa-xmark"></i></button></div><div class="modal-body"><div class="form-stack"><div><label data-i18n="theme">${t('theme')}</label><div class="settings-themes"><button class="btn ghost" data-theme="dark" data-i18n="dark">${t('dark')}</button><button class="btn ghost" data-theme="light" data-i18n="light">${t('light')}</button><button class="btn ghost" data-theme="system" data-i18n="device">${t('device')}</button><button class="btn ghost" data-theme="ocean" data-i18n="ocean">${t('ocean')}</button><button class="btn ghost" data-theme="emerald" data-i18n="emerald">${t('emerald')}</button><button class="btn ghost" data-theme="violet" data-i18n="violet">${t('violet')}</button></div></div><div><label for="language-select" data-i18n="language">${t('language')}</label><select id="language-select"></select></div><a href="/support" class="support-email" data-i18n="support">${t('support')}</a></div></div></div>`;
  document.body.appendChild(modal);
  document.getElementById('settings-btn')?.addEventListener('click',()=>{modal.classList.remove('hidden');document.body.classList.add('modal-open')});
  document.getElementById('close-settings')?.addEventListener('click',()=>{modal.classList.add('hidden');document.body.classList.remove('modal-open')});
  modal.addEventListener('click',e=>{if(e.target===modal){modal.classList.add('hidden');document.body.classList.remove('modal-open')}});
}
const syncPageMeta=()=>{const path=location.pathname;const key=path.includes('orders')?'pageOrders':path.includes('wallet')?'pageWallet':path.includes('profile')?'pageProfile':path.includes('support')?'pageSupport':path.includes('products')?'pageProducts':'home';const title=key==='home'?'JoTPay':t(key);document.title=title==='JoTPay'?'JoTPay':`${title} | JoTPay`;document.documentElement.lang=getCurrentLanguage();};

document.addEventListener('DOMContentLoaded',()=>{ensureGlobalSettings();setLanguage(getCurrentLanguage());initLanguageSelect();initTheme();initAuth();syncPageMeta();});
window.addEventListener('jotpay:language',syncPageMeta);
