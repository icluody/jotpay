import { api } from './api.js';
import { auth, firebase } from './firebase.js';
import { openAuthModal } from './auth.js';
import { t, categoryName, localizeBannerField } from './i18n.js';
const { onAuthStateChanged } = firebase;

const esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const safeUrl=v=>{const raw=String(v||'').trim();if(!raw)return '';if(raw.startsWith('/'))return raw;try{const u=new URL(raw,location.origin);return ['https:','http:'].includes(u.protocol)?u.href:''}catch{return ''}};
const BONUS_RATE=0.30;const bonusQuantity=v=>Number((Number(v||0)*BONUS_RATE).toFixed(2));const money=(v,c='USD')=>`${c==='USD'||c==='$'?'$':esc(c)}${Number(v||0).toFixed(2)}`;
const categoryKey={'top-up':'topUp','cards-subscriptions':'cardsSubscriptions','followers':'buyFollowers','accounts':'buyAccounts'};
const DEFAULT_CATEGORIES=[
  {id:'top-up',name:'شحن عملات',type:'primary',parentId:'',sortOrder:10,active:true},
  {id:'cards-subscriptions',name:'بطاقات واشتراكات',type:'primary',parentId:'',sortOrder:20,active:true},
  {id:'followers',name:'شراء متابعين',type:'primary',parentId:'',sortOrder:30,active:true},
  {id:'accounts',name:'شراء حسابات',type:'primary',parentId:'',sortOrder:40,active:true}
];
const DEFAULT_SUBCATEGORIES=[
{id:'top-up-all',name:'الكل',type:'secondary',parentId:'top-up',sortOrder:0,active:true},
{id:'top-up-games',name:'ألعاب',type:'secondary',parentId:'top-up',sortOrder:10,active:true},
{id:'top-up-live',name:'بث مباشر',type:'secondary',parentId:'top-up',sortOrder:20,active:true},
{id:'top-up-voice',name:'غرف صوتية',type:'secondary',parentId:'top-up',sortOrder:30,active:true},
{id:'top-up-other',name:'أخرى',type:'secondary',parentId:'top-up',sortOrder:40,active:true},
{id:'cards-all',name:'الكل',type:'secondary',parentId:'cards-subscriptions',sortOrder:0,active:true},
{id:'cards',name:'بطاقات',type:'secondary',parentId:'cards-subscriptions',sortOrder:10,active:true},
{id:'subscriptions',name:'اشتراكات',type:'secondary',parentId:'cards-subscriptions',sortOrder:20,active:true},
{id:'followers-all',name:'الكل',type:'secondary',parentId:'followers',sortOrder:0,active:true},
{id:'followers-facebook',name:'فيسبوك',type:'secondary',parentId:'followers',sortOrder:10,active:true},
{id:'followers-whatsapp',name:'واتساب',type:'secondary',parentId:'followers',sortOrder:20,active:true},
{id:'followers-youtube',name:'يوتيوب',type:'secondary',parentId:'followers',sortOrder:30,active:true},
{id:'followers-instagram',name:'إنستاجرام',type:'secondary',parentId:'followers',sortOrder:40,active:true},
{id:'followers-tiktok',name:'تيك توك',type:'secondary',parentId:'followers',sortOrder:50,active:true},
{id:'followers-wechat',name:'وي شات',type:'secondary',parentId:'followers',sortOrder:60,active:true},
{id:'followers-telegram',name:'تيليجرام',type:'secondary',parentId:'followers',sortOrder:70,active:true},
{id:'followers-snapchat',name:'سناب شات',type:'secondary',parentId:'followers',sortOrder:80,active:true},
{id:'followers-x',name:'إكس / تويتر',type:'secondary',parentId:'followers',sortOrder:90,active:true},
{id:'followers-reddit',name:'ريديت',type:'secondary',parentId:'followers',sortOrder:100,active:true},
{id:'followers-linkedin',name:'لينكد إن',type:'secondary',parentId:'followers',sortOrder:110,active:true},
{id:'followers-threads',name:'ثريدز',type:'secondary',parentId:'followers',sortOrder:120,active:true},
{id:'followers-pinterest',name:'بينترست',type:'secondary',parentId:'followers',sortOrder:130,active:true},
{id:'followers-discord',name:'ديسكورد',type:'secondary',parentId:'followers',sortOrder:140,active:true},
{id:'followers-twitch',name:'تويتش',type:'secondary',parentId:'followers',sortOrder:150,active:true},
  {id:'followers-other',name:'أخرى',type:'secondary',parentId:'followers',sortOrder:160,active:true},
{id:'accounts-all',name:'الكل',type:'secondary',parentId:'accounts',sortOrder:0,active:true},
{id:'accounts-facebook',name:'فيسبوك',type:'secondary',parentId:'accounts',sortOrder:10,active:true},
{id:'accounts-whatsapp',name:'واتساب',type:'secondary',parentId:'accounts',sortOrder:20,active:true},
{id:'accounts-youtube',name:'يوتيوب',type:'secondary',parentId:'accounts',sortOrder:30,active:true},
{id:'accounts-instagram',name:'إنستاجرام',type:'secondary',parentId:'accounts',sortOrder:40,active:true},
{id:'accounts-tiktok',name:'تيك توك',type:'secondary',parentId:'accounts',sortOrder:50,active:true},
{id:'accounts-wechat',name:'وي شات',type:'secondary',parentId:'accounts',sortOrder:60,active:true},
{id:'accounts-telegram',name:'تيليجرام',type:'secondary',parentId:'accounts',sortOrder:70,active:true},
{id:'accounts-snapchat',name:'سناب شات',type:'secondary',parentId:'accounts',sortOrder:80,active:true},
{id:'accounts-x',name:'إكس / تويتر',type:'secondary',parentId:'accounts',sortOrder:90,active:true},
{id:'accounts-reddit',name:'ريديت',type:'secondary',parentId:'accounts',sortOrder:100,active:true},
{id:'accounts-linkedin',name:'لينكد إن',type:'secondary',parentId:'accounts',sortOrder:110,active:true},
{id:'accounts-threads',name:'ثريدز',type:'secondary',parentId:'accounts',sortOrder:120,active:true},
{id:'accounts-pinterest',name:'بينترست',type:'secondary',parentId:'accounts',sortOrder:130,active:true},
{id:'accounts-discord',name:'ديسكورد',type:'secondary',parentId:'accounts',sortOrder:140,active:true},
{id:'accounts-twitch',name:'تويتش',type:'secondary',parentId:'accounts',sortOrder:150,active:true},
{id:'accounts-other',name:'أخرى',type:'secondary',parentId:'accounts',sortOrder:160,active:true}
];
const DEFAULT_LOGIN_BANNER={
  tag:'مكافأة أول تسجيل دخول',
  title:'زيادة 30% على قيمة الشحن لأول مرة',
  description:'عند تسجيل الدخول لأول مرة إلى JoTPay، تظهر لك مكافأة زيادة 30% على قيمة الشحن وفق العرض المنشور.',
  bonusPercent:30,audience:'first-login',active:true
};

let products=[],settings={},banners=[],loginBanner=null,currentPrimary='top-up',currentSecondary='top-up-all',categories=[],resultsVisible=true,shouldShowFirstLoginBanner=false;
let currentSlide=0,carouselTimer=null,cleanupCarousel=null,languageHandler=null;

export function initHome(){
  bindStaticActions();initSearch();categories=[...DEFAULT_CATEGORIES,...DEFAULT_SUBCATEGORIES];currentPrimary='top-up';currentSecondary='top-up-all';resultsVisible=true;renderCategories(categories);renderPopularProducts([]);renderBanners([]);renderLoginBanner(null);renderMaintenance({});
  loadPublishedData();
  onAuthStateChanged(auth,async user=>{
    if(!user){renderLoginBanner(null);return;}
    try{shouldShowFirstLoginBanner=Boolean(await api.consumeFirstLoginBanner?.());renderLoginBanner(shouldShowFirstLoginBanner?(loginBanner||DEFAULT_LOGIN_BANNER):null);}
    catch(e){console.warn('[JoTPay] first-login banner check failed',e);renderLoginBanner(null);}
  });
  languageHandler=()=>{renderCategories(categories);renderCategoryResults();renderPopularProducts(products);renderBanners(banners);renderMaintenance(settings);if(!auth.currentUser||shouldShowFirstLoginBanner)renderLoginBanner(loginBanner||DEFAULT_LOGIN_BANNER);};
  window.addEventListener('jotpay:language',languageHandler);
}

async function loadPublishedData(){
  products=[];banners=[];settings={};loginBanner=null;
  const results=await Promise.allSettled([api.categories(),api.products(),api.banners(),api.loginBanner(),api.settings()]);
  const rawCats=results[0].status==='fulfilled'?results[0].value:[];
  const cats=(Array.isArray(rawCats)?rawCats:[]).filter(c=>c.active!==false && ['primary','secondary'].includes(String(c.type||'')));
  const merged=[...DEFAULT_CATEGORIES,...DEFAULT_SUBCATEGORIES];
  const byId=new Map(merged.map(c=>[c.id,c]));
  cats.forEach(c=>byId.set(c.id,c));
  categories=[...byId.values()].sort((a,b)=>Number(a.type==='primary')-Number(b.type==='primary') || Number(a.sortOrder??9999)-Number(b.sortOrder??9999));
  renderCategories(categories);
  products=results[1].status==='fulfilled'?(results[1].value||[]):[];
  banners=results[2].status==='fulfilled'?(results[2].value||[]):[];
  loginBanner=results[3].status==='fulfilled'&&results[3].value?{...DEFAULT_LOGIN_BANNER,...results[3].value}:null;
  settings=results[4].status==='fulfilled'?(results[4].value||{}):{};
  renderCategoryResults();renderPopularProducts(products);renderBanners(banners);renderMaintenance(settings);if(!auth.currentUser||shouldShowFirstLoginBanner)renderLoginBanner(loginBanner||DEFAULT_LOGIN_BANNER);
  if(results[1].status==='rejected' || results[2].status==='rejected'){
    console.warn('[JoTPay] Public catalog load degraded', results.map(r=>r.status));
    const retry=document.getElementById('public-catalog-retry');
    if(!retry){
      const host=document.querySelector('.page-main');
      if(host){
        const n=document.createElement('div'); n.id='public-catalog-retry'; n.className='notice warning'; n.style.marginTop='12px';
        n.innerHTML='<b>تعذر تحميل الكتالوج حالياً.</b><button type="button" class="btn ghost" style="margin-inline-start:8px">إعادة المحاولة</button>';
        n.querySelector('button').onclick=()=>{n.remove();loadPublishedData()};
        host.prepend(n);
      }
    }
  } else document.getElementById('public-catalog-retry')?.remove();
}

function getCategories(){return categories.length?categories:[...DEFAULT_CATEGORIES,...DEFAULT_SUBCATEGORIES];}
function primaryCategories(){return getCategories().filter(x=>x.type==='primary').sort((a,b)=>Number(a.sortOrder??9999)-Number(b.sortOrder??9999));}
function secondaryCategories(parentId){return getCategories().filter(x=>x.type==='secondary'&&x.parentId===parentId).sort((a,b)=>Number(a.sortOrder??9999)-Number(b.sortOrder??9999));}
function bindStaticActions(){
  const closeSearch=document.getElementById('search-close');
  closeSearch?.addEventListener('click',exitSearch);
  document.getElementById('banner-close')?.addEventListener('click',()=>document.getElementById('login-ticker')?.classList.add('hidden'));document.getElementById('login-ticker')?.addEventListener('click',e=>{if(e.target.closest('#banner-close'))return;if(!auth.currentUser)openAuthModal('login');});
}
function renderMaintenance(store){const n=document.getElementById('maintenance-banner');if(!n)return;if(store?.maintenance===true){n.classList.remove('hidden');n.querySelector('[data-maintenance-title]').textContent=t('maintenance');n.querySelector('[data-maintenance-message]').textContent=store.maintenanceMessage||t('maintenanceDefault')}else n.classList.add('hidden')}
function categoryLabel(x){const key=categoryKey[x.id];return key?t(key):categoryName(x.id, x.name);}
function renderCategories(rows){
  const el=document.getElementById('categories-container');if(!el)return;
  const list=(rows||[]).filter(x=>x.active!==false);
  const primary=list.filter(x=>x.type==='primary'&&['top-up','cards-subscriptions','followers','accounts'].includes(x.id)).sort((a,b)=>Number(a.sortOrder??9999)-Number(b.sortOrder??9999));
  if(!primary.some(x=>x.id===currentPrimary))currentPrimary=primary[0]?.id||'top-up';
  const subs=list.filter(x=>x.type==='secondary'&&x.parentId===currentPrimary).sort((a,b)=>Number(a.sortOrder??9999)-Number(b.sortOrder??9999));
  if(!subs.some(x=>x.id===currentSecondary))currentSecondary=subs[0]?.id||'';
  if(!subs.some(x=>x.id===currentSecondary))currentSecondary=subs[0]?.id||'';
  el.innerHTML=`<div class="primary-category-bar" role="tablist" aria-label="${esc(t('sections'))}">${primary.map(x=>`<button type="button" role="tab" aria-selected="${x.id===currentPrimary}" class="primary-category${x.id===currentPrimary?' active':''}" data-primary="${esc(x.id)}"><i class="${x.id==='top-up'?'fa-solid fa-coins':x.id==='cards-subscriptions'?'fa-solid fa-ticket':x.id==='followers'?'fa-solid fa-users':'fa-solid fa-user-shield'}"></i><span>${esc(categoryLabel(x))}</span></button>`).join('')}</div>${subs.length?`<div class="secondary-category-bar" role="tablist" aria-label="${esc(t('categoriesFor'))} ${esc(categoryLabel(primary.find(x=>x.id===currentPrimary)||{}))}">${subs.map(x=>`<button type="button" role="tab" aria-selected="${x.id===currentSecondary}" class="secondary-category${x.id===currentSecondary?' active':''}" data-secondary="${esc(x.id)}">${esc(categoryName(x.id,x.name))}</button>`).join('')}</div>`:''}`;
  el.querySelectorAll('[data-primary]').forEach(btn=>btn.addEventListener('click',()=>{currentPrimary=btn.dataset.primary;currentSecondary=secondaryCategories(currentPrimary)[0]?.id||'';resultsVisible=true;renderCategories(categories);renderCategoryResults(true)}));
  el.querySelectorAll('[data-secondary]').forEach(btn=>btn.addEventListener('click',()=>{currentSecondary=btn.dataset.secondary;resultsVisible=true;renderCategoryResults(true);el.querySelectorAll('[data-secondary]').forEach(x=>x.classList.toggle('active',x.dataset.secondary===currentSecondary));}));
}
function productCard(p,options={}){const image=safeUrl(p.image||''),hidePrice=Boolean(options.hidePrice),raw=Number(p.price||0),unit=esc(p.unitLabel||t('quantity'));const hasQuantity=String(p.sectionId||'')==='followers' || (String(p.sectionId||'')!=='top-up' && String(p.sectionId||'')!=='accounts' && !['cards','subscriptions'].includes(String(p.categoryId||'')));const bonus=hasQuantity?bonusQuantity(1):0;return `<button type="button" data-product="${esc(p.id)}" class="product-card"><div class="product-image">${image?`<img src="${esc(image)}" alt="${esc(p.name)}" loading="lazy" decoding="async">`:'<i class="fa-solid fa-coins"></i>'}</div><div class="product-body"><b>${esc(p.name)}</b>${p.platform?`<small class="muted product-platform">${esc(p.platform)}</small>`:''}<div class="product-meta">${hidePrice?`<span class="product-price product-price-hidden">${esc(t('offer'))}</span>`:`<span class="product-price sale">${money(raw,p.currency)}</span>${hasQuantity?`<small class="discount-badge quantity-bonus-badge">+30% ${esc(t('bonusQuantity'))}</small>`:''}`}<span class="rating"><i class="fa-solid fa-star"></i> ${Number(p.rating??5).toFixed(1)}</span></div></div></button>`;}
function renderCategoryResults(scroll=false){const wrap=document.getElementById('category-results'),grid=document.getElementById('category-products'),title=document.getElementById('category-results-title');if(!wrap||!grid||!title)return;if(!resultsVisible){hideCategoryResults();return;}const sub=currentSecondary;const section=primaryCategories().find(x=>x.id===currentPrimary);const subcat=secondaryCategories(currentPrimary).find(x=>x.id===sub);const isAll=String(sub||'').endsWith('-all');const list=products.filter(p=>String(p.sectionId||'')===currentPrimary&&(isAll||String(p.categoryId||'')===sub));title.textContent=`${section?categoryLabel(section):''}${subcat&&!isAll?' — '+categoryName(subcat.id,subcat.name):isAll?' — '+esc(t('all')):''}`;grid.innerHTML=list.length?list.slice(0,60).map(p=>productCard(p,{hidePrice:String(p.sectionId||'')==='top-up'})).join(''):`<div class="empty-state wide"><p>${esc(t('noPublishedServices'))}</p></div>`;grid.querySelectorAll('[data-product]').forEach(btn=>btn.addEventListener('click',()=>openProduct(list.find(p=>p.id===btn.dataset.product))));wrap.classList.remove('hidden');if(scroll)wrap.scrollIntoView({behavior:'smooth',block:'start'});}
function renderPopularProducts(rows){const section=document.getElementById('popular-section'),grid=document.getElementById('popular-products');if(!section||!grid)return;const popular=(rows||[]).filter(p=>p.active!==false&&p.featured===true).slice().sort((a,b)=>Number(Boolean(b.featured))-Number(Boolean(a.featured))||Number(b.popularity||0)-Number(a.popularity||0)||Number(b.rating||0)-Number(a.rating||0)||Number(a.sortOrder??9999)-Number(b.sortOrder??9999)).slice(0,8);grid.innerHTML=popular.length?popular.map(p=>productCard(p,{hidePrice:String(p.sectionId||'')==='top-up'})).join(''):`<div class="empty-state wide"><p>${esc(t('noPublishedServices'))}</p></div>`;section.classList.remove('hidden');grid.querySelectorAll('[data-product]').forEach(btn=>btn.addEventListener('click',()=>openProduct(popular.find(p=>p.id===btn.dataset.product))));}
function hideCategoryResults(){const wrap=document.getElementById('category-results');if(wrap)wrap.classList.add('hidden')}
function localizedContent(item, field){const lang=document.documentElement.lang||'en';const tr=item?.translations?.[lang];if(tr&&typeof tr[field]==='string'&&tr[field].trim())return tr[field];const direct=item?.[field+'_'+lang];if(typeof direct==='string'&&direct.trim())return direct;return String(item?.[field]||'');}
function renderBanners(rows){
  const el=document.getElementById('promo-carousel'),dots=document.getElementById('carousel-dots');if(!el||!dots)return;
  clearInterval(carouselTimer);cleanupCarousel?.();cleanupCarousel=null;
  if(!rows.length){el.innerHTML=`<div class="promo-empty"><i class="fa-regular fa-images"></i><span>${esc(t('offersWillAppear'))}</span></div>`;dots.innerHTML='';return;}
  currentSlide=0;
  el.innerHTML=rows.map((b,i)=>`<article class="promo-slide${i===0?' active':''}" data-slide="${i}" data-url="${esc(b.actionUrl||'')}"><div class="promo-media"><img src="${esc(safeUrl(b.image||''))}" alt="${esc(localizeBannerField(b,'title'))}" loading="${i===0?'eager':'lazy'}" decoding="async"></div><div class="promo-copy"><span class="eyebrow">${esc(localizeBannerField(b,'tag')||t('offer'))}</span><h2>${esc(localizeBannerField(b,'title'))}</h2><p>${esc(localizeBannerField(b,'description'))}</p>${safeUrl(b.actionUrl)?`<a class="btn primary" href="${esc(safeUrl(b.actionUrl))}">${esc(localizeBannerField(b,'cta')||t('open'))}</a>`:''}</div></article>`).join('');
  if(rows.length>1)el.insertAdjacentHTML('beforeend',`<button type="button" class="carousel-arrow prev" id="promo-prev" aria-label="${esc(t('previous'))}"><i class="fa-solid fa-chevron-right"></i></button><button type="button" class="carousel-arrow next" id="promo-next" aria-label="${esc(t('next'))}"><i class="fa-solid fa-chevron-left"></i></button>`);
  dots.innerHTML=rows.map((_,i)=>`<button type="button" data-slide="${i}" aria-label="${i+1}"></button>`).join('');
  const show=index=>{currentSlide=(index+rows.length)%rows.length;el.querySelectorAll('.promo-slide').forEach((slide,i)=>slide.classList.toggle('active',i===currentSlide));dots.querySelectorAll('button').forEach((d,i)=>d.classList.toggle('active',i===currentSlide));};
  const restart=()=>{clearInterval(carouselTimer);if(rows.length>1&&!document.hidden)carouselTimer=setInterval(()=>show(currentSlide+1),6000)};
  dots.querySelectorAll('button').forEach(d=>d.addEventListener('click',()=>{show(Number(d.dataset.slide));restart()}));
  el.querySelector('#promo-prev')?.addEventListener('click',e=>{e.stopPropagation();show(currentSlide-1);restart()});
  el.querySelector('#promo-next')?.addEventListener('click',e=>{e.stopPropagation();show(currentSlide+1);restart()});
  el.querySelectorAll('.promo-slide').forEach(slide=>slide.addEventListener('click',e=>{if(e.target.closest('a'))return;const u=safeUrl(slide.dataset.url);if(u)location.href=u;}));
  let sx=0,sy=0;const ts=e=>{const p=e.touches[0];sx=p.clientX;sy=p.clientY};const te=e=>{const p=e.changedTouches[0],dx=p.clientX-sx,dy=p.clientY-sy;if(Math.abs(dx)>45&&Math.abs(dx)>Math.abs(dy)){show(currentSlide+(dx<0?1:-1));restart()}};
  el.addEventListener('touchstart',ts,{passive:true});el.addEventListener('touchend',te,{passive:true});
  const vis=()=>document.hidden?clearInterval(carouselTimer):restart();document.addEventListener('visibilitychange',vis);cleanupCarousel=()=>{el.removeEventListener('touchstart',ts);el.removeEventListener('touchend',te);document.removeEventListener('visibilitychange',vis);clearInterval(carouselTimer)};
  show(0);restart();
}
function renderLoginBanner(b){const sec=document.getElementById('login-ticker'),track=document.getElementById('login-ticker-track');if(!sec||!track)return;if(!b||b.active===false){sec.classList.add('hidden');return;}const pct=Math.max(0,Math.floor(Number(b.bonusPercent??30)));const fallbackTag=t('firstLoginBonusTag')||t('offer');const fallbackTitle=(t('firstLoginBonusTitle')||`زيادة ${pct}% على قيمة الشحن لأول مرة`).replace('30%',`${pct}%`);const text=`${b.tag||fallbackTag} — ${b.title||fallbackTitle}`;track.innerHTML=`<span><i class="fa-solid fa-gift"></i>${esc(text)}</span><span aria-hidden="true"><i class="fa-solid fa-gift"></i>${esc(text)}</span>`;sec.classList.remove('hidden');}
function initSearch(){
  const input=document.getElementById('main-search-input'),list=document.getElementById('search-suggestions');if(!input||!list)return;
  let timer;const closeBtn=document.getElementById('search-close');
  const setActive=active=>{document.body.classList.toggle('search-mode',active);document.getElementById('search-section')?.classList.toggle('search-active',active);closeBtn?.classList.toggle('hidden',!active)};
  const render=()=>{clearTimeout(timer);window.__jotpaySearchTimer=timer=setTimeout(()=>{const q=input.value.trim().toLowerCase();setActive(true);const rows=q?products.filter(p=>`${p.name} ${p.description||''}`.toLowerCase().includes(q)).slice(0,8):products.slice(0,8);list.innerHTML=rows.length?`${!q?`<div class="suggestion-heading">${esc(t('searchHint'))}</div>`:''}${rows.map(p=>`<button type="button" data-search-product="${esc(p.id)}" class="suggestion"><span class="suggestion-img">${safeUrl(p.image||'')?`<img src="${esc(safeUrl(p.image||''))}" alt="" loading="lazy">`:'<i class="fa-solid fa-coins"></i>'}</span><span><b>${esc(p.name)}</b><small>${money(p.price,p.currency)}</small></span></button>`).join('')}`:`<div class="search-empty-state">${esc(t('noResults'))}</div>`;list.classList.remove('hidden');list.querySelectorAll('[data-search-product]').forEach(btn=>btn.addEventListener('click',()=>{const p=products.find(x=>x.id===btn.dataset.searchProduct);exitSearch();openProduct(p)}))},40)};
  input.addEventListener('focus',render);input.addEventListener('input',render);input.addEventListener('keydown',e=>{if(e.key==='Escape')exitSearch()});document.addEventListener('click',e=>{if(!input.contains(e.target)&&!list.contains(e.target)&&!e.target.closest('#search-close'))list.classList.add('hidden')});
}
function exitSearch(){clearTimeout(window.__jotpaySearchTimer);const input=document.getElementById('main-search-input'),list=document.getElementById('search-suggestions');if(!input)return;clearTimeout(window.__jotpaySearchTimer);input.value='';list?.classList.add('hidden');document.body.classList.remove('search-mode');document.getElementById('search-section')?.classList.remove('search-active');document.getElementById('search-close')?.classList.add('hidden');input.blur()}
function openProduct(product){
 if(!product)return;const modal=document.getElementById('product-modal');if(!modal)return;const maintenance=settings?.maintenance===true;
 const name=modal.querySelector('[data-product-name]'),img=modal.querySelector('[data-product-image]'),desc=modal.querySelector('[data-product-description]'),price=modal.querySelector('[data-product-price]'),cat=modal.querySelector('[data-product-category]'),body=modal.querySelector('.modal-body');
 name.textContent=product.name||'';const image=safeUrl(product.image||'');img.innerHTML=image?`<img src="${esc(image)}" alt="${esc(product.name||'')}" loading="eager">`:'<i class="fa-solid fa-coins"></i>';desc.textContent=product.description||'';const c=categories.find(x=>x.id===product.categoryId)||categories.find(x=>x.id===product.sectionId);cat.textContent=c?categoryLabel(c):String(product.categoryName||'');
 modal.querySelector('#order-qty')?.closest('.form-stack')?.remove();const area=modal.querySelector('#product-purchase-area')||(()=>{const d=document.createElement('div');d.id='product-purchase-area';d.className='form-stack';d.style.marginTop='18px';body.appendChild(d);return d})();
 const close=()=>{modal.classList.add('hidden');document.body.classList.remove('modal-open')};modal.querySelector('#order-close').onclick=close;modal.onclick=e=>{if(e.target===modal)close()};modal.classList.remove('hidden');document.body.classList.add('modal-open');
 if(maintenance){area.innerHTML=`<div class="notice warning">${esc(settings.maintenanceMessage||t('maintenanceDefault'))}</div>`;return}
 const merchant=String(window.__jotpayAccountType||'personal')==='merchant';
 if(String(product.sectionId)==='top-up'){
   const packs=Array.isArray(product.topupPackages)?product.topupPackages.filter(x=>x&&x.active!==false):[];
   price.textContent=packs.length?t('chooseTopupCard')||'اختر بطاقة الشحن':money(product.price,product.currency);
   area.innerHTML=`<div class="topup-flow"><div class="topup-package-grid">${packs.map((x,i)=>{const pr=Number(x.price||0),base=Number(x.baseQuantity||x.quantity||0),bp=Number(x.bonusPercent||0);return `<button type="button" class="topup-package-card" data-pack="${i}"><span class="topup-card-index">${String(i+1).padStart(2,'0')}</span><span class="topup-card-label">${esc(t('topupPackage')||'باقة الشحن')}</span><span class="price-discount-wrap"><b class="topup-price">$${pr.toFixed(2)}</b></span><strong class="topup-coins">${Number(base+base*bp/100+base*BONUS_RATE).toLocaleString()} ${esc(product.unitLabel||'Coins')}</strong><span class="topup-card-divider"></span><span class="topup-bonus-row">${bp>0?`<span class="topup-bonus-strip">+${bp}% ${t('bonusStrip')}</span>`:''}<span class="topup-bonus-strip global-bonus">+30% ${esc(t('bonusQuantity'))}</span></span></button>`}).join('')}</div>${merchant?`<button type="button" class="btn ghost" id="merchant-custom-topup">${t('merchantCustom')}</button>`:''}<div class="notice warning ${packs.length?'hidden':''}">${esc(t('topupNotConfigured')||'لم يتم إعداد بطاقات الشحن لهذه الخدمة بعد.')}</div></div>`;
   area.querySelectorAll('[data-pack]').forEach(b=>b.onclick=()=>{const pack=packs[Number(b.dataset.pack)];if(!auth.currentUser){close();openAuthModal('login');return}openTopupTarget(product,pack,close,false)});
   area.querySelector('#merchant-custom-topup')?.addEventListener('click',()=>{if(!auth.currentUser){close();openAuthModal('login');return}openMerchantTopup(product,close)});return;
 }
 price.innerHTML=money(product.price,product.currency);
 const inputType=String(product.inputType||'');const isSubscription=String(product.categoryId)==='subscriptions';const needsConfiguredInput=['ID','Username','Number','Email'].includes(inputType);const quantityField=isSubscription?'':`<label>${esc(t('quantity')||'الكمية')}<input id="order-qty" type="number" min="1" max="100" value="1" inputmode="numeric"></label>`;const targetField=needsConfiguredInput?`<label>${esc(inputType)}<input id="order-target" type="${inputType==='Email'?'email':'text'}" ${inputType==='Email'?'autocomplete="email"':''} minlength="2" maxlength="160" required></label>`:'';
 area.innerHTML=`${quantityField}${targetField}<div id="order-msg" class="notice hidden"></div><button id="order-submit" class="btn primary" type="button">${esc(t('createOrder')||'شراء')}</button>`;
 area.querySelector('#order-submit').onclick=async()=>{if(!auth.currentUser){close();openAuthModal('login');return}const q=isSubscription?1:Math.floor(Number(area.querySelector('#order-qty')?.value||1));if(!Number.isInteger(q)||q<1||q>100){toast(t('purchaseInvalidQuantity'),'danger');return}const configuredTarget=area.querySelector('#order-target')?.value.trim()||'';if(needsConfiguredInput&&configuredTarget.length<2){toast(t('targetRequired'),'danger');return}const needsTarget=['followers','accounts'].includes(String(product.sectionId));if(needsConfiguredInput){close();await confirmAndPurchase({product,price:Number(product.price),quantity:q,target:configuredTarget,customerData:{target:configuredTarget,inputType}});return}if(needsTarget){let tm=document.getElementById('service-target-modal');if(!tm){tm=document.createElement('div');tm.id='service-target-modal';tm.className='modal-backdrop';tm.innerHTML=`<div class="modal-card"><div class="modal-head"><div><h2>${t('targetData')}</h2><p class="muted">${t('targetHint')}</p></div><button class="icon-btn" data-x>×</button></div><form class="modal-body form-stack"><label>${t('target')}<input id="service-target" required minlength="2" maxlength="160"></label><div id="service-target-error" class="notice danger hidden"></div><button class="btn primary" type="submit">${t('continuePurchase')}</button></form></div>`;document.body.appendChild(tm)}tm.classList.remove('hidden');document.body.classList.add('modal-open');tm.querySelector('#service-target').value='';tm.querySelector('[data-x]').onclick=()=>{tm.classList.add('hidden');document.body.classList.remove('modal-open')};tm.querySelector('form').onsubmit=async ev=>{ev.preventDefault();const target=tm.querySelector('#service-target').value.trim();if(target.length<2){tm.querySelector('#service-target-error').textContent=t('targetRequired');tm.querySelector('#service-target-error').className='notice danger';return}tm.classList.add('hidden');document.body.classList.remove('modal-open');close();await confirmAndPurchase({product,price:Number(product.price),quantity:q,target,customerData:{target}})};return}close();await confirmAndPurchase({product,price:Number(product.price),quantity:q,target:'',customerData:{}})};
}
function toast(text,type='info'){const n=document.getElementById('page-notice')||document.getElementById('order-msg');if(!n)return;n.textContent=text;n.className=`notice ${type}`;}
function localizedPurchaseError(code){const map={INSUFFICIENT_BALANCE:t('insufficientBalance'),MERCHANT_MIN_650:t('merchantMin650'),ACCOUNT_BANNED:t('accountBanned'),PRODUCT_UNAVAILABLE:t('productUnavailable'),AUTH_REQUIRED:t('loginNeeded'),TOPUP_PACKAGE_UNAVAILABLE:t('topupNotConfigured'),MINIMUM_PURCHASE_10:t('minimumPurchase10'),INVALID_NUMBER:t('invalidNumber')};return map[code]||code||t('purchaseFailed')||'تعذر إكمال الشراء.'}
async function confirmAndPurchase({product,price,quantity=1,target='',packageId='',customerData={}}){
 const balanceData=await api.user().catch(()=>null),balance=balanceData?Number(balanceData.walletBalance||0):null,amount=Number(price||0)*Number(quantity||1);
 if(amount<10){toast(t('minimumPurchase10'),'danger');return;}
 if(balance!==null&&balance<amount){toast(t('purchaseInsufficient')||t('insufficientBalance'),'danger');return;}
 let modal=document.getElementById('home-purchase-confirm');if(!modal){modal=document.createElement('div');modal.id='home-purchase-confirm';modal.className='modal-backdrop';modal.innerHTML=`<div class="modal-card purchase-confirm-card" role="dialog" aria-modal="true"><div class="modal-head"><div><h2>${t('purchaseConfirmTitle')}</h2><p class="muted">${t('purchaseConfirmMessage')}</p></div><button class="icon-btn" data-x>×</button></div><div class="modal-body"><div class="purchase-summary"><div><span>${t('purchaseConfirmProduct')}</span><b id="home-pc-product"></b></div><div><span>${t('purchaseConfirmPrice')}</span><b id="home-pc-price" class="purchase-price-value"></b></div><div><span>${t('purchaseConfirmBalance')}</span><b id="home-pc-balance"></b></div><div><span>${t('purchaseConfirmAfter')}</span><b id="home-pc-after"></b></div></div><div id="home-pc-error" class="notice danger hidden"></div><button id="home-pc-submit" class="btn primary" type="button">${t('purchaseConfirm')}</button></div></div>`;document.body.appendChild(modal)}
 modal.querySelector('#home-pc-product').textContent=product.name||'';modal.querySelector('#home-pc-price').textContent=money(amount,product.currency);modal.querySelector('#home-pc-balance').textContent=balance===null?'—':money(balance,product.currency);modal.querySelector('#home-pc-after').textContent=balance===null?'—':money(Math.max(0,balance-amount),product.currency);modal.querySelector('#home-pc-error').className='notice danger hidden';modal.classList.remove('hidden');document.body.classList.add('modal-open');
 const close=()=>{modal.classList.add('hidden');document.body.classList.remove('modal-open')};modal.querySelector('[data-x]').onclick=close;const btn=modal.querySelector('#home-pc-submit'),err=modal.querySelector('#home-pc-error');btn.disabled=false;btn.textContent=t('purchaseConfirm');btn.onclick=async()=>{if(btn.disabled)return;btn.disabled=true;btn.textContent=t('purchaseProcessing');try{const r=await api.purchaseWallet(product.id,quantity,{...customerData,target},packageId,price);close();showHomePurchaseSuccess(r,amount,product.currency);}catch(e){err.textContent=localizedPurchaseError(e.message);err.className='notice danger';btn.disabled=false;btn.textContent=t('purchaseConfirm');}};
}
function showHomePurchaseSuccess(r,amount,currency){let m=document.getElementById('home-purchase-success');if(!m){m=document.createElement('div');m.id='home-purchase-success';m.className='modal-backdrop';m.innerHTML=`<div class="modal-card purchase-result-card"><div class="modal-head"><div><h2>${t('purchaseCreated')}</h2><p class="muted">${t('orderStatus')}: ${t('orderPending')}</p></div><button class="icon-btn" data-x>×</button></div><div class="modal-body"><div class="purchase-result"><div><span>${t('orderNumber')}</span><b dir="ltr">#<span id="home-success-id"></span></b></div><div><span>${t('purchaseConfirmPrice')}</span><b id="home-success-total"></b></div></div><a class="btn primary" href="/orders">${t('viewOrder')}</a></div></div>`;document.body.appendChild(m)}m.querySelector('#home-success-id').textContent=r.orderId||'—';m.querySelector('#home-success-total').textContent=money(amount,currency);m.querySelector('[data-x]').onclick=()=>{m.classList.add('hidden');document.body.classList.remove('modal-open')};m.classList.remove('hidden');document.body.classList.add('modal-open');}

function openTopupTarget(product,pack,back,merchantMode=false){let modal=document.getElementById('topup-target-modal');if(!modal){modal=document.createElement('div');modal.id='topup-target-modal';modal.className='modal-backdrop';modal.innerHTML=`<div class="modal-card"><div class="modal-head"><div><h2>${t('targetData')}</h2><p class="muted">${t('targetHint')}</p></div><button class="icon-btn" data-x>×</button></div><div id="topup-summary" class="info-box"></div><form id="topup-form" class="form-stack"><label>${esc(product.inputType||t('target'))}<input id="topup-target" required minlength="2" maxlength="160" autocomplete="off"></label><div id="topup-message" class="notice hidden"></div><div style="display:grid;grid-template-columns:1fr 1fr;gap:8px"><button type="button" class="btn ghost" data-back>${t('back')}</button><button type="submit" class="btn primary">${t('confirmDeduct')}</button></div></form></div>`;document.body.appendChild(modal)}const pr=Number(pack.price||0),base=Number(pack.baseQuantity||pack.quantity||0),bp=Number(pack.bonusPercent||0),final=base+base*bp/100+base*BONUS_RATE;modal.querySelector('#topup-summary').innerHTML=`${esc(product.name)}<br><b>$${pr.toFixed(2)}</b> · ${final.toLocaleString()} ${esc(product.unitLabel||'Coins')} · ${bp>0?`<span class="topup-bonus-strip">+${bp}% ${t('bonusStrip')}</span>`:''}<span class="topup-bonus-strip global-bonus">+30% ${esc(t('bonusQuantity'))}</span>`;modal.classList.remove('hidden');document.body.classList.add('modal-open');modal.querySelector('#topup-target').value='';modal.querySelector('#topup-message').className='notice hidden';const close=()=>{modal.classList.add('hidden');document.body.classList.remove('modal-open');back?.()};modal.querySelector('[data-x]').onclick=close;modal.querySelector('[data-back]').onclick=close;modal.querySelector('#topup-form').onsubmit=async e=>{e.preventDefault();const btn=e.submitter,msg=modal.querySelector('#topup-message');btn.disabled=true;try{const target=modal.querySelector('#topup-target').value.trim();if(target.length<2){msg.textContent=t('targetRequired');msg.className='notice danger';btn.disabled=false;return}modal.classList.add('hidden');document.body.classList.remove('modal-open');back?.();await confirmAndPurchase({product,price:pr,quantity:1,target,packageId:String(pack.id||pack.price),customerData:{target}});btn.disabled=false}catch(err){msg.textContent=localizedPurchaseError(err.message);msg.className='notice danger';btn.disabled=false}}}
function openMerchantTopup(product,back){let modal=document.getElementById('merchant-modal');if(!modal){modal=document.createElement('div');modal.id='merchant-modal';modal.className='modal-backdrop';modal.innerHTML=`<div class="modal-card"><div class="modal-head"><div><h2>${t('merchantCustom')}</h2><p class="muted">${t('merchantMin650')} · +30% ${esc(t('bonusQuantity'))}</p></div><button class="icon-btn" data-x>×</button></div><form id="merchant-form" class="form-stack"><div class="info-box">${esc(t('merchantWalletOnly')||'شراء عملات المنصة وإضافتها مباشرة إلى رصيدك')}</div><label>${t('merchantMode')}<select id="merchant-mode"><option value="amount">${t('amount')}</option><option value="quantity">${t('coinsLabel')}</option></select></label><label id="merchant-value-label">${t('amountUSD')}<input id="merchant-value" type="number" min="650" step="0.01" required></label><div id="merchant-quote" class="info-box"></div><div id="merchant-msg" class="notice hidden"></div><button class="btn primary" type="submit">${t('confirmDeduct')}</button></form></div>`;document.body.appendChild(modal)}modal.classList.remove('hidden');document.body.classList.add('modal-open');const form=modal.querySelector('#merchant-form'),mode=modal.querySelector('#merchant-mode'),val=modal.querySelector('#merchant-value'),quote=modal.querySelector('#merchant-quote'),label=modal.querySelector('#merchant-value-label');const update=()=>{const m=mode.value;label.firstChild.textContent=m==='amount'?t('amountUSD'):t('coinsLabel');const first=Array.isArray(product.topupPackages)?product.topupPackages.find(x=>x&&x.active!==false):null;const ratePrice=Number(first?.price||0),rateCoins=Number(first?.baseQuantity||first?.quantity||0);const minCoins=ratePrice>0&&rateCoins>0?650/ratePrice*rateCoins*1.30:0;val.min=m==='amount'?'650':String(Math.ceil(minCoins));api.merchantQuote(product,m,val.value||0).then(q=>quote.innerHTML=`${t('amountUSD')}: <b>$${q.charged.toFixed(2)}</b><br>${t('baseCoins')}: ${q.baseCoins.toFixed(2)}<br>${t('bonus')}: +${q.bonusCoins.toFixed(2)} (30%)<br><strong>${t('totalCoins')}: ${q.totalCoins.toFixed(2)} ${esc(product.unitLabel||t('coinsLabel'))}</strong>`).catch(()=>quote.textContent=t('invalidValue'));};mode.onchange=update;val.oninput=update;update();const close=()=>{modal.classList.add('hidden');document.body.classList.remove('modal-open');back?.()};modal.querySelector('[data-x]').onclick=close;form.onsubmit=async e=>{e.preventDefault();const msg=modal.querySelector('#merchant-msg'),btn=form.querySelector('button[type=submit]');const q=await api.merchantQuote(product,mode.value,val.value);if(q.charged<650){msg.textContent=t('merchantMinimumError');msg.className='notice danger';return}btn.disabled=true;try{modal.classList.add('hidden');document.body.classList.remove('modal-open');back?.();await confirmAndPurchase({product,price:q.charged,quantity:1,target:'',packageId:'merchant-custom',customerData:{target:'',merchant:true,merchantMode:mode.value,merchantValue:Number(val.value),requestedCoins:q.totalCoins,charged:q.charged}});btn.disabled=false}catch(err){msg.textContent=localizedPurchaseError(err.message);msg.className='notice danger';btn.disabled=false}}}

