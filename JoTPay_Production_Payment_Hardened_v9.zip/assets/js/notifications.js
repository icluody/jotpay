import { auth, firebase } from './firebase.js';
import { api } from './api.js';
import { openAuthModal } from './auth.js';
import { t } from './i18n.js';

const esc = v => String(v ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const { onAuthStateChanged } = firebase;

let cached = [];

function formatDate(value) {
  if (!value) return '—';
  return new Date(value).toLocaleString(document.documentElement.lang || 'ar');
}

function renderList(rows) {
  const list = document.getElementById('notifications-list');
  if (!list) return;
  if (!rows.length) {
    list.innerHTML = `<div class="empty-state"><i class="fa-regular fa-bell-slash"></i><p>${esc(t('noNotifications'))}</p></div>`;
    return;
  }
  list.innerHTML = rows.map(n => `
    <button type="button" class="notification-item ${n.read ? '' : 'unread'}" data-notification-id="${esc(n.id)}" data-broadcast="${n.broadcast?'true':'false'}">
      <span class="notification-icon"><i class="fa-solid ${n.type === 'order' ? 'fa-receipt' : n.type === 'support' ? 'fa-headset' : 'fa-circle-info'}"></i></span>
      <span class="notification-copy"><b>${esc(n.title || 'JoTPay')}</b><span>${esc(n.message || '')}</span><small>${esc(formatDate(n.createdAt))}</small></span>
      ${n.read ? '' : '<i class="fa-solid fa-circle unread-dot"></i>'}
    </button>`).join('');
  list.querySelectorAll('[data-notification-id]').forEach(btn => btn.addEventListener('click', async () => {
    const id = btn.dataset.notificationId;
    try { if(btn.dataset.broadcast!=='true') await api.markNotificationRead(id); const target = cached.find(x => x.id === id); if (target) target.read = true; refreshBadge(); btn.classList.remove('unread'); btn.querySelector('.unread-dot')?.remove(); } catch (e) { console.error(e); }
  }));
}

function refreshBadge() {
  const badge = document.getElementById('notif-badge');
  if (!badge) return;
  const unread = cached.filter(n => !n.read).length;
  badge.textContent = unread > 9 ? '9+' : String(unread || '');
  badge.classList.toggle('hidden', unread === 0);
}

async function openNotifications() {
  const modal = document.getElementById('notifications-modal');
  if (!modal) return;
  if (!auth.currentUser) { openAuthModal('login'); return; }
  modal.classList.remove('hidden');
  document.body.classList.add('modal-open');
  const list = document.getElementById('notifications-list');
  list.innerHTML = `<div class="loading-line">${t('notificationsLoading')}</div>`;
  try {
    cached = await api.myNotifications();
    renderList(cached);
    refreshBadge();
  } catch (e) {
    list.innerHTML = `<div class="empty-state"><i class="fa-solid fa-circle-exclamation"></i><p>${t('notificationsLoadFailed')}</p></div>`;
  }
}

export function initNotifications() {
  const btn = document.getElementById('notifications-btn');
  const close = document.getElementById('close-notifications');
  const modal = document.getElementById('notifications-modal');
  btn?.addEventListener('click', openNotifications);
  close?.addEventListener('click', () => { modal?.classList.add('hidden'); document.body.classList.remove('modal-open'); });
  modal?.addEventListener('click', e => { if (e.target === modal) { modal.classList.add('hidden'); document.body.classList.remove('modal-open'); } });

  onAuthStateChanged(auth, async user => {
    cached = [];
    refreshBadge();
    if (!user) return;
    try { cached = await api.myNotifications(); refreshBadge(); } catch (e) { console.warn('Notifications', e); }
  });
}
