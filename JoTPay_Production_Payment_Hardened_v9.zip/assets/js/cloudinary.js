/**
 * JoTPay Cloudinary upload client.
 * The API secret is never exposed to the browser.
 * Admin -> Netlify Function -> Cloudinary.
 */
const MAX_FILE_SIZE = 12 * 1024 * 1024;
const ACCEPTED_TYPES = new Set(['image/jpeg', 'image/png', 'image/webp']);

async function prepareImage(file) {
  if (!file || !ACCEPTED_TYPES.has(String(file.type || '').toLowerCase())) {
    throw new Error('اختر صورة JPG أو PNG أو WEBP صالحة.');
  }
  if (file.size > MAX_FILE_SIZE) throw new Error('حجم الصورة الأصلي كبير جداً. الحد 12MB.');

  let source=null;
  let cleanup=()=>{};
  try {
    source=await createImageBitmap(file);
  } catch {
    const objectUrl=URL.createObjectURL(file);
    source=await new Promise((resolve,reject)=>{
      const image=new Image();
      image.onload=()=>resolve(image);
      image.onerror=()=>reject(new Error('تعذر قراءة الصورة.'));
      image.src=objectUrl;
    });
    cleanup=()=>URL.revokeObjectURL(objectUrl);
  }

  try {
    const maxSide=1800;
    const width=source.width||source.naturalWidth||0;
    const height=source.height||source.naturalHeight||0;
    if(!width||!height)throw new Error('أبعاد الصورة غير صالحة.');
    const scale=Math.min(1,maxSide/Math.max(width,height));
    const canvas=document.createElement('canvas');
    canvas.width=Math.max(1,Math.round(width*scale));
    canvas.height=Math.max(1,Math.round(height*scale));
    const ctx=canvas.getContext('2d',{alpha:true,desynchronized:true});
    if(!ctx)throw new Error('تعذر تجهيز الصورة في المتصفح.');
    ctx.imageSmoothingEnabled=true;
    ctx.imageSmoothingQuality='high';
    ctx.clearRect(0,0,canvas.width,canvas.height);
    ctx.drawImage(source,0,0,canvas.width,canvas.height);

    let blob=await new Promise(resolve=>canvas.toBlob(resolve,'image/webp',0.86));
    if(!blob)blob=await new Promise(resolve=>canvas.toBlob(resolve,'image/jpeg',0.84));
    if(!blob)throw new Error('تعذر تجهيز الصورة للرفع.');

    if(blob.size>2.6*1024*1024){
      const smaller=await new Promise(resolve=>canvas.toBlob(resolve,'image/webp',0.70));
      if(smaller&&smaller.size<blob.size)blob=smaller;
    }
    if(blob.size>3.0*1024*1024){
      const smaller=await new Promise(resolve=>canvas.toBlob(resolve,'image/jpeg',0.66));
      if(smaller&&smaller.size<blob.size)blob=smaller;
    }
    if(blob.size>3.2*1024*1024)throw new Error('الصورة بعد الضغط ما زالت كبيرة. استخدم صورة أبسط أو أصغر من 12MB.');
    return blob;
  } finally {
    source?.close?.();
    cleanup();
  }
}

async function parseResponse(response) {
  const data = await response.json().catch(() => ({}));
  if (!response.ok || !data?.url) {
    throw new Error(data?.error || `فشل رفع الصورة (${response.status}).`);
  }
  return data;
}

export async function uploadImage(file, authInstance) {
  if (!authInstance?.currentUser) throw new Error('يجب تسجيل الدخول كمدير لرفع الصور.');
  const prepared = await prepareImage(file);
  const token = await authInstance.currentUser.getIdToken(true);
  const form = new FormData();
  form.append('image', prepared, 'jotpay-catalog.webp');
  const response = await fetch('/api/cloudinary-upload', {
    method: 'POST',
    headers: { Authorization: `Bearer ${token}` },
    body: form,
    credentials: 'same-origin',
  });
  const data = await parseResponse(response);
  return String(data.url);
}
