import { db, auth, firebase, currentUserProfile, ensureUserDocument } from './firebase.js';
const { collection, doc, getDoc, getDocs, addDoc, updateDoc, query, where, limit, serverTimestamp, runTransaction, orderBy } = firebase;
const col=name=>collection(db,name);
const clean=x=>x?.toDate?x.toDate().toISOString():x;
const normalize=d=>({id:d.id,...d.data(),createdAt:clean(d.data().createdAt),updatedAt:clean(d.data().updatedAt)});
const cache=new Map();
const DEFAULT_CATEGORIES=[
{id:'top-up',name:'شحن عملات',type:'primary',parentId:'',sortOrder:10,active:true},
{id:'cards-subscriptions',name:'بطاقات واشتراكات',type:'primary',parentId:'',sortOrder:20,active:true},
{id:'followers',name:'شراء متابعين',type:'primary',parentId:'',sortOrder:30,active:true},
{id:'accounts',name:'شراء حسابات',type:'primary',parentId:'',sortOrder:40,active:true}
];
const DEFAULT_SUBCATEGORIES=[
{id:'top-up-games',name:'ألعاب',type:'secondary',parentId:'top-up',sortOrder:10,active:true},
{id:'top-up-live',name:'بث مباشر',type:'secondary',parentId:'top-up',sortOrder:20,active:true},
{id:'top-up-voice',name:'غرف صوتية',type:'secondary',parentId:'top-up',sortOrder:30,active:true},
{id:'top-up-other',name:'أخرى',type:'secondary',parentId:'top-up',sortOrder:40,active:true},
{id:'cards',name:'بطاقات',type:'secondary',parentId:'cards-subscriptions',sortOrder:10,active:true},
{id:'subscriptions',name:'اشتراكات',type:'secondary',parentId:'cards-subscriptions',sortOrder:20,active:true},
{id:'followers-facebook',name:'فيسبوك',type:'secondary',parentId:'followers',sortOrder:10,active:true},
{id:'followers-whatsapp',name:'واتساب',type:'secondary',parentId:'followers',sortOrder:20,active:true},
{id:'followers-youtube',name:'يوتيوب',type:'secondary',parentId:'followers',sortOrder:30,active:true},
{id:'followers-instagram',name:'إنستاجرام',type:'secondary',parentId:'followers',sortOrder:40,active:true},
{id:'followers-tiktok',name:'تيك توك',type:'secondary',parentId:'followers',sortOrder:50,active:true},
{id:'followers-wechat',name:'وي شات',type:'secondary',parentId:'followers',sortOrder:60,active:true},
{id:'followers-telegram',name:'تيليجرام',type:'secondary',parentId:'followers',sortOrder:70,active:true},
{id:'followers-snapchat',name:'سناب شات',type:'secondary',parentId:'followers',sortOrder:80,active:true},
{id:'followers-x',name:'إكس / تويتر',type:'secondary',parentId:'followers',sortOrder:90,active:true},
{id:'followers-reddit',name:'ريديت',type:'secondary',parentId:'followers',sortOrder:100,active:true},
{id:'followers-linkedin',name:'لينكد إن',type:'secondary',parentId:'followers',sortOrder:110,active:true},
{id:'followers-threads',name:'ثريدز',type:'secondary',parentId:'followers',sortOrder:120,active:true},
{id:'followers-pinterest',name:'بينترست',type:'secondary',parentId:'followers',sortOrder:130,active:true},
{id:'followers-discord',name:'ديسكورد',type:'secondary',parentId:'followers',sortOrder:140,active:true},
{id:'followers-twitch',name:'تويتش',type:'secondary',parentId:'followers',sortOrder:150,active:true},
  {id:'followers-other',name:'أخرى',type:'secondary',parentId:'followers',sortOrder:160,active:true},
{id:'accounts-facebook',name:'فيسبوك',type:'secondary',parentId:'accounts',sortOrder:10,active:true},
{id:'accounts-whatsapp',name:'واتساب',type:'secondary',parentId:'accounts',sortOrder:20,active:true},
{id:'accounts-youtube',name:'يوتيوب',type:'secondary',parentId:'accounts',sortOrder:30,active:true},
{id:'accounts-instagram',name:'إنستاجرام',type:'secondary',parentId:'accounts',sortOrder:40,active:true},
{id:'accounts-tiktok',name:'تيك توك',type:'secondary',parentId:'accounts',sortOrder:50,active:true},
{id:'accounts-wechat',name:'وي شات',type:'secondary',parentId:'accounts',sortOrder:60,active:true},
{id:'accounts-telegram',name:'تيليجرام',type:'secondary',parentId:'accounts',sortOrder:70,active:true},
{id:'accounts-snapchat',name:'سناب شات',type:'secondary',parentId:'accounts',sortOrder:80,active:true},
{id:'accounts-x',name:'إكس / تويتر',type:'secondary',parentId:'accounts',sortOrder:90,active:true},
{id:'accounts-reddit',name:'ريديت',type:'secondary',parentId:'accounts',sortOrder:100,active:true},
{id:'accounts-linkedin',name:'لينكد إن',type:'secondary',parentId:'accounts',sortOrder:110,active:true},
{id:'accounts-threads',name:'ثريدز',type:'secondary',parentId:'accounts',sortOrder:120,active:true},
{id:'accounts-pinterest',name:'بينترست',type:'secondary',parentId:'accounts',sortOrder:130,active:true},
{id:'accounts-discord',name:'ديسكورد',type:'secondary',parentId:'accounts',sortOrder:140,active:true},
{id:'accounts-twitch',name:'تويتش',type:'secondary',parentId:'accounts',sortOrder:150,active:true},
{id:'accounts-other',name:'أخرى',type:'secondary',parentId:'accounts',sortOrder:160,active:true}
];
const CANONICAL_CATEGORY_IDS=new Set([...DEFAULT_CATEGORIES,...DEFAULT_SUBCATEGORIES].map(c=>c.id));
const PRIMARY_IDS=new Set(DEFAULT_CATEGORIES.map(c=>c.id));
const DEFAULT_SUBCATEGORY_BY_PRIMARY=Object.fromEntries(DEFAULT_CATEGORIES.map(c=>[c.id,DEFAULT_SUBCATEGORIES.find(x=>x.parentId===c.id)?.id||'']));
function readStored(){return {}}
function writeStored(){return undefined}
export function getCachedPublic(){return {categories:[...DEFAULT_CATEGORIES,...DEFAULT_SUBCATEGORIES],products:[],banners:[],loginBanner:null,settings:{}}}
async function cached(key,loader,ttl=30000){const hit=cache.get(key);if(hit&&Date.now()-hit.at<ttl)return hit.value;const value=await loader();cache.set(key,{at:Date.now(),value});return value}
async function listPublic(name,max=200){const snap=await getDocs(query(col(name),where('active','==',true),limit(max)));return snap.docs.map(normalize)}
let publicCatalogPromise = null;
async function publicCatalog() {
  if (publicCatalogPromise) return publicCatalogPromise;
  publicCatalogPromise = (async () => {
  const response = await fetch('/api/public-catalog', {
    method: 'GET',
    headers: { accept: 'application/json' },
    cache: 'no-store',
  });
  if (!response.ok) throw new Error(`PUBLIC_CATALOG_${response.status}`);
  const data = await response.json();
  if (!data?.ok) throw new Error(data?.error || 'PUBLIC_CATALOG_FAILED');
  return {
    categories: Array.isArray(data.categories) ? data.categories : [],
    products: Array.isArray(data.products) ? data.products : [],
    banners: Array.isArray(data.banners) ? data.banners : [],
  };
  })();
  try { return await publicCatalogPromise; }
  finally { publicCatalogPromise = null; }
}

export const api={
 async categories(){return cached('categories',async()=>{try{const catalog=await publicCatalog();const rows=catalog.categories.filter(x=>['primary','secondary'].includes(String(x.type||'')));return rows.length?rows:getCachedPublic().categories}catch{try{const rows=(await listPublic('categories')).filter(x=>['primary','secondary'].includes(String(x.type||'')));rows.sort((a,b)=>(Number(a.sortOrder??9999)-Number(b.sortOrder??9999))||String(a.name||'').localeCompare(String(b.name||''),'ar'));return rows.length?rows:getCachedPublic().categories}catch{return getCachedPublic().categories}}})},
 async products(){return cached('products',async()=>{try{const catalog=await publicCatalog();return catalog.products.filter(x=>x.active!==false && (String(x.categoryId||'') || String(x.sectionId||'')))}catch{try{const rows=(await listPublic('products')).filter(x=>x.active!==false && (String(x.categoryId||'') || String(x.sectionId||'')));rows.sort((a,b)=>Number(Boolean(b.featured))-Number(Boolean(a.featured))||Number(b.popularity||0)-Number(a.popularity||0)||Number(a.sortOrder??9999)-Number(b.sortOrder??9999));return rows}catch{return getCachedPublic().products}}})},
 async banners(){return cached('banners',async()=>{try{const catalog=await publicCatalog();const rows=catalog.banners;writeStored({banners:rows});return rows}catch{try{const rows=await listPublic('banners');rows.sort((a,b)=>Number(a.sortOrder??9999)-Number(b.sortOrder??9999));writeStored({banners:rows});return rows}catch{return getCachedPublic().banners}}})},
 async loginBanner(){try{const s=await getDoc(doc(db,'settings','loginBanner'));const value=s.exists()&&s.data().active!==false?{id:s.id,...s.data()}:null;writeStored({loginBanner:value});return value}catch{return getCachedPublic().loginBanner}},
 async settings(){return cached('settings',async()=>{try{const s=await getDoc(doc(db,'settings','store'));const value=s.exists()?{id:s.id,...s.data()}:{};writeStored({settings:value});return value}catch{return getCachedPublic().settings}})},
 async user(){return currentUserProfile()},
 async purchaseWallet(productId,quantity=1,customerData={},packageId='',price=''){
   const user=auth.currentUser;if(!user)throw new Error('AUTH_REQUIRED');
   const token=await user.getIdToken();const idempotencyKey=globalThis.crypto?.randomUUID?.()||`${Date.now()}-${Math.random().toString(36).slice(2)}-${Math.random().toString(36).slice(2)}`;const r=await fetch('/api/wallet-purchase',{method:'POST',headers:{'content-type':'application/json',authorization:`Bearer ${token}`},body:JSON.stringify({productId,quantity,customerData,target:customerData?.target||customerData?.username||'',packageId,price,idempotencyKey})});
   const d=await r.json().catch(()=>({}));if(!r.ok)throw new Error(d.error||'PURCHASE_FAILED');return d;
 },
 async createOrder(productId,quantity=1,customerData={}){return this.purchaseWallet(productId,quantity,customerData,'','');},
 async createNOWPaymentsInvoice(amount){
   const user=auth.currentUser;if(!user)throw new Error('AUTH_REQUIRED');
   const token=await user.getIdToken();
   const idempotencyKey=globalThis.crypto?.randomUUID?.()||`${Date.now()}-${Math.random().toString(36).slice(2)}-${Math.random().toString(36).slice(2)}`;
   const r=await fetch('/api/nowpayments-create',{method:'POST',headers:{'content-type':'application/json',authorization:`Bearer ${token}`},body:JSON.stringify({amount,idempotencyKey})});
   const d=await r.json().catch(()=>({}));if(!r.ok)throw new Error(d.error||'NOWPAYMENTS_CREATE_FAILED');return d;
 },
 async createUSDTDeposit(amount,txHash){const user=auth.currentUser;if(!user)throw new Error('AUTH_REQUIRED');const token=await user.getIdToken();const r=await fetch('/api/usdt-deposit',{method:'POST',headers:{'content-type':'application/json',authorization:`Bearer ${token}`},body:JSON.stringify({amount,txHash})});const d=await r.json().catch(()=>({}));if(!r.ok)throw new Error(d.error||'DEPOSIT_FAILED');return d;},
 async merchantQuote(product,mode,value){const packs=Array.isArray(product?.topupPackages)?product.topupPackages.filter(x=>x&&x.active!==false):[];if(!packs.length)throw new Error('MERCHANT_TOPUP_NOT_CONFIGURED');const first=packs[0],price=Number(first.price||0),coins=Number(first.baseQuantity||first.quantity||0);if(price<=0||coins<=0)throw new Error('INVALID_TOPUP_RATE');const v=Number(value);if(!Number.isFinite(v)||v<=0)throw new Error('INVALID_VALUE');if(mode==='amount'){const charged=v,baseCoins=v/price*coins;return{charged,baseCoins,bonusCoins:baseCoins*.30,totalCoins:baseCoins*1.30,bonusPercent:30};}const requested=v,baseAmount=requested/1.30/coins*price;return{charged:baseAmount,baseCoins:requested/1.30,bonusCoins:requested/1.30*.30,totalCoins:requested,bonusPercent:30};},
 async consumeFirstLoginBanner(){
   const user=auth.currentUser;if(!user)return false;
   // Ensure the customer document exists before the atomic first-login marker is written.
   await ensureUserDocument(user);
   const ref=doc(db,'users',user.uid);
   let show=false;
   await runTransaction(db,async tx=>{
     const snap=await tx.get(ref);
     if(!snap.exists()) return;
     const data=snap.data()||{};
     if(data.welcomeBonusBannerShown===true) return;
     tx.update(ref,{welcomeBonusBannerShown:true,welcomeBonusBannerShownAt:serverTimestamp(),updatedAt:serverTimestamp()});
     show=true;
   });
   return show;
 },
 async myOrders(){const user=auth.currentUser;if(!user)return [];const snap=await getDocs(query(col('orders'),where('userId','==',user.uid),limit(100)));return snap.docs.map(normalize).sort((a,b)=>new Date(b.createdAt||0)-new Date(a.createdAt||0))},
 async myNotifications(){const user=auth.currentUser;if(!user)return [];const [personal,broadcast]=await Promise.all([getDocs(query(col('notifications'),where('userId','==',user.uid),limit(50))),getDocs(query(col('notificationBroadcasts'),where('active','==',true),limit(50)))]);return [...personal.docs.map(normalize),...broadcast.docs.map(d=>({...normalize(d),broadcast:true,read:true}))].sort((a,b)=>new Date(b.createdAt||0)-new Date(a.createdAt||0)).slice(0,80)},
 async markNotificationRead(id){const user=auth.currentUser;if(!user)return;const ref=doc(db,'notifications',id),snap=await getDoc(ref);if(!snap.exists()||snap.data().userId!==user.uid)return;const {updateDoc}=firebase;await updateDoc(ref,{read:true,readAt:serverTimestamp()})},
 async ensureUser(){return auth.currentUser?ensureUserDocument(auth.currentUser):null}
};
