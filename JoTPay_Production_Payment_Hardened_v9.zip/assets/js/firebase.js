/**
 * JoTPay Firebase client setup.
 *
 * Customer authentication uses the main Firebase app with local persistence.
 * Admin authentication uses a separate named Firebase app with session
 * persistence. Admin Firestore operations use adminDb, which is bound to the
 * same named app as adminAuth. This prevents customer/admin auth state from
 * being mixed and allows independent admin sessions.
 */
import {
  initializeApp,
  getApp,
  getApps
} from 'https://www.gstatic.com/firebasejs/12.19.0/firebase-app.js';

import {
  getAuth,
  initializeAuth,
  browserLocalPersistence,
  browserSessionPersistence,
  setPersistence,
  onAuthStateChanged,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  signOut,
  updateProfile,
  sendPasswordResetEmail
} from 'https://www.gstatic.com/firebasejs/12.19.0/firebase-auth.js';

import {
  getFirestore,
  collection,
  doc,
  getDoc,
  getDocs,
  setDoc,
  addDoc,
  updateDoc,
  deleteDoc,
  query,
  where,
  orderBy,
  limit,
  serverTimestamp,
  runTransaction,
  getCountFromServer,
  onSnapshot
} from 'https://www.gstatic.com/firebasejs/12.19.0/firebase-firestore.js';

export const firebaseConfig = {
  apiKey: 'AIzaSyAesgTFW22oi6oGKCIECxVf9Isi_DCw57k',
  authDomain: 'jotpay-4be1e.firebaseapp.com',
  databaseURL: 'https://jotpay-4be1e-default-rtdb.firebaseio.com',
  projectId: 'jotpay-4be1e',
  storageBucket: 'jotpay-4be1e.firebasestorage.app',
  messagingSenderId: '269096864510',
  appId: '1:269096864510:web:e81ae6fec8174b4e42f3af',
  measurementId: 'G-KR8Y5SMPQS'
};

/* -----------------------------
 * Main/customer Firebase app
 * ----------------------------- */
export const app = getApps().some(a => a.name === '[DEFAULT]')
  ? getApp()
  : initializeApp(firebaseConfig);

export const auth = getAuth(app);
export const db = getFirestore(app);
export const customerDb = db;

// Customer sessions persist between browser sessions.
setPersistence(auth, browserLocalPersistence).catch(error => {
  console.error('[JoTPay] Customer auth persistence failed:', error);
});

/* -----------------------------
 * Separate admin Firebase app
 * ----------------------------- */
let adminApp;

try {
  adminApp = getApp('jotpay-admin');
} catch {
  adminApp = initializeApp(firebaseConfig, 'jotpay-admin');
}

export { adminApp };

/* -----------------------------
 * Separate admin Auth
 * ----------------------------- */
let adminAuthInstance;

try {
  adminAuthInstance = getAuth(adminApp);
} catch {
  adminAuthInstance = initializeAuth(adminApp, {
    persistence: browserSessionPersistence
  });
}

export const adminAuth = adminAuthInstance;

// Explicitly enforce session persistence for admin authentication.
setPersistence(adminAuth, browserSessionPersistence).catch(error => {
  console.error('[JoTPay] Admin auth persistence failed:', error);
});

/* -----------------------------
 * Admin Firestore
 * -----------------------------
 * IMPORTANT: adminDb belongs to adminApp, the same named app used by
 * adminAuth. Admin pages must use adminDb for all Firestore operations.
 */
export const adminDb = getFirestore(adminApp);

/* -----------------------------
 * Generic Firebase API bundle
 * ----------------------------- */
export const firebase = {
  onAuthStateChanged,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  signOut,
  updateProfile,
  sendPasswordResetEmail,
  collection,
  doc,
  getDoc,
  getDocs,
  setDoc,
  addDoc,
  updateDoc,
  deleteDoc,
  query,
  where,
  orderBy,
  limit,
  serverTimestamp,
  runTransaction,
  getCountFromServer,
  onSnapshot
};

/* -----------------------------
 * Customer profile helpers
 * ----------------------------- */
export async function currentUserProfile(user = auth.currentUser) {
  if (!user) return null;

  const snap = await getDoc(doc(customerDb, 'users', user.uid));
  return snap.exists() ? { id: snap.id, ...snap.data() } : null;
}

export async function ensureUserDocument(user, options = {}) {
  if (!user) return null;

  const ref = doc(customerDb, 'users', user.uid);
  const snap = await getDoc(ref);

  if (!snap.exists()) {
    await setDoc(ref, {
      email: user.email || '', displayName: user.displayName || '', photoURL: user.photoURL || '',
      role: 'customer', accountType: options.accountType === 'merchant' ? 'merchant' : 'personal',
      walletBalance: 0, createdAt: serverTimestamp(), updatedAt: serverTimestamp()
    });
  } else if (!snap.data().accountType) {
    await updateDoc(ref, {accountType: options.accountType === 'merchant' ? 'merchant' : 'personal', updatedAt: serverTimestamp()});
  }
  return currentUserProfile(user);
}

/* -----------------------------
 * Admin profile/access helpers
 * ----------------------------- */
export async function currentAdminProfile(user = adminAuth.currentUser) {
  if (!user) return null;

  const snap = await getDoc(doc(adminDb, 'admins', user.uid));
  return snap.exists() ? { id: snap.id, ...snap.data() } : null;
}

export async function verifyAdminAccess(user = adminAuth.currentUser) {
  if (!user) {
    return { authorized: false, reason: 'not-authenticated', profile: null };
  }

  const profile = await currentAdminProfile(user);

  if (!profile) {
    return { authorized: false, reason: 'admin-document-not-found', profile: null };
  }

  if (profile.active === false) {
    return { authorized: false, reason: 'admin-disabled', profile };
  }

  if (!['owner', 'manager', 'support'].includes(profile.role)) {
    return { authorized: false, reason: 'admin-role-invalid', profile };
  }

  return { authorized: true, reason: 'authorized', profile };
}

export function adminCollection(collectionName) {
  return collection(adminDb, collectionName);
}

export function adminDocument(collectionName, documentId) {
  return doc(adminDb, collectionName, documentId);
}

export async function getAdminDocument(collectionName, documentId) {
  const snap = await getDoc(adminDocument(collectionName, documentId));
  return snap.exists() ? { id: snap.id, ...snap.data() } : null;
}

/* -----------------------------
 * Safe Firebase error messages
 * ----------------------------- */
export function firebaseErrorMessage(error) {
  if (!error) return 'حدث خطأ غير معروف.';

  const code = error.code || '';
  const messages = {
    'auth/api-key-not-valid': 'مفتاح Firebase API غير صالح. تحقق من إعدادات Firebase Web App.',
    'auth/invalid-api-key': 'مفتاح Firebase API غير صالح.',
    'auth/invalid-credential': 'البريد الإلكتروني أو كلمة المرور غير صحيحة.',
    'auth/invalid-email': 'صيغة البريد الإلكتروني غير صحيحة.',
    'auth/user-disabled': 'تم تعطيل هذا الحساب.',
    'auth/user-not-found': 'لم يتم العثور على هذا الحساب.',
    'auth/wrong-password': 'كلمة المرور غير صحيحة.',
    'auth/email-already-in-use': 'هذا البريد الإلكتروني مستخدم بالفعل.',
    'auth/weak-password': 'كلمة المرور ضعيفة جدًا.',
    'auth/too-many-requests': 'تم تجاوز عدد المحاولات. حاول مرة أخرى لاحقًا.',
    'auth/network-request-failed': 'تعذر الاتصال بخدمة Firebase. تحقق من الإنترنت.',
    'permission-denied': 'رفضت قواعد Firestore العملية. تحقق من صلاحيات الحساب ومستند admins/{UID}.',
    'failed-precondition': 'تعذر تنفيذ العملية بسبب إعداد أو فهرس مطلوب.',
    'unavailable': 'خدمة Firebase غير متاحة حاليًا. حاول مرة أخرى.'
  };

  return messages[code] || error.message || 'حدث خطأ أثناء تنفيذ العملية.';
}

export function isFirebaseConfigured() {
  return [
    'apiKey',
    'authDomain',
    'projectId',
    'appId',
    'messagingSenderId'
  ].every(key => typeof firebaseConfig[key] === 'string' && firebaseConfig[key].trim());
}

export default {
  firebaseConfig,
  app,
  auth,
  db,
  customerDb,
  adminApp,
  adminAuth,
  adminDb,
  firebase,
  currentUserProfile,
  ensureUserDocument,
  currentAdminProfile,
  verifyAdminAccess,
  adminCollection,
  adminDocument,
  getAdminDocument,
  firebaseErrorMessage,
  isFirebaseConfigured
};
