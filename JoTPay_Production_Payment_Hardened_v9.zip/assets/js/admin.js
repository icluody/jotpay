import { adminAuth, adminDb, firebase } from './firebase.js';
import { uploadImage } from './cloudinary.js';

const {
  onAuthStateChanged, signInWithEmailAndPassword, signOut,
  doc, getDoc, getDocs, collection, addDoc, setDoc, updateDoc, deleteDoc,
  serverTimestamp, query, where, limit, runTransaction, onSnapshot
} = firebase;

const $ = id => document.getElementById(id);
const esc = v => String(v ?? '').replace(/[&<>"']/g, c => ({ '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;' }[c]));
const attr = esc;
const date = v => v?.seconds ? new Date(v.seconds * 1000).toLocaleString('ar') : v ? new Date(v).toLocaleString('ar') : '—';
const money = (v, c='USD') => `${c==='USD'||c==='$'?'$':esc(c)}${Number(v || 0).toFixed(2)}`;
const safeUrl = value => { const raw=String(value||'').trim(); if(!raw) return ''; if(raw.startsWith('/')) return raw; try{const u=new URL(raw,location.origin);return ['https:','http:'].includes(u.protocol)?u.href:'';}catch{return '';} };

const ROLE_NAMES = { owner:'Owner — المالك', manager:'Manager — مدير', support:'Support — دعم' };
const BANNER_LANGS=[['ar','العربية'],['en','English'],['fr','Français'],['es','Español'],['de','Deutsch'],['tr','Türkçe'],['pt','Português'],['ru','Русский'],['zh','中文'],['ja','日本語'],['ko','한국어'],['it','Italiano'],['id','Bahasa Indonesia'],['hi','हिन्दी'],['ur','اردو'],['nl','Nederlands'],['pl','Polski'],['fa','فارسی']];
const CANONICAL_CATEGORIES = [
  { id:'top-up', name:'شحن عملات', type:'primary', parentId:'', active:true, sortOrder:10 },
  { id:'cards-subscriptions', name:'بطاقات واشتراكات', type:'primary', parentId:'', active:true, sortOrder:20 },
  { id:'followers', name:'شراء متابعين', type:'primary', parentId:'', active:true, sortOrder:30 },
  { id:'accounts', name:'شراء حسابات', type:'primary', parentId:'', active:true, sortOrder:40 }
];
const DEFAULT_SUBCATEGORIES = [
  {id:'top-up-all',name:'الكل',type:'secondary',parentId:'top-up',sortOrder:0,active:true},
  {id:'top-up-games',name:'ألعاب',type:'secondary',parentId:'top-up',sortOrder:10,active:true},
  {id:'top-up-live',name:'بث مباشر',type:'secondary',parentId:'top-up',sortOrder:20,active:true},
  {id:'top-up-voice',name:'غرف صوتية',type:'secondary',parentId:'top-up',sortOrder:30,active:true},
  {id:'top-up-other',name:'أخرى',type:'secondary',parentId:'top-up',sortOrder:40,active:true},
  {id:'cards-all',name:'الكل',type:'secondary',parentId:'cards-subscriptions',sortOrder:0,active:true},
  {id:'cards',name:'بطاقات',type:'secondary',parentId:'cards-subscriptions',sortOrder:10,active:true},
  {id:'subscriptions',name:'اشتراكات',type:'secondary',parentId:'cards-subscriptions',sortOrder:20,active:true},
  {id:'followers-all',name:'الكل',type:'secondary',parentId:'followers',sortOrder:0,active:true},
  {id:'followers-facebook',name:'فيسبوك',type:'secondary',parentId:'followers',sortOrder:10,active:true},
  {id:'followers-whatsapp',name:'واتساب',type:'secondary',parentId:'followers',sortOrder:20,active:true},
  {id:'followers-youtube',name:'يوتيوب',type:'secondary',parentId:'followers',sortOrder:30,active:true},
  {id:'followers-instagram',name:'إنستاجرام',type:'secondary',parentId:'followers',sortOrder:40,active:true},
  {id:'followers-tiktok',name:'تيك توك',type:'secondary',parentId:'followers',sortOrder:50,active:true},
  {id:'followers-wechat',name:'وي شات',type:'secondary',parentId:'followers',sortOrder:60,active:true},
  {id:'followers-telegram',name:'تيليجرام',type:'secondary',parentId:'followers',sortOrder:70,active:true},
  {id:'followers-snapchat',name:'سناب شات',type:'secondary',parentId:'followers',sortOrder:80,active:true},
  {id:'followers-x',name:'إكس / تويتر',type:'secondary',parentId:'followers',sortOrder:90,active:true},
  {id:'followers-reddit',name:'ريديت',type:'secondary',parentId:'followers',sortOrder:100,active:true},
  {id:'followers-linkedin',name:'لينكد إن',type:'secondary',parentId:'followers',sortOrder:110,active:true},
  {id:'followers-threads',name:'ثريدز',type:'secondary',parentId:'followers',sortOrder:120,active:true},
  {id:'followers-pinterest',name:'بينترست',type:'secondary',parentId:'followers',sortOrder:130,active:true},
  {id:'followers-discord',name:'ديسكورد',type:'secondary',parentId:'followers',sortOrder:140,active:true},
  {id:'followers-twitch',name:'تويتش',type:'secondary',parentId:'followers',sortOrder:150,active:true},
  {id:'followers-other',name:'أخرى',type:'secondary',parentId:'followers',sortOrder:160,active:true},
  {id:'accounts-all',name:'الكل',type:'secondary',parentId:'accounts',sortOrder:0,active:true},
  {id:'accounts-facebook',name:'فيسبوك',type:'secondary',parentId:'accounts',sortOrder:10,active:true},
  {id:'accounts-whatsapp',name:'واتساب',type:'secondary',parentId:'accounts',sortOrder:20,active:true},
  {id:'accounts-youtube',name:'يوتيوب',type:'secondary',parentId:'accounts',sortOrder:30,active:true},
  {id:'accounts-instagram',name:'إنستاجرام',type:'secondary',parentId:'accounts',sortOrder:40,active:true},
  {id:'accounts-tiktok',name:'تيك توك',type:'secondary',parentId:'accounts',sortOrder:50,active:true},
  {id:'accounts-wechat',name:'وي شات',type:'secondary',parentId:'accounts',sortOrder:60,active:true},
  {id:'accounts-telegram',name:'تيليجرام',type:'secondary',parentId:'accounts',sortOrder:70,active:true},
  {id:'accounts-snapchat',name:'سناب شات',type:'secondary',parentId:'accounts',sortOrder:80,active:true},
  {id:'accounts-x',name:'إكس / تويتر',type:'secondary',parentId:'accounts',sortOrder:90,active:true},
  {id:'accounts-reddit',name:'ريديت',type:'secondary',parentId:'accounts',sortOrder:100,active:true},
  {id:'accounts-linkedin',name:'لينكد إن',type:'secondary',parentId:'accounts',sortOrder:110,active:true},
  {id:'accounts-threads',name:'ثريدز',type:'secondary',parentId:'accounts',sortOrder:120,active:true},
  {id:'accounts-pinterest',name:'بينترست',type:'secondary',parentId:'accounts',sortOrder:130,active:true},
  {id:'accounts-discord',name:'ديسكورد',type:'secondary',parentId:'accounts',sortOrder:140,active:true},
  {id:'accounts-twitch',name:'تويتش',type:'secondary',parentId:'accounts',sortOrder:150,active:true},
  {id:'accounts-other',name:'أخرى',type:'secondary',parentId:'accounts',sortOrder:160,active:true}
];
const ALL_DEFAULT_CATEGORIES=[...CANONICAL_CATEGORIES,...DEFAULT_SUBCATEGORIES];
const PRIMARY_IDS=new Set(CANONICAL_CATEGORIES.map(c=>c.id));
const DEFAULT_LOGIN_BANNER = {
  tag:'مكافأة أول تسجيل دخول',
  title:'زيادة 30% على قيمة الشحن لأول مرة',
  description:'عند تسجيل الدخول لأول مرة إلى JoTPay، تظهر لك مكافأة زيادة 30% على قيمة الشحن وفق العرض المنشور.',
  bonusPercent:30,
  audience:'first-login',
  active:true
};
const DEFAULT_PRICE_PRESETS = [9.99, 19.99, 49.99, 99.99, 199.99, 499.99, 999.99];

const perms = {
  owner:['dashboard','products','categories','banners','orders','users','notifications','deposits','admins','settings','audit','support','market'],
  manager:['dashboard','products','categories','banners','orders','users','notifications','deposits','audit','support','market'],
  support:['dashboard','orders','users','support']
};
let state = { categories:[], products:[], banners:[], orders:[], users:[], admins:[], audit:[], tickets:[], accountListings:[], deposits:[], loginBanner:null, settings:null };
let me = null;
let activeView = 'dashboard';
let ordersUnsub=null;

function toast(msg, type='ok') {
  const t=$('toast'); if(!t) return;
  t.textContent=msg; t.className=`toast ${type}`;
  clearTimeout(window.__jotpayToast); window.__jotpayToast=setTimeout(()=>{t.className='toast hidden'},4000);
}

function friendlyError(error) {
  const code=error?.code||'';
  const messages={
    'permission-denied':'رفضت قواعد Firestore العملية. تأكد أن الحساب موجود في admins وأن دوره صحيح.',
    'unauthenticated':'انتهت جلسة الإدارة. سجّل الدخول مجدداً.',
    'failed-precondition':'قاعدة Firestore تحتاج إعداداً إضافياً أو فهرساً غير متاح.',
    'unavailable':'تعذر الاتصال بـ Firebase حالياً. تحقق من الإنترنت.',
    'network-request-failed':'تعذر الاتصال بالشبكة.',
    'auth/invalid-credential':'البريد الإلكتروني أو كلمة المرور غير صحيحة.',
    'auth/invalid-email':'صيغة البريد الإلكتروني غير صحيحة.',
    'auth/too-many-requests':'محاولات دخول كثيرة. حاول لاحقاً.',
    'auth/network-request-failed':'تعذر الوصول إلى Firebase Authentication.',
    'auth/operation-not-allowed':'فعّل Email/Password من Firebase Authentication.',
    'auth/user-disabled':'حساب Firebase Authentication معطّل.',
    'auth/user-not-found':'لا يوجد حساب بهذا البريد الإلكتروني.'
  };
  return messages[code] || error?.message || 'حدث خطأ غير متوقع.';
}

function showLogin() { $('login-view').classList.remove('hidden'); $('admin-app').classList.add('hidden'); }
function showApp() { $('login-view').classList.add('hidden'); $('admin-app').classList.remove('hidden'); }
function can(view) { return (perms[me?.role] || []).includes(view); }

async function getMe(user) {
  const snap=await getDoc(doc(adminDb,'admins',user.uid));
  if(!snap.exists()) { const e=new Error('تم تسجيل الدخول بنجاح، لكن الحساب غير مسجّل كمدير في Firestore: admins/'+user.uid); e.code='admin-record-missing'; throw e; }
  if(snap.data().active===false) { const e=new Error('حساب الإدارة معطّل حالياً.'); e.code='admin-disabled'; throw e; }
  if(!['owner','manager','support'].includes(snap.data().role)) { const e=new Error('دور حساب الإدارة غير صالح.'); e.code='admin-role-invalid'; throw e; }
  return { id:snap.id, ...snap.data() };
}

async function read(name,max=500) {
  const snap=await getDocs(query(collection(adminDb,name),limit(max)));
  return snap.docs.map(d=>({id:d.id,...d.data()}));
}

async function writeAudit(action,target,targetId,details={}) {
  if(!me) return;
  try { await addDoc(collection(adminDb,'auditLogs'),{adminId:me.id,adminEmail:adminAuth.currentUser?.email||'',role:me.role,action,target,targetId:String(targetId||''),details,createdAt:serverTimestamp()}); }
  catch(e){ console.warn('Audit log failed',e); }
}

async function notifyUser(userId,title,message,type='info',referenceId='') {
  if(!userId || !can('users')) return;
  try { await addDoc(collection(adminDb,'notifications'),{userId,title,message,type,referenceId,createdBy:me.id,read:false,createdAt:serverTimestamp()}); }
  catch(e){ console.warn('Notification failed',e); }
}

function subscribeOrders(){ordersUnsub?.();ordersUnsub=onSnapshot(query(collection(adminDb,'orders'),orderBy('createdAt','desc'),limit(500)),snap=>{state.orders=snap.docs.map(d=>({id:d.id,...d.data()}));if(activeView==='orders'||activeView==='dashboard'){render(activeView);}},err=>console.warn('Admin orders listener failed',err));}

async function loadAll() {
  const role=me?.role||'support';
  const names=role==='support' ? ['orders','users','supportTickets'] : ['categories','products','banners','orders','users','supportTickets','accountListings','depositRequests'];
  if(role==='owner') names.push('admins');
  if(role==='owner'||role==='manager') names.push('auditLogs');
  const results=await Promise.allSettled(names.map(n=>read(n)));
  names.forEach((n,i)=>{const key=n==='supportTickets'?'tickets':n==='auditLogs'?'audit':n;state[key]=results[i].status==='fulfilled'?results[i].value:[];});
  if(role==='support'){state.categories=[];state.products=[];state.banners=[];state.admins=[];state.audit=[];state.accountListings=[];state.deposits=[];}
  // Preserve every existing category/product. Never discard custom or legacy records from the admin view.
  state.categories = state.categories.map(c => ({...c, active:c.active !== false}));
  state.products = state.products.map(p => ({...p}));
  const [lb,store]=await Promise.allSettled([getDoc(doc(adminDb,'settings','loginBanner')),getDoc(doc(adminDb,'settings','store'))]);
  state.loginBanner = lb.status==='fulfilled' && lb.value.exists()
    ? {id:lb.value.id,...DEFAULT_LOGIN_BANNER,...lb.value.data()}
    : {id:'loginBanner',...DEFAULT_LOGIN_BANNER};
  state.settings=store.status==='fulfilled'&&store.value.exists()?{id:store.value.id,...store.value.data()}:null;
  if(results.some(r=>r.status==='rejected')||lb.status==='rejected'||store.status==='rejected') toast('تم تحميل لوحة الإدارة جزئياً. توجد مجموعة بيانات لم تُحمّل، افحص الاتصال وقواعد Firestore.','error');
}

async function ensureSystemDefaults() {
  if(me?.role!=='owner') return;
  const allDefault=ALL_DEFAULT_CATEGORIES;
  const snaps=await Promise.all(allDefault.map(c=>getDoc(doc(adminDb,'categories',c.id))));
  for(let i=0;i<allDefault.length;i++){
    const c=allDefault[i],snap=snaps[i];
    if(!snap.exists()) await setDoc(doc(adminDb,'categories',c.id),{...c,createdAt:serverTimestamp(),updatedAt:serverTimestamp()});
    else await updateDoc(doc(adminDb,'categories',c.id),{name:c.name,type:c.type,parentId:c.parentId,sortOrder:c.sortOrder,active:snap.data().active!==false,updatedAt:serverTimestamp()});
  }
  const catSnap=await getDocs(query(collection(adminDb,'categories'),limit(1000)));
  const known=new Set(allDefault.map(c=>c.id));
  const validParents=new Set(CANONICAL_CATEGORIES.map(c=>c.id));
  const legacy=catSnap.docs.map(d=>({id:d.id,...d.data()})).filter(c=>!known.has(c.id));
  const productSnap=await getDocs(query(collection(adminDb,'products'),limit(1000)));
  const findSection=(category)=>{
    if(validParents.has(String(category?.parentId||''))) return String(category.parentId);
    const n=String(category?.name||'').toLowerCase();
    if(/متابع|followers|instagram|tiktok|youtube|facebook|telegram|snap|reddit|linkedin|threads|pinterest|discord|twitch|whatsapp|wechat|إكس|تويتر/.test(n)) return 'followers';
    if(/حساب|account/.test(n)) return 'accounts';
    if(/بطاق|اشتراك|card|subscription/.test(n)) return 'cards-subscriptions';
    return 'top-up';
  };
  const defaultFor={ 'top-up':'top-up-games','cards-subscriptions':'cards','followers':'followers-instagram','accounts':'accounts-other' };
  const categoryMap=new Map(catSnap.docs.map(d=>[d.id,{id:d.id,...d.data()}]));
  for(const p of productSnap.docs){
    const data=p.data(); const raw=String(data.categoryId||'');
    let section=String(data.sectionId||'');
    if(!PRIMARY_IDS.has(section)){ const c=categoryMap.get(raw); section=PRIMARY_IDS.has(raw)?raw:findSection(c||{name:data.platform||''}); }
    let category=raw;
    const knownSub=categoryMap.get(category);
    if(category.endsWith('-all')) category='';
    if(!(knownSub?.type==='secondary'&&PRIMARY_IDS.has(String(knownSub.parentId||'')) && !category.endsWith('-all'))) category=defaultFor[section]||'top-up-games';
    const patch={sectionId:section,categoryId:category,updatedAt:serverTimestamp()};
    if(data.categoryId!==category||data.sectionId!==section) await updateDoc(doc(adminDb,'products',p.id),patch);
  }
  // Existing non-canonical categories are preserved; never deactivate or rewrite them here.
  const storeRef=doc(adminDb,'settings','store'),storeSnap=await getDoc(storeRef);
  if(!storeSnap.exists()) await setDoc(storeRef,{storeName:'JoTPay',currency:'$',supportEmail:'',maintenance:false,maintenanceMessage:'',pricePresets:DEFAULT_PRICE_PRESETS,updatedAt:serverTimestamp()});
  else { const storeData=storeSnap.data()||{},patch={}; if(String(storeData.currency||'').toUpperCase()==='USD') patch.currency='$'; if(!Array.isArray(storeData.pricePresets)||!storeData.pricePresets.length) patch.pricePresets=DEFAULT_PRICE_PRESETS; if(Object.keys(patch).length){patch.updatedAt=serverTimestamp();await updateDoc(storeRef,patch);} }
  const bannerRef=doc(adminDb,'settings','loginBanner'),bannerSnap=await getDoc(bannerRef);
  if(!bannerSnap.exists()) await setDoc(bannerRef,{...DEFAULT_LOGIN_BANNER,updatedAt:serverTimestamp()});
  else { const existing=bannerSnap.data()||{},patch={}; if(!existing.tag)patch.tag=DEFAULT_LOGIN_BANNER.tag;if(!existing.title)patch.title=DEFAULT_LOGIN_BANNER.title;if(!existing.description)patch.description=DEFAULT_LOGIN_BANNER.description;if(Number.isNaN(Number(existing.bonusPercent)))patch.bonusPercent=30;if(!existing.audience)patch.audience='first-login';if(existing.active===undefined)patch.active=true;if(Object.keys(patch).length){patch.updatedAt=serverTimestamp();await updateDoc(bannerRef,patch);} }
}
function render(view) {
  if(!can(view)){toast('ليست لديك صلاحية لهذه الصفحة.','error');return;}
  document.querySelectorAll('.view').forEach(x=>x.classList.add('hidden'));
  $(view)?.classList.remove('hidden');
  const funcs={dashboard,products,categories,banners,orders,users,notifications,deposits,admins,settings,audit:auditView,support,market};
  funcs[view]?.();
  activeView=view;
  document.querySelectorAll('.nav').forEach(b=>b.classList.toggle('active',b.dataset.view===view));
  const titles={dashboard:'الرئيسية',products:'الخدمات',categories:'التصنيفات',banners:'العروض والبنرات',orders:'الطلبات',users:'المستخدمون',notifications:'الإشعارات',deposits:'شحن الرصيد',admins:'المديرون',settings:'الإعدادات',audit:'سجل التدقيق',support:'الدعم',market:'سوق الحسابات'};
  $('view-title').textContent=titles[view]||view;
}

function dashboard(){
  const revenue=state.orders.filter(o=>o.status==='completed').reduce((sum,o)=>sum+Number(o.total||0),0);
  const newOrders=state.orders.filter(o=>String(o.status||'pending')==='pending').length;
  $('dashboard').innerHTML=`<div class="stats"><div class="stat"><small>الخدمات النشطة</small><strong>${state.products.filter(x=>x.active!==false).length}</strong></div><div class="stat"><small>التصنيفات النشطة</small><strong>${state.categories.filter(x=>x.active!==false).length}</strong></div><div class="stat"><small>الطلبات</small><strong>${state.orders.length}</strong></div><div class="stat"><small>طلبات جديدة</small><strong>${newOrders}</strong></div><div class="stat"><small>إجمالي الطلبات المكتملة</small><strong>$${revenue.toFixed(2)}</strong></div></div><div class="grid2"><div class="panel"><div class="panel-head"><div><h3>آخر الطلبات</h3><p class="muted">آخر عمليات الطلب المسجلة في Firestore.</p></div><button class="toolbar-btn" data-action="view" data-view-target="orders">عرض الكل</button></div>${ordersTable([...state.orders].sort((a,b)=>(b.createdAt?.seconds||0)-(a.createdAt?.seconds||0)).slice(0,8))}</div><div class="panel"><div class="panel-head"><div><h3>حالة المتجر</h3><p class="muted">الإعدادات الفعلية الحالية.</p></div></div><div class="status-box"><b>${esc(state.settings?.storeName||'JoTPay')}</b><span>${state.settings?.maintenance?'وضع الصيانة مفعّل':'المتجر يعمل'}</span><span>العملة: $</span><span>الدعم: ${esc(state.settings?.supportEmail||'غير محدد')}</span><span>الأسعار المحفوظة: ${(state.settings?.pricePresets||DEFAULT_PRICE_PRESETS).length}</span></div></div></div>`;
}

function ordersTable(rows){
  if(!rows.length)return'<div class="empty">لا توجد بيانات.</div>';
  return`<div class="table-wrap"><table><thead><tr><th>الطلب</th><th>العميل</th><th>الخدمة</th><th>الإجمالي</th><th>الحالة</th><th>الدفع</th><th>التاريخ</th><th></th></tr></thead><tbody>${rows.map(o=>`<tr><td dir="ltr">${esc(o.id.slice(0,12))}</td><td dir="ltr">${esc(o.customerEmail||'—')}</td><td>${esc(o.productName)}</td><td>${money(o.total,o.currency)}</td><td><span class="status ${esc(o.status||'pending')}">${esc(statusName(o.status))}</span></td><td>${esc(o.paymentStatus||'unpaid')}</td><td>${esc(date(o.createdAt))}</td><td><button class="icon-btn" data-action="edit-order" data-id="${attr(o.id)}" title="تعديل"><i class="fa-solid fa-pen"></i></button></td></tr>`).join('')}</tbody></table></div>`;
}
function statusName(s){return{pending:'قيد الانتظار',processing:'قيد المعالجة',completed:'مكتمل',cancelled:'ملغي',refunded:'مسترد'}[s]||s||'—';}

function products(){
  const canWrite=can('products');
  const primary=CANONICAL_CATEGORIES;
  $('products').innerHTML=`<div class="panel"><div class="panel-head"><div><h3>الخدمات</h3><p class="muted">النشر الاحترافي يبدأ من القسم ثم التصنيف، مع صورة Cloudinary وسعر وحالة نشر واضحة.</p></div>${canWrite?'<button class="primary-small" data-action="add-product">+ إضافة خدمة</button>':''}</div><div class="admin-product-filters"><input id="admin-product-search" placeholder="ابحث باسم الخدمة أو المنصة…"><select id="admin-product-section"><option value="">كل الأقسام</option>${primary.map(c=>`<option value="${attr(c.id)}">${esc(c.name)}</option>`).join('')}</select><select id="admin-product-category"><option value="">كل التصنيفات</option>${state.categories.filter(c=>c.type==='secondary').map(c=>`<option value="${attr(c.id)}">${esc(c.name)}</option>`).join('')}</select><select id="admin-product-status"><option value="">كل الحالات</option><option value="active">منشور</option><option value="draft">مسودة</option></select></div><div id="admin-products-table"></div></div>`;
  const draw=()=>{const q=($('admin-product-search')?.value||'').trim().toLowerCase(),sec=$('admin-product-section')?.value||'',cat=$('admin-product-category')?.value||'',status=$('admin-product-status')?.value||'';const selectedCat=cat;const catIsAll=selectedCat.endsWith('-all');const rows=state.products.filter(p=>(!q||`${p.name||''} ${p.platform||''} ${p.description||''}`.toLowerCase().includes(q))&&(!sec||p.sectionId===sec)&&(!selectedCat||(catIsAll?p.sectionId===selectedCat.replace(/-all$/,''):p.categoryId===selectedCat))&&(!status||(status==='active'?p.active!==false:p.active===false)));$('admin-products-table').innerHTML=rows.length?`<div class="table-wrap"><table><thead><tr><th>الصورة</th><th>الاسم</th><th>القسم / التصنيف</th><th>السعر</th><th>التقييم</th><th>النشر</th><th>مميز</th><th></th></tr></thead><tbody>${rows.map(p=>`<tr><td>${p.image?`<img class="thumb" src="${attr(safeUrl(p.image))}" alt="" loading="lazy">`:'—'}</td><td><b>${esc(p.name)}</b><small class="muted" style="display:block">${esc(p.platform||'')}</small></td><td>${esc((state.categories.find(c=>c.id===p.sectionId)?.name)||'—')}<small class="muted" style="display:block">${esc((state.categories.find(c=>c.id===p.categoryId)?.name)||'—')}</small></td><td>${money(p.price,p.currency)}</td><td>★ ${Number(p.rating??5).toFixed(1)}</td><td>${p.active===false?'مسودة':'منشور'}</td><td>${p.featured?'نعم':'لا'}</td><td class="actions">${canWrite?`<button class="icon-btn" data-action="edit-product" data-id="${attr(p.id)}"><i class="fa-solid fa-pen"></i></button><button class="icon-btn danger" data-action="delete-product" data-id="${attr(p.id)}"><i class="fa-solid fa-trash"></i></button>`:''}</td></tr>`).join('')}</tbody></table></div>`:'<div class="empty">لا توجد خدمات مطابقة للفلاتر الحالية.</div>';};['admin-product-search','admin-product-section','admin-product-category','admin-product-status'].forEach(id=>$(id)?.addEventListener('input',draw));draw();
}

function categories(){
  const canWrite=can('categories');
  const primary=CANONICAL_CATEGORIES.map(base=>state.categories.find(x=>x.id===base.id)||base).sort((a,b)=>Number(a.sortOrder||9999)-Number(b.sortOrder||9999));
  const secondary=state.categories.filter(c=>c.type==='secondary'&&PRIMARY_IDS.has(String(c.parentId||''))).sort((a,b)=>String(a.parentId).localeCompare(String(b.parentId))||Number(a.sortOrder||9999)-Number(b.sortOrder||9999));
  $('categories').innerHTML=`<div class="panel"><div class="panel-head"><div><h3>الأقسام والتصنيفات</h3><p class="muted">أربعة أقسام رئيسية ثابتة، وتحت كل قسم تصنيفات واضحة. يمكن للمالك والمدير إدارة التصنيفات الإضافية دون إنشاء قسم رئيسي جديد.</p></div><span class="muted">4 أقسام رئيسية</span></div><div class="category-admin-grid">${primary.map(c=>`<div class="category-admin-card"><div class="category-admin-head"><div><b>${esc(c.name)}</b><small>${secondary.filter(x=>x.parentId===c.id).length} تصنيف</small></div>${canWrite?`<button class="icon-btn" data-action="edit-category" data-id="${attr(c.id)}"><i class="fa-solid fa-pen"></i></button>`:''}</div><div class="category-admin-chips">${secondary.filter(x=>x.parentId===c.id).map(x=>`<span class="admin-chip ${x.active===false?'muted-chip':''}">${esc(x.name)}${canWrite&&!x.id.endsWith('-all')?`<button type="button" data-action="edit-subcategory" data-id="${attr(x.id)}" aria-label="تعديل"><i class="fa-solid fa-pen"></i></button>`:''}</span>`).join('')||'<span class="muted">لا توجد تصنيفات</span>'}</div>${canWrite?`<button class="toolbar-btn" data-action="add-subcategory" data-parent="${attr(c.id)}">+ إضافة تصنيف</button>`:''}</div>`).join('')}</div></div>`;
}

function secondaryCategoryForm(id,parentId){
  if(!can('categories'))return; const existing=state.categories.find(x=>x.id===id)||{}; if(existing.id?.endsWith('-all')){toast('تصنيف «الكل» نظامي ولا يمكن تعديله.','error');return;} const parent=CANONICAL_CATEGORIES.find(x=>x.id===(parentId||existing.parentId)); if(!parent)return;
  openModal(modalShell(id?'تعديل تصنيف':'إضافة تصنيف',`<form id="editor-form" class="form-stack"><div class="notice info">القسم الرئيسي: <b>${esc(parent.name)}</b></div>${id?`<label>المعرّف</label><input readonly dir="ltr" value="${attr(existing.id)}">`:''}<label>اسم التصنيف *</label><input id="f-name" required maxlength=80 value="${attr(existing.name||'')}" placeholder="مثال: Netflix"><label>الترتيب</label><input id="f-sort" type="number" min="0" value="${attr(existing.sortOrder??100)}"><label class="switch"><input id="f-active" type="checkbox" ${existing.active!==false?'checked':''}> ظاهر للعملاء</label><button class="primary-btn" type="submit">حفظ التصنيف</button></form>`),async e=>{e.preventDefault();try{const name=$('f-name').value.trim();if(!name)throw new Error('اسم التصنيف مطلوب.');const sort=Math.max(0,Math.floor(Number($('f-sort').value||100)));const cid=id||`${parent.id}-${name.toLowerCase().replace(/[^a-z0-9]+/g,'-').replace(/^-|-$/g,'')||Date.now()}`;const data={name,type:'secondary',parentId:parent.id,sortOrder:sort,active:$('f-active').checked,updatedAt:serverTimestamp()};if(id)await updateDoc(doc(adminDb,'categories',cid),data);else await setDoc(doc(adminDb,'categories',cid),{...data,createdAt:serverTimestamp()});await writeAudit(id?'update':'create','categories',cid,{name,parentId:parent.id});$('editor-modal').remove();await loadAll();render('categories');toast('تم حفظ التصنيف.');}catch(error){toast(friendlyError(error),'error');}});
}

function banners(){
  const canWrite=can('banners');
  $('banners').innerHTML=`<div class="panel"><div class="panel-head"><div><h3>بانر تسجيل الدخول</h3><p class="muted">لا يتم عرض أي مكافأة أو نسبة للمستخدم إلا بعد نشرها من هنا.</p></div>${canWrite?'<button class="primary-small" data-action="edit-login-banner">تعديل</button>':''}</div><div class="banner-preview"><b>${esc(state.loginBanner?.title||'لا يوجد بانر منشور')}</b><span>${esc(state.loginBanner?.description||'')}</span><small>${state.loginBanner?.active===false?'مخفي':'نشط'} • ${Number(state.loginBanner?.bonusPercent??30)}%</small></div></div><div class="panel"><div class="panel-head"><div><h3>العروض والبنرات</h3><p class="muted">العروض المنشورة تظهر على الصفحة الرئيسية.</p></div>${canWrite?'<button class="primary-small" data-action="add-banner">+ إضافة عرض</button>':''}</div><div class="table-wrap"><table><thead><tr><th>الصورة</th><th>العنوان</th><th>الترتيب</th><th>الرابط</th><th>الحالة</th><th></th></tr></thead><tbody>${[...state.banners].sort((a,b)=>Number(a.sortOrder||9999)-Number(b.sortOrder||9999)).map(b=>`<tr><td>${b.image?`<img class="thumb" src="${attr(safeUrl(b.image))}" alt="">`:'—'}</td><td>${esc(b.title)}</td><td>${esc(b.sortOrder??9999)}</td><td dir="ltr">${esc(b.actionUrl||'—')}</td><td>${b.active===false?'مخفي':'منشور'}</td><td>${canWrite?`<button class="icon-btn" data-action="edit-banner" data-id="${attr(b.id)}"><i class="fa-solid fa-pen"></i></button><button class="icon-btn danger" data-action="delete-banner" data-id="${attr(b.id)}"><i class="fa-solid fa-trash"></i></button>`:''}</td></tr>`).join('')}</tbody></table></div></div>`;
}
function orders(){ $('orders').innerHTML=`<div class="panel"><div class="panel-head"><div><h3>الطلبات</h3><p class="muted">الطلبات الأحدث أولاً. تغيير الحالة ينعكس على حساب العميل.</p></div></div><div class="order-filters"><input id="admin-order-search" placeholder="بحث برقم الطلب أو البريد أو المنتج"><select id="admin-order-status"><option value="">كل الطلبات</option><option value="pending">الجديدة / قيد الانتظار</option><option value="processing">قيد المعالجة</option><option value="completed">مكتملة</option><option value="cancelled">ملغاة</option><option value="refunded">مستردة</option></select></div><div id="admin-orders-table"></div></div>`;const draw=()=>{const q=($('admin-order-search')?.value||'').trim().toLowerCase(),st=$('admin-order-status')?.value||'';const rows=[...state.orders].sort((a,b)=>(b.createdAt?.seconds||0)-(a.createdAt?.seconds||0)).filter(o=>(!st||o.status===st)&&(!q||`${o.id} ${o.customerEmail||''} ${o.productName||''}`.toLowerCase().includes(q)));$('admin-orders-table').innerHTML=ordersTable(rows)};['admin-order-search','admin-order-status'].forEach(id=>$(id)?.addEventListener('input',draw));draw(); }

function users(){
  const canWrite=me?.role==='owner'||me?.role==='manager';
  $('users').innerHTML=`<div class="panel"><div class="panel-head"><div><h3>المستخدمون</h3><p class="muted">الرصيد المالي لا يمكن تعديله إلا بواسطة المالك ويتم تسجيل التغيير في السجل.</p></div><span class="muted">${state.users.length} حساب</span></div><div class="table-wrap"><table><thead><tr><th>البريد</th><th>الاسم</th><th>الدور</th><th>الرصيد</th><th>التسجيل</th><th></th></tr></thead><tbody>${state.users.map(u=>`<tr><td dir="ltr">${esc(u.email)}</td><td>${esc(u.displayName||'—')}</td><td>${esc(u.role||'customer')}</td><td>${money(u.walletBalance,'USD')}</td><td>${esc(date(u.createdAt))}</td><td>${canWrite?`<button class="icon-btn" data-action="edit-user" data-id="${attr(u.id)}"><i class="fa-solid fa-pen"></i></button>`:''}</td></tr>`).join('')}</tbody></table></div></div>`;
}
function admins(){
  $('admins').innerHTML=`<div class="panel"><div class="panel-head"><div><h3>حسابات الإدارة</h3><p class="muted">لا يتم إنشاء حساب Firebase من هنا؛ أنشئ الحساب أولاً في Authentication ثم أضف UID ومنحه الدور.</p></div><button class="primary-small" data-action="add-admin">+ إضافة مدير</button></div><div class="table-wrap"><table><thead><tr><th>UID</th><th>البريد</th><th>الدور</th><th>الحالة</th><th></th></tr></thead><tbody>${state.admins.map(a=>`<tr><td dir="ltr">${esc(a.id)}</td><td dir="ltr">${esc(a.email||'—')}</td><td>${esc(ROLE_NAMES[a.role]||a.role)}</td><td>${a.active===false?'معطّل':'نشط'}</td><td><button class="icon-btn" data-action="edit-admin" data-id="${attr(a.id)}"><i class="fa-solid fa-pen"></i></button></td></tr>`).join('')}</tbody></table></div></div>`;
}

function settings(){
  const presets=(state.settings?.pricePresets?.length?state.settings.pricePresets:DEFAULT_PRICE_PRESETS).map(Number).filter(Number.isFinite).sort((a,b)=>a-b);
  $('settings').innerHTML=`<div class="panel"><div class="panel-head"><div><h3>إعدادات المتجر</h3><p class="muted">المعلومات هنا هي مصدر الإعدادات العامة التي تقرؤها الواجهة.</p></div></div><form id="settings-form" class="form-grid"><div><label>اسم المتجر</label><input id="s-name" maxlength="80" value="${attr(state.settings?.storeName||'JoTPay')}"></div><div><label>العملة الافتراضية</label><input id="s-currency" maxlength="6" value="${attr((String(state.settings?.currency||'$').toUpperCase()==='USD'?'$':String(state.settings?.currency||'$')))}"></div><div><label>بريد الدعم</label><input id="s-support" type="email" dir="ltr" value="${attr(state.settings?.supportEmail||'')}"></div><div><label>رسالة الصيانة</label><input id="s-message" maxlength="240" value="${attr(state.settings?.maintenanceMessage||'')}"></div><div class="full"><label>قائمة الأسعار الأساسية</label><div class="price-presets" id="price-presets">${presets.map((v,i)=>`<div class="price-row"><span>${i+1}</span><input class="preset-input" type="number" min="0.01" step="0.01" value="${v.toFixed(2)}"><button type="button" class="icon-btn danger remove-price" title="حذف">×</button></div>`).join('')}</div><button type="button" class="toolbar-btn" id="add-price">+ إضافة سعر</button><p class="muted">القائمة الافتراضية: 9.99 / 19.99 / 49.99 / 99.99 / 199.99 / 499.99 / 999.99. يستطيع المالك تعديلها وإضافة أو حذف أسعار.</p></div><div class="full"><label>عنوان محفظة USDT-TRC20</label><input id="s-usdt" dir="ltr" maxlength=80 value="${attr(state.settings?.usdtAddress||'')}"><p class="muted">ضع عنوان محفظة حقيقي تملكه لاستقبال USDT. لا تضع مفتاحاً سرياً هنا.</p></div><div class="full"><label class="switch"><input id="s-maint" type="checkbox" ${state.settings?.maintenance?'checked':''}> وضع الصيانة</label></div><div class="full"><button class="primary-btn" id="settings-save" type="submit">حفظ الإعدادات والأسعار</button></div></form></div><div class="panel"><div class="panel-head"><h3>رفع الصور</h3></div><div id="cloudinary-status" class="info-box">جارٍ فحص خدمة رفع الصور…</div></div><div class="panel"><div class="panel-head"><h3>الدعم والمساعدة</h3></div><div class="info-box">يمكن للعملاء فتح تذاكر من صفحة الدعم، وتستطيع الإدارة الرد وإغلاق التذاكر من قسم الدعم.</div></div><div class="panel"><div class="panel-head"><h3>الدفع الحقيقي</h3></div><div class="info-box">لا توجد عملية دفع وهمية في الواجهة. الطلب الجديد يسجل كـ unpaid/pending حتى يتم ربط مزود دفع وخدمة تنفيذ حقيقية من الخادم.</div></div>`;
  const rows=$('price-presets');
  const bind=()=>rows.querySelectorAll('.remove-price').forEach(btn=>btn.onclick=()=>{if(rows.children.length<=1)return toast('يجب إبقاء سعر واحد على الأقل.','error');btn.parentElement.remove();[...rows.children].forEach((r,i)=>r.querySelector('span').textContent=i+1);});
  $('add-price').onclick=()=>{const d=document.createElement('div');d.className='price-row';d.innerHTML=`<span>${rows.children.length+1}</span><input class="preset-input" type="number" min="0.01" step="0.01" value="0.01"><button type="button" class="icon-btn danger remove-price">×</button>`;rows.appendChild(d);bind();};
  bind();
  fetch('/api/cloudinary-upload').then(r=>r.json()).then(x=>{
    $('cloudinary-status').textContent = x.configured && x.authConfigured ? 'خدمة Cloudinary والتحقق من الإدارة مكوّنان.' : x.configured ? 'Cloudinary مكوّن، لكن FIREBASE_SERVICE_ACCOUNT_JSON غير مضاف.' : 'أضف CLOUDINARY_URL وFIREBASE_SERVICE_ACCOUNT_JSON في Netlify.';
  }).catch(()=>{$('cloudinary-status').textContent='تعذر فحص خدمة رفع الصور.';});
  $('settings-form').onsubmit=async e=>{e.preventDefault();try{const vals=[...document.querySelectorAll('.preset-input')].map(x=>Number(x.value)).filter(v=>Number.isFinite(v)&&v>0);const pricePresets=[...new Set(vals)].sort((a,b)=>a-b);if(!pricePresets.length)throw new Error('يجب حفظ سعر واحد على الأقل.');const data={storeName:$('s-name').value.trim()||'JoTPay',currency:(($('s-currency').value.trim().toUpperCase()==='USD')?'$':($('s-currency').value.trim()||'$')),supportEmail:$('s-support').value.trim(),maintenance:$('s-maint').checked,maintenanceMessage:$('s-message').value.trim(),usdtAddress:$('s-usdt').value.trim(),pricePresets,updatedAt:serverTimestamp()};await setDoc(doc(adminDb,'settings','store'),data,{merge:true});await writeAudit('update','settings','store',{storeName:data.storeName,currency:data.currency,maintenance:data.maintenance,pricePresets});await loadAll();render('settings');toast('تم حفظ الإعدادات والأسعار.')}catch(error){toast(friendlyError(error),'error');}};
}

function notifications(){if(!can('notifications'))return;$('notifications').innerHTML=`<div class="panel"><div class="panel-head"><div><h3>إرسال إشعار</h3><p class="muted">إرسال فوري لكل المستخدمين أو لمستخدم محدد. لا تُستخدم إشعارات وهمية.</p></div></div><form id="notify-form" class="form-stack"><label>الجمهور<select id="n-audience"><option value="all">كل المستخدمين</option><option value="user">مستخدم محدد</option></select></label><label id="n-user-wrap" class="hidden">UID المستخدم<input id="n-user" dir="ltr" placeholder="Firebase UID"></label><label>العنوان<input id="n-title" maxlength="100" required></label><label>الرسالة<textarea id="n-message" maxlength="1000" required></textarea></label><label>النوع<select id="n-type"><option value="info">معلومة</option><option value="order">طلب</option><option value="wallet">المحفظة</option><option value="support">دعم</option></select></label><button class="primary-btn" type="submit">إرسال الإشعار</button><div id="n-result" class="notice hidden"></div></form></div>`;const aud=$('n-audience');aud.onchange=()=>$('n-user-wrap').classList.toggle('hidden',aud.value!=='user');$('notify-form').onsubmit=async e=>{e.preventDefault();const result=$('n-result');try{const title=$('n-title').value.trim(),message=$('n-message').value.trim(),type=$('n-type').value;if(aud.value==='user'){const uid=$('n-user').value.trim();if(!uid)throw new Error('UID المستخدم مطلوب.');await addDoc(collection(adminDb,'notifications'),{userId:uid,title,message,type,createdBy:me.id,read:false,createdAt:serverTimestamp()});await writeAudit('notification','users',uid,{title,type});result.textContent='تم إرسال الإشعار للمستخدم.';}else{const ref=await addDoc(collection(adminDb,'notificationBroadcasts'),{title,message,type,createdBy:me.id,read:false,createdAt:serverTimestamp(),active:true});await writeAudit('broadcast','notificationBroadcasts',ref.id,{title,type});result.textContent='تم نشر الإشعار لجميع المستخدمين.';}result.className='notice success';e.target.reset();$('n-user-wrap').classList.add('hidden')}catch(err){result.textContent=friendlyError(err);result.className='notice danger'}}}
function deposits(){if(!can('deposits'))return;$('deposits').innerHTML=`<div class="panel"><div class="panel-head"><div><h3>طلبات شحن الرصيد — USDT</h3><p class="muted">USDT-TRC20. يتم اعتماد الطلب بعد التحقق الفعلي من المعاملة. أول شحن مؤهل يحصل على مكافأة البانر المنشور.</p></div></div><div class="table-wrap"><table><thead><tr><th>المستخدم</th><th>المبلغ</th><th>TX</th><th>الحالة</th><th></th></tr></thead><tbody>${(state.deposits||[]).map(d=>`<tr><td dir="ltr">${esc(d.email||d.userId)}</td><td>${money(d.amount,d.currency||'USD')}</td><td dir="ltr"><a href="https://tronscan.org/#/transaction/${attr(d.txHash)}" target="_blank" rel="noopener">${esc(String(d.txHash).slice(0,16))}…</a></td><td>${esc(d.status||'pending')}</td><td>${d.status==='pending'?`<button class="primary-small" data-action="approve-deposit" data-id="${attr(d.id)}">اعتماد</button><button class="icon-btn danger" data-action="reject-deposit" data-id="${attr(d.id)}">رفض</button>`:'—'}</td></tr>`).join('')||'<tr><td colspan="5">لا توجد طلبات.</td></tr>'}</tbody></table></div></div>`}
async function approveDeposit(id){if(!can('deposits'))return;const d=(state.deposits||[]).find(x=>x.id===id);if(!d||d.status!=='pending')return;try{const uref=doc(adminDb,'users',d.userId),lref=doc(collection(adminDb,'walletLedger'));let credited=0,bonus=0;await runTransaction(adminDb,async tx=>{const us=await tx.get(uref);if(!us.exists())throw new Error('المستخدم غير موجود.');const u=us.data()||{},base=Number(d.amount||0);bonus=(u.firstWalletFundingBonusClaimed===true||state.loginBanner?.active===false)?0:Number(state.loginBanner?.bonusPercent??30);credited=Number((base+base*bonus/100).toFixed(2));const before=Number(u.walletBalance||0),after=Number((before+credited).toFixed(2));tx.update(uref,{walletBalance:after,firstWalletFundingBonusClaimed:true,updatedAt:serverTimestamp()});tx.update(doc(adminDb,'depositRequests',id),{status:'approved',creditedAmount:credited,bonusPercent:bonus,approvedBy:me.id,approvedAt:serverTimestamp(),updatedAt:serverTimestamp()});tx.set(lref,{userId:d.userId,type:'deposit',depositId:id,amount:credited,baseAmount:base,bonusAmount:credited-base,bonusPercent:bonus,balanceBefore:before,balanceAfter:after,adminId:me.id,createdAt:serverTimestamp()});});await notifyUser(d.userId,'تم شحن المحفظة',`تم اعتماد $${Number(d.amount).toFixed(2)} وإضافة $${credited.toFixed(2)} إلى محفظتك${bonus?` مع زيادة ${bonus}%`:''}.`,'wallet',id);await writeAudit('approve','depositRequests',id,{amount:d.amount,credited,bonus});await loadAll();render('deposits');toast('تم اعتماد الشحن وإضافة الرصيد.')}catch(e){toast(friendlyError(e),'error')}}
async function rejectDeposit(id){if(!can('deposits'))return;const reason=await promptAdminInput('سبب رفض طلب الشحن','سبب الرفض','اكتب سببًا واضحًا للعميل…');if(!reason)return;try{await updateDoc(doc(adminDb,'depositRequests',id),{status:'rejected',rejectReason:reason,updatedAt:serverTimestamp(),rejectedBy:me.id});const d=state.deposits.find(x=>x.id===id);if(d)await notifyUser(d.userId,'رفض طلب شحن الرصيد',`تم رفض طلب شحن USDT. السبب: ${reason}`,'wallet',id);await writeAudit('reject','depositRequests',id,{reason});await loadAll();render('deposits')}catch(e){toast(friendlyError(e),'error')}}
function auditView(){
  const rows=[...state.audit].sort((a,b)=>(b.createdAt?.seconds||0)-(a.createdAt?.seconds||0)).slice(0,300);
  $('audit').innerHTML=`<div class="panel"><div class="panel-head"><div><h3>سجل التدقيق</h3><p class="muted">سجل العمليات الإدارية الحديثة.</p></div></div>${rows.length?`<div class="table-wrap"><table><thead><tr><th>المدير</th><th>الدور</th><th>العملية</th><th>الهدف</th><th>التفاصيل</th><th>التاريخ</th></tr></thead><tbody>${rows.map(a=>`<tr><td dir="ltr">${esc(a.adminEmail||a.adminId)}</td><td>${esc(a.role)}</td><td>${esc(a.action)}</td><td>${esc(a.target)} / ${esc(a.targetId)}</td><td dir="ltr">${esc(JSON.stringify(a.details||{}))}</td><td>${esc(date(a.createdAt))}</td></tr>`).join('')}</tbody></table></div>`:'<div class="empty">لا توجد سجلات.</div>'}</div>`;
}
function market(){
  const canWrite=can('market');
  $('market').innerHTML=`<div class="panel"><div class="panel-head"><div><h3>طلبات عرض الحسابات الشخصية</h3><p class="muted">لا تُحفظ كلمات المرور أو مفاتيح الدخول هنا. هذه الطلبات مخصصة لمراجعة الملكية وحالة النقل قبل النشر.</p></div><span class="muted">${state.accountListings.length} طلب</span></div>${state.accountListings.length?`<div class="table-wrap"><table><thead><tr><th>المستخدم</th><th>اسم الحساب</th><th>المنصة</th><th>السعر</th><th>الحالة</th><th></th></tr></thead><tbody>${state.accountListings.map(x=>`<tr><td dir="ltr">${esc(x.userEmail||x.userId)}</td><td>${esc(x.accountName||'—')}</td><td>${esc(x.platform||'—')}</td><td>${money(x.price,x.currency||'USD')}</td><td>${esc(x.status||'pending')}</td><td>${canWrite?`<button class="icon-btn" data-action="edit-market" data-id="${attr(x.id)}"><i class="fa-solid fa-pen"></i></button>`:''}</td></tr>`).join('')}</tbody></table></div>`:'<div class="empty">لا توجد طلبات حسابات حالياً.</div>'}</div>`;
}
function support(){
  const canWrite=can('support');
  $('support').innerHTML=`<div class="panel"><div class="panel-head"><div><h3>طلبات الدعم</h3><p class="muted">الرد هنا يصل للعميل داخل الإشعارات ويظهر في تذكرته.</p></div><span class="muted">${state.tickets.length} تذكرة</span></div>${state.tickets.length?`<div class="table-wrap"><table><thead><tr><th>المستخدم</th><th>العنوان</th><th>الحالة</th><th>التاريخ</th><th></th></tr></thead><tbody>${state.tickets.map(t=>`<tr><td dir="ltr">${esc(t.userEmail||t.userId)}</td><td>${esc(t.subject||'بدون عنوان')}</td><td><span class="status ${esc(t.status||'open')}">${esc(t.status||'open')}</span></td><td>${esc(date(t.createdAt))}</td><td>${canWrite?`<button class="icon-btn" data-action="edit-ticket" data-id="${attr(t.id)}"><i class="fa-solid fa-pen"></i></button>`:''}</td></tr>`).join('')}</tbody></table></div>`:'<div class="empty">لا توجد تذاكر.</div>'}</div>`;
}

function openModal(html,onSubmit) {
  $('editor-modal')?.remove();
  document.body.insertAdjacentHTML('beforeend',html);
  const modal=$('editor-modal');
  $('editor-close')?.addEventListener('click',()=>modal.remove());
  modal?.addEventListener('click',e=>{if(e.target===modal)modal.remove();});
  $('editor-form')?.addEventListener('submit',onSubmit);
}

function modalShell(title, body){ return `<div class="modal" id="editor-modal"><div class="modal-card"><div class="modal-head"><h3>${esc(title)}</h3><button type="button" class="icon-btn" id="editor-close"><i class="fa-solid fa-xmark"></i></button></div>${body}</div></div>`; }
function adminSuccess(title,message,view='products'){const id='admin-success-modal';document.getElementById(id)?.remove();document.body.insertAdjacentHTML('beforeend',`<div class="modal" id="${id}"><div class="modal-card admin-success-card"><div class="success-icon"><i class="fa-solid fa-check"></i></div><h3>${esc(title)}</h3><p class="muted">${esc(message)}</p><div class="wizard-footer"><button class="toolbar-btn" data-close>إغلاق</button><button class="primary-small" data-view>عرض المنتج</button></div></div></div>`);const m=$(id);m.querySelector('[data-close]').onclick=()=>m.remove();m.querySelector('[data-view]').onclick=()=>{m.remove();render(view);};}
function confirmAdminAction(message){return new Promise(resolve=>{const id='admin-confirm-modal';document.getElementById(id)?.remove();document.body.insertAdjacentHTML('beforeend',`<div class="modal" id="${id}"><div class="modal-card admin-success-card"><h3>تأكيد العملية</h3><p class="muted">${esc(message)}</p><div class="wizard-footer"><button class="toolbar-btn" data-no>إلغاء</button><button class="primary-small" data-yes>تأكيد</button></div></div></div>`);const m=$(id);const finish=v=>{m.remove();resolve(v)};m.querySelector('[data-no]').onclick=()=>finish(false);m.querySelector('[data-yes]').onclick=()=>finish(true);});} 
function promptAdminInput(title,label,placeholder=''){
  return new Promise(resolve=>{
    const id='admin-input-modal';document.getElementById(id)?.remove();
    document.body.insertAdjacentHTML('beforeend',`<div class="modal" id="${id}"><div class="modal-card"><div class="modal-head"><h3>${esc(title)}</h3><button type="button" class="icon-btn" data-no aria-label="إغلاق">×</button></div><form class="form-stack" id="${id}-form"><label>${esc(label)}<textarea id="${id}-value" maxlength="500" required placeholder="${esc(placeholder)}"></textarea></label><div class="wizard-footer"><button type="button" class="toolbar-btn" data-no>إلغاء</button><button class="primary-small" type="submit">متابعة</button></div></form></div></div>`);
    const m=$(id),form=m.querySelector('form'),finish=v=>{m.remove();resolve(v)};
    m.querySelectorAll('[data-no]').forEach(b=>b.onclick=()=>finish(''));
    form.onsubmit=e=>{e.preventDefault();const value=$(id+'-value').value.trim();if(value)finish(value)};
    setTimeout(()=>$(id+'-value')?.focus(),30);
  });
}

function productForm(id){
  if(!can('products'))return;
  const p=state.products.find(x=>x.id===id)||{};
  const presets=(state.settings?.pricePresets?.length?state.settings.pricePresets:DEFAULT_PRICE_PRESETS).map(Number).filter(Number.isFinite).sort((a,b)=>a-b);
  const categories=state.categories.filter(c=>c.active!==false&&c.type==='secondary'&&String(c.parentId||''));
  const TOPUP_PRICES=[9.90,19.90,49.90,99.90,199.00,499.00,999.00], TOPUP_BONUSES=[0,3,5,7,10,15,20];
  let draft={
    name:String(p.name||''),description:String(p.description||''),platform:String(p.platform||''),unitLabel:String(p.unitLabel||''),inputType:String(p.inputType||''),sectionId:String(p.sectionId||'top-up'),categoryId:String(p.categoryId||''),currency:(String(p.currency||state.settings?.currency||'$').toUpperCase()==='USD'?'$':String(p.currency||state.settings?.currency||'$')),price:Number(p.price||presets[0]||9.99),image:String(p.image||''),rating:Number(p.rating??5),popularity:Number(p.popularity??0),sortOrder:Number(p.sortOrder??999),active:p.active!==false,featured:Boolean(p.featured),file:null,
    packs:Array.isArray(p.topupPackages)&&p.topupPackages.length===7?p.topupPackages.map((x,i)=>({...x,price:Number(x.price??TOPUP_PRICES[i]),bonusPercent:Number(x.bonusPercent??TOPUP_BONUSES[i]),baseQuantity:Number(x.baseQuantity??x.quantity??0),manual:Boolean(x.manualOverride)})):TOPUP_PRICES.map((price,i)=>({id:`pack-${i+1}`,price,bonusPercent:TOPUP_BONUSES[i],baseQuantity:i===0?1000:0,active:true,manual:false}))
  };
  if(draft.sectionId==='top-up')recalcPacks();
  function recalcPacks(){const first=Number(draft.packs[0]?.baseQuantity||0),basePrice=Number(draft.packs[0]?.price||9.9);draft.packs.forEach((x,i)=>{if(i>0&&!x.manual)x.baseQuantity=basePrice>0?Number((first*Number(x.price||0)/basePrice).toFixed(2)):0;x.finalQuantity=Number((Number(x.baseQuantity||0)*(1+Number(x.bonusPercent||0)/100)).toFixed(2));x.bonusQuantity=Number((x.finalQuantity-Number(x.baseQuantity||0)).toFixed(2));});}
  function stepContent(step){
    if(step===1)return `<div class="wizard-step"><h4>اختر نوع المنتج</h4><p class="muted">حدد نوع الخدمة أولاً لتظهر الإعدادات المناسبة فقط.</p><div class="wizard-choice-grid">${[['top-up','شحن عملات'],['cards-subscriptions','بطاقة / اشتراك'],['followers','متابعين'],['accounts','بيع حسابات']].map(([v,l])=>`<button type="button" class="wizard-choice ${draft.sectionId===v?'selected':''}" data-section-choice="${v}"><b>${l}</b><small>${v==='top-up'?'يتضمن 7 بطاقات شحن':v==='followers'?'خدمات المتابعين بالكمية والرابط':v==='accounts'?'منتج حساب واحد بدون كمية':'بطاقات أو اشتراكات تُباع كمنتج'}</small></button>`).join('')}</div></div>`;
    if(step===2)return `<div class="wizard-step"><h4>المعلومات الأساسية</h4><div class="form-grid"><div class="full"><label>اسم المنتج *</label><input id="w-name" maxlength="120" value="${attr(draft.name)}"></div><div class="full"><label>الوصف</label><textarea id="w-description" maxlength="1500">${esc(draft.description)}</textarea></div><div><label>المنصة / نوع الخدمة</label><input id="w-platform" maxlength="80" value="${attr(draft.platform)}"></div><div><label>وحدة الكمية</label><input id="w-unit" maxlength="60" value="${attr(draft.unitLabel)}" placeholder="Coins / Followers"></div></div></div>`;
    if(step===3){const subs=categories.filter(c=>c.parentId===draft.sectionId&&!c.id.endsWith('-all')).sort((a,b)=>Number(a.sortOrder||9999)-Number(b.sortOrder||9999));return `<div class="wizard-step"><h4>التصنيف</h4><p class="muted">اختر التصنيف الفعلي للمنتج. تصنيف «الكل» نظامي للعرض فقط ولا يُسند إلى المنتجات.</p><label>القسم الرئيسي</label><input readonly value="${attr(CANONICAL_CATEGORIES.find(c=>c.id===draft.sectionId)?.name||'')}"/><label>التصنيف الفرعي *</label><select id="w-category">${subs.map(c=>`<option value="${attr(c.id)}" ${c.id===draft.categoryId?'selected':''}>${esc(c.name)}</option>`).join('')} </select>${`<div class="form-grid" style="margin-top:12px"><div class="full"><label>نوع بيانات العميل المطلوبة</label><div class="input-type-choice-grid">${[['','بدون بيانات إضافية'],['Username','اسم المستخدم (Username)'],['ID','رقم المعرف (ID)'],['Number','الرقم / رقم الهاتف (Number)'],['Email','البريد الإلكتروني (Email)']].map(([v,l])=>`<label class="input-type-option"><input type="radio" name="w-input-type" value="${v}" ${draft.inputType===v?'checked':''}> <span>${l}</span></label>`).join('')}</div><small class="muted">اختر نوعًا واحدًا أو «بدون بيانات إضافية». يظهر للمستخدم الحقل المحدد فقط أثناء الشراء، ويمكن للبطاقات والاشتراكات تركه فارغًا.</small></div></div>`}</div>`;}
    if(step===4)return `<div class="wizard-step"><h4>الصورة</h4><div class="image-upload-box"><div class="image-preview" id="wizard-image-preview">${safeUrl(draft.image)?`<img src="${attr(safeUrl(draft.image))}" alt="">`:'<i class="fa-regular fa-image"></i><span>معاينة الصورة</span>'}</div><div class="image-upload-fields"><label>رفع صورة Cloudinary</label><input id="w-file" type="file" accept="image/jpeg,image/png,image/webp"><input id="w-image" dir="ltr" value="${attr(draft.image)}" placeholder="رابط صورة موجود"><small class="muted">الصورة المطلوبة للخدمات التي تعتمد على صورة.</small></div></div></div>`;
    if(step===5)return `<div class="wizard-step"><h4>السعر والباقات</h4><div class="form-grid"><div><label>السعر الأساسي *</label><input id="w-price" type="number" min="0.01" step="0.01" value="${attr(draft.price)}"></div><div><label>العملة</label><input id="w-currency" maxlength="6" dir="ltr" value="${attr(draft.currency==='$'?'$':draft.currency)}"></div></div>${draft.sectionId==='top-up'?`<div class="wizard-topup-note">سيتم إنشاء 7 بطاقات بالضبط في الخطوة التالية.</div>`:''}</div>`;
    if(step===6){recalcPacks();return `<div class="wizard-step"><h4>إعدادات شحن العملات</h4>${draft.sectionId==='top-up'?`<p class="muted">أدخل كمية البطاقة الأولى، وسيتم حساب الباقي تناسبياً مع البونص. تعديل أي كمية أخرى يفعّل Manual Override.</p><div class="topup-wizard-grid">${draft.packs.map((x,i)=>`<div class="topup-wizard-card"><div class="topup-wizard-head"><b>البطاقة ${i+1}</b><span class="topup-price">$${Number(x.price).toFixed(2)}</span></div><div class="topup-fields"><label>السعر<input class="wiz-pack-price" data-i="${i}" type="number" min="0.01" step="0.01" value="${attr(x.price)}"></label><label>البونص %<input class="wiz-pack-bonus" data-i="${i}" type="number" min="0" max="100" step="0.1" value="${attr(x.bonusPercent)}"></label><label>الكمية<input class="wiz-pack-qty" data-i="${i}" type="number" min="1" step="0.01" value="${attr(x.baseQuantity)}"></label></div><div class="topup-preview"><b>${Number(x.finalQuantity).toLocaleString()} ${esc(draft.unitLabel||'Coins')}</b><span>الأساسي ${Number(x.baseQuantity).toLocaleString()} • البونص ${Number(x.bonusQuantity).toLocaleString()} • ${x.manual?'Manual Override':'Automatic'}</span></div></div>`).join('')}</div>`:'<div class="notice info">هذا النوع لا يحتاج إعدادات بطاقات شحن.</div>'}</div>`;}
    if(step===7)return `<div class="wizard-step"><h4>المراجعة النهائية</h4><div class="review-grid"><div><span>الاسم</span><b>${esc(draft.name||'—')}</b></div><div><span>النوع</span><b>${esc(CANONICAL_CATEGORIES.find(c=>c.id===draft.sectionId)?.name||draft.sectionId)}</b></div><div><span>التصنيف</span><b>${esc(categories.find(c=>c.id===draft.categoryId)?.name||'—')}</b></div><div><span>السعر</span><b class="topup-price">${Number(draft.price||0).toFixed(2)} ${esc(draft.currency)}</b></div><div><span>نوع الإدخال</span><b>${esc(draft.inputType||'—')}</b></div><div><span>الصورة</span><b>${draft.image||draft.file?'موجودة':'غير موجودة'}</b></div><div><span>الحالة</span><label class="switch"><input id="w-active" type="checkbox" ${draft.active?'checked':''}> نشر المنتج الآن</label></div><div><span>الظهور</span><label class="switch"><input id="w-featured" type="checkbox" ${draft.featured?'checked':''}> إبراز ضمن الأكثر طلباً</label></div></div>${draft.sectionId==='top-up'?`<div class="topup-review-grid">${draft.packs.map((x,i)=>`<div><b>$${Number(x.price).toFixed(2)}</b><span>+${Number(x.bonusPercent)}%</span><strong>${Number(x.finalQuantity).toLocaleString()} ${esc(draft.unitLabel||'Coins')}</strong></div>`).join('')}</div>`:''}<div id="wizard-validation" class="notice danger hidden"></div></div>`;
    if(step===8)return `<div class="wizard-step final-publish-step"><div class="success-icon"><i class="fa-solid fa-cloud-arrow-up"></i></div><h4>جاهز للنشر</h4><p class="muted">سيتم التحقق مرة أخيرة ثم حفظ المنتج في Firestore. لا تعتبر العملية ناجحة إلا بعد تأكيد الحفظ.</p></div>`;
    return '';
  }
  function validateStep(step){
    if(step===2){draft.name=$('w-name')?.value.trim()||'';draft.description=$('w-description')?.value.trim()||'';draft.platform=$('w-platform')?.value.trim()||'';draft.unitLabel=$('w-unit')?.value.trim()||'';if(draft.name.length<2)throw new Error('اسم المنتج مطلوب.');}
    if(step===3){draft.categoryId=$('w-category')?.value||'';if(draft.categoryId.endsWith('-all'))throw new Error('تصنيف «الكل» للعرض فقط. اختر تصنيف المنتج الفعلي.');draft.inputType=document.querySelector('input[name="w-input-type"]:checked')?.value||'';if(['subscriptions','cards'].includes(draft.categoryId)&&draft.inputType&&!['Email','ID','Username','Number'].includes(draft.inputType))throw new Error('نوع بيانات العميل غير صالح.');const c=categories.find(x=>x.id===draft.categoryId);if(!c||c.parentId!==draft.sectionId)throw new Error('اختر تصنيفاً صحيحاً.');}
    if(step===4){draft.image=$('w-image')?.value.trim()||draft.image;draft.file=$('w-file')?.files?.[0]||draft.file;}
    if(step===5){draft.price=Number($('w-price')?.value);draft.currency=($('w-currency')?.value||'$').trim();if(draft.currency==='USD')draft.currency='$';if(!Number.isFinite(draft.price)||draft.price<=0)throw new Error('السعر يجب أن يكون أكبر من صفر.');}
    if(step===6&&draft.sectionId==='top-up'){recalcPacks();if(draft.packs.length!==7)throw new Error('يجب وجود 7 بطاقات بالضبط.');for(const x of draft.packs){if(!Number.isFinite(Number(x.price))||Number(x.price)<=0||!Number.isFinite(Number(x.bonusPercent))||Number(x.bonusPercent)<0||Number(x.bonusPercent)>100||!Number.isFinite(Number(x.baseQuantity))||Number(x.baseQuantity)<=0)throw new Error('تحقق من سعر وبونص وكمية كل بطاقة.');}}
    if(step===7){draft.active=$('w-active')?.checked??draft.active;draft.featured=$('w-featured')?.checked??draft.featured;if(!draft.name||!draft.categoryId||!draft.currency||!Number.isFinite(draft.price)||draft.price<=0)throw new Error('أكمل بيانات المنتج قبل النشر.');if(draft.sectionId==='top-up'&&!draft.packs.every(x=>Number(x.baseQuantity)>0))throw new Error('كمية البطاقة الأولى وبقية البطاقات مطلوبة.');}
  }
  function renderStep(){const modal=$('editor-modal'),body=modal.querySelector('#wizard-body');body.innerHTML=stepContent(step);modal.querySelector('#wizard-step-label').textContent=`الخطوة ${step} من 8`;modal.querySelector('#wizard-back').disabled=step<=1;modal.querySelector('#wizard-next').classList.toggle('hidden',step>=8);modal.querySelector('#wizard-publish').classList.toggle('hidden',step!==8);bindStep();}
  function bindStep(){const modal=$('editor-modal');modal.querySelectorAll('[data-section-choice]').forEach(b=>b.onclick=()=>{draft.sectionId=b.dataset.sectionChoice;draft.categoryId=categories.find(c=>c.parentId===draft.sectionId&&!c.id.endsWith('-all'))?.id||'';if(draft.sectionId==='top-up')recalcPacks();renderStep();});modal.querySelector('#w-category')?.addEventListener('change',()=>{draft.categoryId=modal.querySelector('#w-category').value;renderStep();});modal.querySelector('#w-file')?.addEventListener('change',()=>{draft.file=modal.querySelector('#w-file').files[0]||null;if(draft.file){const u=URL.createObjectURL(draft.file);modal.querySelector('#wizard-image-preview').innerHTML=`<img src="${esc(u)}" alt="">`;}});modal.querySelector('#w-image')?.addEventListener('input',()=>{draft.image=modal.querySelector('#w-image').value.trim();const u=safeUrl(draft.image);modal.querySelector('#wizard-image-preview').innerHTML=u?`<img src="${attr(u)}" alt="">`:'<i class="fa-regular fa-image"></i><span>معاينة الصورة</span>';});modal.querySelectorAll('.wiz-pack-price,.wiz-pack-bonus,.wiz-pack-qty').forEach(input=>input.addEventListener('input',()=>{const i=Number(input.dataset.i),x=draft.packs[i];if(input.classList.contains('wiz-pack-price'))x.price=Number(input.value);if(input.classList.contains('wiz-pack-bonus'))x.bonusPercent=Number(input.value);if(input.classList.contains('wiz-pack-qty')){x.baseQuantity=Number(input.value);if(i>0)x.manual=true;}recalcPacks();modal.querySelectorAll('.topup-wizard-card').forEach((card,idx)=>{const q=draft.packs[idx];const qty=card.querySelector('.wiz-pack-qty');const price=card.querySelector('.wiz-pack-price');if(idx>0&&!q.manual&&document.activeElement!==qty)qty.value=q.baseQuantity;price.value=q.price;card.querySelector('.topup-wizard-head .topup-price').textContent=`$${Number(q.price).toFixed(2)}`;const preview=card.querySelector('.topup-preview');preview.innerHTML=`<b>${Number(q.finalQuantity).toLocaleString()} ${esc(draft.unitLabel||'Coins')}</b><span>الأساسي ${Number(q.baseQuantity).toLocaleString()} • البونص ${Number(q.bonusQuantity).toLocaleString()} • ${q.manual?'Manual Override':'Automatic'}</span>`;});}));
  }
  const html=`<div class="modal" id="editor-modal"><div class="modal-card publish-wizard"><div class="modal-head"><div><h3>${esc(id?'تعديل المنتج':'نشر منتج جديد')}</h3><p class="muted" id="wizard-step-label">الخطوة 1 من 8</p></div><button type="button" class="icon-btn" id="editor-close"><i class="fa-solid fa-xmark"></i></button></div><div class="wizard-progress"><span id="wizard-progress-bar"></span></div><div id="wizard-body" class="modal-body"></div><div class="wizard-footer"><button type="button" class="toolbar-btn" id="wizard-cancel">إلغاء</button><button type="button" class="toolbar-btn" id="wizard-back">السابق</button><button type="button" class="primary-small" id="wizard-next">التالي</button><button type="button" class="primary-small hidden" id="wizard-publish">نشر المنتج الآن</button></div></div></div>`;
  $('editor-modal')?.remove();document.body.insertAdjacentHTML('beforeend',html);let step=1;const modal=$('editor-modal');renderStep();
  const closeWizard=()=>{if(step>1&&step<8){const m=ensureWizardExitModal();return;}modal.remove();};
  function ensureWizardExitModal(){let m=document.getElementById('wizard-exit-confirm');if(!m){m=document.createElement('div');m.id='wizard-exit-confirm';m.className='modal-backdrop';m.innerHTML='<div class="modal-card"><div class="modal-head"><h3>إلغاء عملية النشر؟</h3></div><div class="modal-body"><p class="muted">سيتم فقدان البيانات غير المحفوظة.</p><div class="wizard-footer"><button class="toolbar-btn" data-continue>متابعة التحرير</button><button class="primary-small" data-cancel>إلغاء النشر</button></div></div></div>';document.body.appendChild(m);m.querySelector('[data-continue]').onclick=()=>m.remove();m.querySelector('[data-cancel]').onclick=()=>{m.remove();modal.remove();};}return m;}
  modal.querySelector('#editor-close').onclick=closeWizard;modal.querySelector('#wizard-cancel').onclick=closeWizard;modal.addEventListener('click',e=>{if(e.target===modal)closeWizard();});modal.querySelector('#wizard-back').onclick=()=>{if(step>1){step--;renderStep();}};modal.querySelector('#wizard-next').onclick=()=>{try{validateStep(step);if(step<8){step++;renderStep();modal.querySelector('#wizard-progress-bar').style.width=`${(step/8)*100}%`;}}catch(e){const v=modal.querySelector('#wizard-validation');if(v){v.textContent=e.message;v.className='notice danger';}else toast(e.message,'error');}};
  modal.querySelector('#wizard-publish').onclick=async()=>{const btn=modal.querySelector('#wizard-publish');if(btn.disabled)return;btn.disabled=true;btn.textContent='جاري النشر…';try{validateStep(7);if(draft.file){draft.image=await uploadImage(draft.file,adminAuth);}draft.image=safeUrl(draft.image);if(draft.active&&!draft.image)throw new Error('صورة المنتج مطلوبة قبل النشر.');const selectedCat=categories.find(c=>c.id===draft.categoryId);const packs=draft.sectionId==='top-up'?draft.packs.map((x,i)=>({id:`pack-${i+1}`,price:Number(x.price),bonusPercent:Number(x.bonusPercent),baseQuantity:Number(x.baseQuantity),bonusQuantity:Number(x.bonusQuantity),finalQuantity:Number(x.finalQuantity),calculationMode:x.manual?'manual':'automatic',active:x.active!==false})):[];const data={name:draft.name,description:draft.description,platform:draft.platform,unitLabel:draft.unitLabel,sectionId:draft.sectionId,categoryId:draft.categoryId,categoryName:selectedCat?.name||'',inputType:['Username','ID','Number','Email'].includes(draft.inputType)?draft.inputType:'',price:draft.sectionId==='top-up'?Number(packs[0].price):Number(draft.price),currency:draft.currency==='USD'?'$':draft.currency,image:draft.image,topupPackages:packs,rating:Math.min(5,Math.max(0,Number(draft.rating)||5)),popularity:Math.max(0,Number(draft.popularity)||0),sortOrder:Math.max(0,Math.floor(Number(draft.sortOrder)||999)),featured:Boolean(draft.featured),active:Boolean(draft.active),updatedAt:serverTimestamp()};if(id)await updateDoc(doc(adminDb,'products',id),data);else await addDoc(collection(adminDb,'products'),{...data,createdAt:serverTimestamp()});await writeAudit(id?'update':'create','products',id||'new',{name:data.name,categoryId:data.categoryId,active:data.active,topupPackages:data.topupPackages.length});modal.remove();await loadAll();render('products');adminSuccess(data.active?'تم نشر المنتج بنجاح':'تم حفظ المنتج','تم تأكيد حفظ المنتج في قاعدة البيانات.','products');}catch(error){btn.disabled=false;btn.textContent='نشر المنتج الآن';toast(friendlyError(error),'error');}};
}

function categoryForm(id){
  if(!can('categories'))return;
  const base=CANONICAL_CATEGORIES.find(x=>x.id===id);
  const c=state.categories.find(x=>x.id===id)||base;
  if(!base)return;
  openModal(modalShell('تعديل القسم الرئيسي',`
    <form id="editor-form" class="form-stack">
      <div class="notice success">JoTPay يعتمد أربعة أقسام رئيسية ثابتة: شحن عملات، بطاقات واشتراكات، شراء متابعين، شراء حسابات. التصنيفات الفرعية تُدار من لوحة الإدارة ولا يمكن إنشاء قسم رئيسي خامس.</div>
      <label>اسم القسم</label><input id="f-name" readonly value="${attr(base.name)}">
      <label>المعرّف</label><input id="f-id" readonly dir="ltr" value="${attr(base.id)}">
      <label>الترتيب</label><input id="f-sort" type="number" min="0" step="1" value="${attr(c.sortOrder??base.sortOrder)}">
      <label class="switch"><input id="f-active" type="checkbox" ${c.active!==false?'checked':''}> القسم ظاهر للعملاء</label>
      <button class="primary-btn" type="submit">حفظ القسم</button>
    </form>
  `),async e=>{
    e.preventDefault();
    try{
      const sortOrder=Math.max(0,Math.floor(Number($('f-sort').value||base.sortOrder)));
      const active=$('f-active').checked;
      await setDoc(doc(adminDb,'categories',base.id),{...base,sortOrder,active,parentId:'',type:'primary',updatedAt:serverTimestamp()},{merge:true});
      await writeAudit('update','categories',base.id,{name:base.name,active,sortOrder});
      $('editor-modal').remove();await loadAll();render('categories');toast('تم حفظ القسم.');
    }catch(error){toast(friendlyError(error),'error');}
  });
}

function loginBannerForm(){
  if(!can('banners'))return;
  const b={...DEFAULT_LOGIN_BANNER,...(state.loginBanner||{})};
  openModal(modalShell('بانر مكافأة أول تسجيل دخول',`
    <form id="editor-form" class="form-stack">
      <div class="notice success">يظهر هذا الشريط باللون الأحمر بعد أول تسجيل دخول ناجح للمستخدم، ولا يظهر للزائر غير المسجل.</div>
      <label>الوسم</label><input id="f-tag" maxlength="60" value="${attr(b.tag)}">
      <label>العنوان</label><input id="f-title" required maxlength="180" value="${attr(b.title)}">
      <label>الوصف</label><textarea id="f-description" maxlength="500">${esc(b.description)}</textarea>
      <label>نسبة الزيادة</label><input id="f-bonus" type="number" min="0" max="100" step="1" value="${attr(b.bonusPercent??30)}">
      <label class="switch"><input id="f-active" type="checkbox" ${b.active!==false?'checked':''}> تفعيل العرض</label>
      <button class="primary-btn" type="submit">حفظ ونشر</button>
    </form>
  `),async e=>{
    e.preventDefault();
    try{
      const bonus=Math.min(100,Math.max(0,Math.floor(Number($('f-bonus').value||30))));
      if(!String($('f-title').value||'').trim())throw new Error('عنوان العرض مطلوب.');
      const data={tag:$('f-tag').value.trim()||'مكافأة أول تسجيل دخول',title:$('f-title').value.trim(),description:$('f-description').value.trim(),bonusPercent:bonus,audience:'first-login',active:$('f-active').checked,updatedAt:serverTimestamp()};
      await setDoc(doc(adminDb,'settings','loginBanner'),data,{merge:true});
      await writeAudit('update','settings','loginBanner',{active:data.active,bonusPercent:bonus});
      $('editor-modal').remove();await loadAll();render('banners');toast('تم حفظ بانر المكافأة.');
    }catch(error){toast(friendlyError(error),'error');}
  });
}

function bannerForm(id){
  if(!can('banners'))return;
  const b=state.banners.find(x=>x.id===id)||{};
  const image=safeUrl(b.image||'');
  openModal(modalShell(id?'تعديل العرض':'إضافة عرض',`
    <form id="editor-form" class="form-stack product-editor">
      <div class="form-section">
        <h4>1) محتوى العرض</h4>
        <div class="form-grid">
          <div><label>الوسم</label><input id="f-tag" maxlength="60" value="${attr(b.tag||'عرض')}"></div>
          <div><label>العنوان *</label><input id="f-title" required maxlength="180" value="${attr(b.title||'')}"></div>
          <div class="full"><label>الوصف</label><textarea id="f-description" maxlength="500">${esc(b.description||'')}</textarea></div>
          <div><label>نص زر العرض</label><input id="f-cta" maxlength="60" value="${attr(b.cta||'استفد من العرض')}"></div>
          <div><label>الرابط (اختياري)</label><input id="f-url" dir="ltr" value="${attr(b.actionUrl||'')}"></div>
          <div><label>الترتيب</label><input id="f-sort" type="number" min="0" step="1" value="${attr(b.sortOrder??100)}"></div>
        </div>
      </div>
      <div class="form-section">
        <h4>2) ترجمات العرض</h4>
        <p class="muted">تُستخدم الترجمة المطابقة للغة المستخدم تلقائيًا. اترك أي لغة فارغة لاستخدام المحتوى الأصلي بأمان.</p>
        <div class="form-grid banner-translations">${BANNER_LANGS.map(([code,label])=>{const tr=(b.translations&&b.translations[code])||{};return `<div><label>${label}</label><input data-tr-title="${code}" maxlength="180" placeholder="العنوان" value="${attr(tr.title||'')}"><textarea data-tr-description="${code}" maxlength="500" placeholder="الوصف">${esc(tr.description||'')}</textarea><input data-tr-cta="${code}" maxlength="60" placeholder="نص الزر" value="${attr(tr.cta||'')}"></div>`;}).join('')}</div>
      </div>
      <div class="form-section">
        <h4>3) صورة العرض</h4>
        <div class="image-upload-box">
          <div class="image-preview" id="banner-image-preview">${image?`<img src="${attr(image)}" alt="">`:'<i class="fa-regular fa-image"></i><span>معاينة الصورة</span>'}</div>
          <div class="image-upload-fields">
            <label>رفع صورة إلى Cloudinary</label>
            <input id="f-file" class="file" type="file" accept="image/png,image/jpeg,image/webp">
            <input id="f-image" dir="ltr" value="${attr(image)}" placeholder="رابط الصورة الحالي، أو ارفع صورة">
            <small class="muted">الصورة تُضغط قبل الرفع وتُحفظ عبر Cloudinary، ويمكن استخدام رابط مباشر موجود مسبقاً.</small>
            <button type="button" class="toolbar-btn" id="clear-banner-image">إزالة الصورة</button>
          </div>
        </div>
      </div>
      <div class="form-section">
        <h4>3) النشر</h4>
        <label class="switch"><input id="f-active" type="checkbox" ${b.active!==false?'checked':''}> منشور على الصفحة الرئيسية</label>
        <div class="full"><button class="primary-btn" id="save-btn" type="submit">حفظ العرض</button></div>
      </div>
    </form>
  `),async e=>{
    e.preventDefault();
    const btn=$('save-btn');btn.disabled=true;
    try{
      let image=$('f-image').value.trim();
      if($('f-file').files[0])image=await uploadImage($('f-file').files[0],adminAuth);
      image=safeUrl(image);
      if($('f-file').files[0]&&!image)throw new Error('لم يتم الحصول على رابط صورة صالح.');
      const rawUrl=$('f-url').value.trim(),url=safeUrl(rawUrl);
      if(rawUrl&&!url)throw new Error('الرابط يجب أن يبدأ بـ https:// أو http:// أو /');
      const translations={};BANNER_LANGS.forEach(([code])=>{const title=document.querySelector(`[data-tr-title=\"${code}\"]`)?.value.trim()||'',description=document.querySelector(`[data-tr-description=\"${code}\"]`)?.value.trim()||'',cta=document.querySelector(`[data-tr-cta=\"${code}\"]`)?.value.trim()||'';if(title||description||cta)translations[code]={title,description,cta};});const data={tag:$('f-tag').value.trim(),title:$('f-title').value.trim(),description:$('f-description').value.trim(),cta:$('f-cta').value.trim()||'استفد من العرض',translations,actionUrl:url,image,sortOrder:Math.max(0,Math.floor(Number($('f-sort').value||100))),active:$('f-active').checked,updatedAt:serverTimestamp()};
      if(!data.title)throw new Error('عنوان العرض مطلوب.');
      if(id)await updateDoc(doc(adminDb,'banners',id),data);
      else await addDoc(collection(adminDb,'banners'),{...data,createdAt:serverTimestamp()});
      await writeAudit(id?'update':'create','banners',id||'new',{title:data.title,active:data.active,hasImage:Boolean(image)});
      $('editor-modal').remove();await loadAll();render('banners');toast('تم حفظ العرض.');
    }catch(error){toast(friendlyError(error),'error');}
    finally{btn.disabled=false;}
  });
  $('f-file')?.addEventListener('change',()=>{const file=$('f-file').files[0];if(!file)return;const url=URL.createObjectURL(file);$('banner-image-preview').innerHTML=`<img src="${attr(url)}" alt="معاينة">`;});
  $('f-image')?.addEventListener('input',()=>{const url=safeUrl($('f-image').value.trim());$('banner-image-preview').innerHTML=url?`<img src="${attr(url)}" alt="">`:'<i class="fa-regular fa-image"></i><span>معاينة الصورة</span>';});
  $('clear-banner-image')?.addEventListener('click',()=>{$('f-file').value='';$('f-image').value='';$('banner-image-preview').innerHTML='<i class="fa-regular fa-image"></i><span>معاينة الصورة</span>';});
}

function marketForm(id){ if(!can('market'))return; const x=state.accountListings.find(v=>v.id===id); if(!x)return; openModal(modalShell('مراجعة طلب الحساب',`<form id="editor-form" class="form-stack"><p>الحساب: <b>${esc(x.accountName||'—')}</b></p><p>المنصة: <b>${esc(x.platform||'—')}</b></p><p>السعر: <b>${money(x.price,x.currency||'USD')}</b></p><p class="muted">لا يتم طلب كلمة المرور هنا. أكمل التسليم عبر قناة الدعم الآمنة ثم حدّث الحالة.</p><label>الحالة</label><select id="f-status"><option value="pending">قيد المراجعة</option><option value="approved">تمت الموافقة</option><option value="handover">قيد التسليم</option><option value="listed">منشور للبيع</option><option value="sold">تم البيع</option><option value="rejected">مرفوض</option></select><label>ملاحظة الإدارة</label><textarea id="f-note" maxlength="1000">${esc(x.adminNote||'')}</textarea><button class="primary-btn" type="submit">حفظ الحالة</button></form>`),async e=>{e.preventDefault();try{const status=$('f-status').value,note=$('f-note').value.trim();await updateDoc(doc(adminDb,'accountListings',id),{status,adminNote:note,updatedAt:serverTimestamp()});await writeAudit('update','accountListings',id,{status});$('editor-modal').remove();await loadAll();render('market');toast('تم تحديث حالة الحساب.')}catch(error){toast(friendlyError(error),'error')}});setTimeout(()=>{$('f-status').value=x.status||'pending'},0);}
function editOrder(id){
  if(!can('orders'))return;
  const o=state.orders.find(x=>x.id===id);if(!o)return;
  const customer=o.customerData&&typeof o.customerData==='object'?o.customerData:{};
  const target=customer.target||customer.username||'';
  const details=`<div class="info-grid">
    <div><small>رقم الطلب</small><b dir="ltr">${esc(o.id)}</b></div>
    <div><small>العميل</small><b dir="ltr">${esc(o.customerEmail||o.userId||'—')}</b></div>
    <div><small>الخدمة</small><b>${esc(o.productName||'—')}</b></div>
    <div><small>المبلغ المدفوع</small><b>${money(o.total??o.chargedAmount??0,o.currency)}</b></div>
    <div><small>الكمية المطلوبة</small><b>${esc(o.requestedQuantity??o.quantity??1)}</b></div>
    <div><small>الكمية/التسليم المسجل</small><b>${esc(o.quantity??'—')}</b></div>
    <div><small>الدفع</small><b>${esc(o.paymentStatus||'—')}</b></div>
    <div><small>التنفيذ</small><b>${esc(o.fulfillmentStatus||'pending')}</b></div>
    <div><small>المصدر</small><b>${esc(o.source||'web')}</b></div>
    <div><small>التاريخ</small><b>${esc(date(o.createdAt))}</b></div>
    <div><small>المعرّف/اسم المستخدم</small><b dir="ltr">${esc(target||'—')}</b></div>
    <div><small>الباقة</small><b dir="ltr">${esc(customer.packageId||'—')}</b></div>
  </div>
  <div class="panel" style="margin-top:12px"><div class="panel-head"><div><h4 style="margin:0">تعليمات الشحن اليدوي</h4><p class="muted">لا يوجد شحن آلي مزيف. نفّذ الشحن خارج المنصة ثم غيّر الحالة إلى «مكتمل».</p></div></div>
  <div class="notice info">بعد تنفيذ الشحن فعلياً: اختر <b>مكتمل</b> واحفظ. سيصل تحديث للعميل وتبقى العملية في سجل التدقيق.</div></div>`;
  openModal(modalShell('تفاصيل الطلب والشحن اليدوي',`<form id="editor-form" class="form-stack">
    ${details}
    <label>حالة الطلب</label>
    <select id="f-status">
      <option value="pending">قيد الانتظار — طلب جديد</option>
      <option value="processing">قيد المعالجة — تم استلام الطلب ويجري شحنه يدوياً</option>
      <option value="completed">مكتمل — تم الشحن بنجاح</option>
      <option value="cancelled">ملغي</option>
      <option value="refunded">مسترد</option>
    </select>
    <label>ملاحظة الإدارة</label>
    <textarea id="f-note" maxlength="500" placeholder="مثال: تم الشحن يدوياً بتاريخ...">${esc(o.adminNote||'')}</textarea>
    <button class="primary-btn" type="submit">حفظ وتحديث العميل</button>
  </form>`),async e=>{
    e.preventDefault();
    try{
      const status=$('f-status').value,note=$('f-note').value.trim(),previous=o.status||'pending';
      if(status==='refunded'&&!['owner','manager'].includes(me?.role))throw new Error('لا تملك صلاحية رد المبلغ.');
      if(status==='refunded'&&previous!=='refunded'){
        const orderRef=doc(adminDb,'orders',id),userRef=doc(adminDb,'users',o.userId),ledgerRef=doc(collection(adminDb,'walletLedger'));
        const refund=Number(o.total??o.chargedAmount??0);
        if(!Number.isFinite(refund)||refund<=0)throw new Error('قيمة الاسترداد غير صالحة.');
        await runTransaction(adminDb,async tx=>{
          const [os,us]=await Promise.all([tx.get(orderRef),tx.get(userRef)]);
          if(!os.exists()||!us.exists())throw new Error('بيانات الطلب أو المستخدم غير موجودة.');
          if(os.data().status==='refunded')return;
          const before=Number(us.data().walletBalance||0),after=Number((before+refund).toFixed(2));
          tx.update(userRef,{walletBalance:after,updatedAt:serverTimestamp()});
          tx.update(orderRef,{status:'refunded',adminNote:note,fulfillmentStatus:'refunded',refundAmount:refund,refundedBy:me.id,refundedAt:serverTimestamp(),updatedAt:serverTimestamp()});
          tx.set(ledgerRef,{userId:o.userId,orderId:id,type:'refund',amount:refund,balanceBefore:before,balanceAfter:after,adminId:me.id,createdAt:serverTimestamp()});
        });
      }else{
        const fulfillmentStatus=status==='completed'?'completed':status==='cancelled'?'cancelled':status==='refunded'?'refunded':status==='processing'?'processing':'pending';
        await updateDoc(doc(adminDb,'orders',id),{status,adminNote:note,updatedAt:serverTimestamp(),fulfillmentStatus:fulfillmentStatus});
      }
      if(status!==previous)await notifyUser(o.userId,'تحديث طلبك',`تم تغيير حالة الطلب ${o.id.slice(0,12)} إلى: ${statusName(status)}.`,'order',id);
      await writeAudit('update','orders',id,{status,previous,manualFulfillment:status==='completed'||status==='processing',refunded:status==='refunded'});
      $('editor-modal').remove();await loadAll();render('orders');toast('تم تحديث الطلب وحفظ حالة الشحن.');
    }catch(error){toast(friendlyError(error),'error');}
  });
  setTimeout(()=>{$('f-status').value=o.status||'pending'},0);
}

function userForm(id){
  const u=state.users.find(x=>x.id===id);if(!u||!(me?.role==='owner'||me?.role==='manager'))return;
  const owner=me.role==='owner';
  openModal(modalShell('تعديل المستخدم',`<form id="editor-form" class="form-stack"><p dir="ltr">${esc(u.email||u.id)}</p><label>الاسم</label><input id="f-name" maxlength="80" value="${attr(u.displayName||'')}"><label>حالة الحساب</label><select id="f-ban"><option value="active" ${u.status!=='banned'?'selected':''}>نشط</option><option value="temporary" ${u.status==='banned'&&u.banType==='temporary'?'selected':''}>حظر مؤقت</option><option value="permanent" ${u.status==='banned'&&u.banType==='permanent'?'selected':''}>حظر دائم</option></select><label id="f-ban-until-label">ينتهي الحظر في</label><input id="f-ban-until" type="datetime-local" value="${u.bannedUntil?.toDate?new Date(u.bannedUntil.toDate()).toISOString().slice(0,16):''}"><label id="f-ban-reason-label">سبب الحظر</label><textarea id="f-ban-reason" maxlength="500">${attr(u.banReason||'')}</textarea>${owner?`<label>الرصيد الحالي</label><input id="f-balance" type="number" min="0" step="0.01" value="${attr(u.walletBalance??0)}"><label>الرصيد الجديد</label><input id="f-new-balance" type="number" min="0" step="0.01" value="${attr(u.walletBalance??0)}"><label>سبب تعديل الرصيد</label><input id="f-note" maxlength="240" placeholder="مثال: تعويض طلب">`:''}<button class="primary-btn" type="submit">حفظ</button></form>`),async e=>{e.preventDefault();try{const ban=$('f-ban').value;const until=$('f-ban-until').value;const reason=$('f-ban-reason').value.trim();if(ban!=='active'&&!reason)throw new Error('سبب الحظر مطلوب.');if(ban==='temporary'&&!until)throw new Error('حدد موعد انتهاء الحظر المؤقت.');const banData=ban==='active'?{status:'active',banType:null,banReason:'',bannedUntil:null,bannedAt:null}:{status:'banned',banType:ban==='temporary'?'temporary':'permanent',banReason:reason,bannedUntil:ban==='temporary'?new Date(until):null,bannedAt:serverTimestamp()};await updateDoc(doc(adminDb,'users',id),{displayName:$('f-name').value.trim(),...banData,updatedAt:serverTimestamp()});if(ban!=='active')await notifyUser(id,'تم حظر الحساب',reason,'info');else if(u.status==='banned')await notifyUser(id,'تم إلغاء حظر الحساب','تم إعادة تفعيل حسابك.','info');if(owner){const old=Number(u.walletBalance||0),next=Number($('f-new-balance').value||0);if(!Number.isFinite(next)||next<0)throw new Error('الرصيد الجديد غير صالح.');if(Math.abs(next-old)>0.000001){const userRef=doc(adminDb,'users',id),ledgerRef=doc(collection(adminDb,'walletLedger'));await runTransaction(adminDb,async tx=>{const snap=await tx.get(userRef);if(!snap.exists())throw new Error('المستخدم غير موجود.');const current=Number(snap.data().walletBalance||0);const calculated=Number((current+(next-current)).toFixed(2));tx.update(userRef,{walletBalance:calculated,updatedAt:serverTimestamp()});tx.set(ledgerRef,{userId:id,adminId:me.id,type:'admin_adjustment',amount:Number((next-current).toFixed(2)),balanceBefore:current,balanceAfter:calculated,note:$('f-note').value.trim(),createdAt:serverTimestamp()});});await notifyUser(id,'تحديث رصيد المحفظة',`تم تحديث رصيد محفظتك إلى $${next.toFixed(2)}.`,'wallet');await writeAudit('wallet_adjustment','users',id,{before:old,after:next,note:$('f-note').value.trim()});}}await writeAudit('update','users',id,{displayName:$('f-name').value.trim()});$('editor-modal').remove();await loadAll();render('users');toast('تم حفظ المستخدم.');}catch(error){toast(friendlyError(error),'error');}});
}

function adminForm(id){
  if(!can('admins'))return; const a=state.admins.find(x=>x.id===id)||{};
  openModal(modalShell(id?'تعديل مدير':'إضافة مدير',`<form id="editor-form" class="form-stack">${id?`<p dir="ltr">UID: ${esc(id)}</p>`:'<label>UID المستخدم من Firebase Authentication</label><input id="f-uid" required dir="ltr" maxlength="128">'}<label>البريد للعرض</label><input id="f-email" type="email" dir="ltr" value="${attr(a.email||'')}"><label>الدور</label><select id="f-role"><option value="owner" ${a.role==='owner'?'selected':''}>Owner — المالك</option><option value="manager" ${a.role==='manager'?'selected':''}>Manager — مدير</option><option value="support" ${a.role==='support'?'selected':''}>Support — دعم</option></select><label class="switch"><input id="f-active" type="checkbox" ${a.active!==false?'checked':''}> الحساب نشط</label><button class="primary-btn" type="submit">حفظ الصلاحيات</button></form>`),async e=>{e.preventDefault();try{const uid=id||$('f-uid').value.trim();if(!uid)throw new Error('UID مطلوب.');if(uid===me.id&&$('f-active').checked===false)throw new Error('لا يمكنك تعطيل جلسة المالك الحالية.');const data={email:$('f-email').value.trim(),role:$('f-role').value,active:$('f-active').checked,updatedAt:serverTimestamp()};await setDoc(doc(adminDb,'admins',uid),{...data,createdAt:a.createdAt||serverTimestamp()},{merge:true});await writeAudit(id?'update':'create','admins',uid,{role:data.role,active:data.active});$('editor-modal').remove();await loadAll();render('admins');toast('تم حفظ صلاحيات المدير.');}catch(error){toast(friendlyError(error),'error');}});
}

function ticketForm(id){
  if(!can('support'))return;const t=state.tickets.find(x=>x.id===id);if(!t)return;
  openModal(modalShell('تحديث تذكرة الدعم',`<form id="editor-form" class="form-stack"><p><b>${esc(t.subject||'بدون عنوان')}</b></p><p class="muted">المستخدم: ${esc(t.userEmail||t.userId)}</p><label>رسالة العميل</label><textarea readonly>${esc(t.message||'')}</textarea><label>الحالة</label><select id="f-status"><option value="open">مفتوحة</option><option value="pending">قيد المتابعة</option><option value="closed">مغلقة</option></select><label>رد الإدارة</label><textarea id="f-reply" maxlength="1500">${esc(t.adminReply||'')}</textarea><button class="primary-btn" type="submit">حفظ وإرسال</button></form>`),async e=>{e.preventDefault();try{const status=$('f-status').value,reply=$('f-reply').value.trim();const changed=reply!==String(t.adminReply||'')||status!==String(t.status||'open');await updateDoc(doc(adminDb,'supportTickets',id),{status,adminReply:reply,updatedAt:serverTimestamp()});if(reply&&changed)await notifyUser(t.userId,'رد من الدعم',reply,'support',id);await writeAudit('update','supportTickets',id,{status,replied:Boolean(reply)});$('editor-modal').remove();await loadAll();render('support');toast('تم تحديث التذكرة وإرسال الرد عند الإمكان.');}catch(error){toast(friendlyError(error),'error');}});setTimeout(()=>{$('f-status').value=t.status||'open'},0);
}

async function deleteDocSafe(name,id){
  const allowed=['products','categories','banners'];if(!allowed.includes(name)||!can(name))return;
  if(name==='categories'){const c=state.categories.find(x=>x.id===id);if(c?.type==='primary'){toast('لا يمكن حذف الأقسام الرئيسية الأربعة. يمكنك تعطيلها فقط.','error');return;}if(c&&state.products.some(p=>p.categoryId===id)){toast('لا يمكن حذف تصنيف يحتوي منتجات. انقل المنتجات أولاً أو عطّل التصنيف.','error');return;}}
  if(!await confirmAdminAction('هل تريد حذف هذا العنصر نهائياً؟ لا يمكن التراجع عن هذه العملية.'))return;
  try{await deleteDoc(doc(adminDb,name,id));await writeAudit('delete',name,id);await loadAll();render(activeView);toast('تم الحذف نهائياً.');}catch(error){toast(friendlyError(error),'error');}
}

$('admin-login-form').addEventListener('submit',async e=>{e.preventDefault();const btn=e.target.querySelector('button'),err=$('admin-login-error');err.classList.add('hidden');btn.disabled=true;btn.textContent='جارٍ التحقق…';try{await signInWithEmailAndPassword(adminAuth,$('admin-email').value.trim(),$('admin-password').value);}catch(error){err.textContent=friendlyError(error);err.className='error';btn.disabled=false;btn.textContent='دخول لوحة الإدارة';}});
$('logout').addEventListener('click',()=>signOut(adminAuth));
$('refresh').addEventListener('click',async()=>{try{$('refresh').disabled=true;await loadAll();render(activeView);toast('تم تحديث البيانات.');}catch(error){toast(friendlyError(error),'error');}finally{$('refresh').disabled=false;}});
document.querySelectorAll('.nav').forEach(b=>b.addEventListener('click',()=>render(b.dataset.view)));

document.querySelector('.content').addEventListener('click',e=>{
  const btn=e.target.closest('[data-action]');if(!btn)return;
  const action=btn.dataset.action,id=btn.dataset.id;
  if(action==='view')return render(btn.dataset.viewTarget);
  if(action==='add-product')return productForm(); if(action==='edit-product')return productForm(id); if(action==='delete-product')return deleteDocSafe('products',id);
  if(action==='edit-category')return categoryForm(id); if(action==='add-subcategory')return secondaryCategoryForm('',btn.dataset.parent); if(action==='edit-subcategory')return secondaryCategoryForm(id);
  if(action==='edit-login-banner')return loginBannerForm(); if(action==='add-banner')return bannerForm(); if(action==='edit-banner')return bannerForm(id); if(action==='delete-banner')return deleteDocSafe('banners',id);
  if(action==='edit-market')return marketForm(id); if(action==='edit-order')return editOrder(id); if(action==='edit-user')return userForm(id); if(action==='add-admin')return adminForm(); if(action==='edit-admin')return adminForm(id); if(action==='edit-ticket')return ticketForm(id); if(action==='approve-deposit')return approveDeposit(id); if(action==='reject-deposit')return rejectDeposit(id);
});

onAuthStateChanged(adminAuth,async user=>{
  if(!user){me=null;ordersUnsub?.();ordersUnsub=null;showLogin();return;}
  try{
    me=await getMe(user);showApp();$('admin-email-label').textContent=user.email||'';$('admin-role-label').textContent=ROLE_NAMES[me.role]||me.role;
    document.querySelectorAll('.nav').forEach(b=>b.classList.toggle('hidden',!can(b.dataset.view)));
    await loadAll();await ensureSystemDefaults();await loadAll();subscribeOrders();render('dashboard');
  }catch(error){
    const err=$('admin-login-error');err.className='error';
    err.textContent=error.code==='admin-record-missing' ? `${error.message}. أنشئ المستند ثم أعد الدخول.` : error.code==='admin-disabled' ? error.message : friendlyError(error);
    err.classList.remove('hidden');
    await signOut(adminAuth).catch(()=>{});
    showLogin();
  }
});
