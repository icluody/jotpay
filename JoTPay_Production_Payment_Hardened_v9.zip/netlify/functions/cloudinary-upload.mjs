import crypto from 'node:crypto';
import { getApps, initializeApp, cert } from 'firebase-admin/app';
import { getAuth } from 'firebase-admin/auth';
import { getFirestore, doc, getDoc } from 'firebase-admin/firestore';

const json = (payload, status = 200) => new Response(JSON.stringify(payload), {
  status,
  headers: {
    'Content-Type': 'application/json; charset=utf-8',
    'Cache-Control': 'no-store',
  },
});

function firebaseServices() {
  const raw = String(process.env.FIREBASE_SERVICE_ACCOUNT_JSON || '').trim();
  if (!raw) throw new Error('FIREBASE_SERVICE_ACCOUNT_JSON is not configured in Netlify.');
  let serviceAccount;
  try { serviceAccount = JSON.parse(raw); }
  catch { throw new Error('FIREBASE_SERVICE_ACCOUNT_JSON is invalid JSON.'); }
  if (!serviceAccount.project_id || !serviceAccount.client_email || !serviceAccount.private_key) {
    throw new Error('FIREBASE_SERVICE_ACCOUNT_JSON is incomplete.');
  }
  serviceAccount.private_key = String(serviceAccount.private_key).replace(/\\n/g, '\n');
  const app = getApps().find(x => x.name === 'jotpay-cloudinary-admin')
    || initializeApp({ credential: cert(serviceAccount) }, 'jotpay-cloudinary-admin');
  return { auth: getAuth(app), db: getFirestore(app) };
}

async function requireAdmin(request) {
  const header = request.headers.get('authorization') || '';
  if (!header.startsWith('Bearer ')) throw new Error('Missing authorization token.');
  const token = header.slice(7).trim();
  if (!token) throw new Error('Missing authorization token.');
  const { auth, db } = firebaseServices();
  const decoded = await auth.verifyIdToken(token);
  const snap = await getDoc(doc(db, 'admins', decoded.uid));
  const admin = snap.exists() ? snap.data() : null;
  if (!admin || admin.active === false || !['owner', 'manager'].includes(String(admin.role || ''))) {
    throw new Error('Admin access is required.');
  }
  return decoded;
}

function cloudinaryConfig() {
  const envUrl = String(process.env.CLOUDINARY_URL || '').trim();
  if (envUrl) {
    let parsed;
    try { parsed = new URL(envUrl); }
    catch { throw new Error('CLOUDINARY_URL is invalid.'); }
    const cloudName = parsed.hostname;
    const apiKey = decodeURIComponent(parsed.username || '');
    const apiSecret = decodeURIComponent(parsed.password || '');
    if (!cloudName || !apiKey || !apiSecret) throw new Error('CLOUDINARY_URL is incomplete.');
    return { cloudName, apiKey, apiSecret };
  }
  const cloudName = String(process.env.CLOUDINARY_CLOUD_NAME || '').trim();
  const apiKey = String(process.env.CLOUDINARY_API_KEY || '').trim();
  const apiSecret = String(process.env.CLOUDINARY_API_SECRET || '').trim();
  if (!cloudName || !apiKey || !apiSecret) throw new Error('Cloudinary credentials are not configured in Netlify.');
  return { cloudName, apiKey, apiSecret };
}

function signParams(params, apiSecret) {
  const serialized = Object.entries(params)
    .filter(([, value]) => value !== undefined && value !== null && value !== '')
    .sort(([a], [b]) => a.localeCompare(b))
    .map(([key, value]) => `${key}=${value}`)
    .join('&');
  return crypto.createHash('sha1').update(`${serialized}${apiSecret}`, 'utf8').digest('hex');
}

function looksLikeAllowedImage(bytes) {
  if (bytes.length >= 3 && bytes[0] === 0xff && bytes[1] === 0xd8 && bytes[2] === 0xff) return 'image/jpeg';
  if (bytes.length >= 8 && bytes[0] === 0x89 && bytes[1] === 0x50 && bytes[2] === 0x4e && bytes[3] === 0x47 && bytes[4] === 0x0d && bytes[5] === 0x0a && bytes[6] === 0x1a && bytes[7] === 0x0a) return 'image/png';
  if (bytes.length >= 12 && bytes.toString('ascii', 0, 4) === 'RIFF' && bytes.toString('ascii', 8, 12) === 'WEBP') return 'image/webp';
  return '';
}

async function readImage(request) {
  const contentType = (request.headers.get('content-type') || '').toLowerCase();
  if (!contentType.includes('multipart/form-data')) throw new Error('يجب إرسال الصورة كملف multipart/form-data.');
  const form = await request.formData();
  const file = form.get('image');
  if (!file || typeof file.arrayBuffer !== 'function') throw new Error('لم تصل الصورة إلى الخادم.');
  if (Number(file.size || 0) <= 0) throw new Error('الصورة فارغة.');
  if (Number(file.size) > 3_300_000) throw new Error('حجم الصورة كبير جداً بعد الضغط. الحد 3.2MB.');
  const bytes = Buffer.from(await file.arrayBuffer());
  const detected = looksLikeAllowedImage(bytes);
  if (!detected) throw new Error('نوع الصورة غير مدعوم. استخدم JPG أو PNG أو WEBP.');
  return { bytes, contentType: detected };
}

function cloudinaryUpload(bytes, contentType, cfg) {
  const timestamp = Math.floor(Date.now() / 1000);
  const folder = 'jotpay/catalog';
  const signature = signParams({ folder, timestamp }, cfg.apiSecret);
  const form = new FormData();
  form.append('file', new Blob([bytes], { type: contentType }), 'jotpay-catalog');
  form.append('api_key', cfg.apiKey);
  form.append('timestamp', String(timestamp));
  form.append('folder', folder);
  form.append('signature', signature);
  return fetch(`https://api.cloudinary.com/v1_1/${encodeURIComponent(cfg.cloudName)}/image/upload`, {
    method: 'POST',
    body: form,
    signal: AbortSignal.timeout(30000),
  });
}

export const config = {
  rateLimit: {
    action: 'rate_limit',
    aggregateBy: 'ip',
    windowSize: 60,
    windowLimit: 20,
  },
};

export default async request => {
  if (request.method === 'GET') {
    const configured = Boolean(
      String(process.env.CLOUDINARY_URL || '').trim()
      || (String(process.env.CLOUDINARY_CLOUD_NAME || '').trim()
        && String(process.env.CLOUDINARY_API_KEY || '').trim()
        && String(process.env.CLOUDINARY_API_SECRET || '').trim())
    );
    return json({ ok: true, configured, authConfigured: Boolean(String(process.env.FIREBASE_SERVICE_ACCOUNT_JSON || '').trim()) });
  }
  if (request.method !== 'POST') return json({ error: 'Method not allowed' }, 405);

  try {
    await requireAdmin(request);
    const cfg = cloudinaryConfig();
    const contentLength = Number(request.headers.get('content-length') || 0);
    if (contentLength && contentLength > 4_400_000) {
      return json({ error: 'حجم الرفع أكبر من الحد المسموح. استخدم صورة أصغر.' }, 413);
    }
    const image = await readImage(request);
    const upstream = await cloudinaryUpload(image.bytes, image.contentType, cfg);
    const body = await upstream.text();
    let data = {};
    try { data = JSON.parse(body); } catch {}
    if (!upstream.ok || !data?.secure_url) {
      const detail = String(data?.error?.message || `HTTP ${upstream.status}`).slice(0, 240);
      return json({ error: `Cloudinary رفض رفع الصورة: ${detail}` }, 502);
    }
    return json({
      ok: true,
      url: data.secure_url,
      secureUrl: data.secure_url,
      publicId: data.public_id || '',
      width: data.width || null,
      height: data.height || null,
      format: data.format || '',
    });
  } catch (error) {
    const message = String(error?.message || 'Upload failed');
    const status = /FIREBASE_SERVICE_ACCOUNT|authorization|Admin access|token/i.test(message)
      ? 401
      : /not configured|invalid|incomplete/i.test(message)
        ? 503
        : /timeout|abort/i.test(message)
          ? 504
          : /size|حجم|نوع الصورة|multipart/i.test(message)
            ? 413
            : 400;
    return json({ error: message }, status);
  }
};
