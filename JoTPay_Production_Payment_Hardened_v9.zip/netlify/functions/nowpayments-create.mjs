import { getApps, initializeApp, cert, applicationDefault } from 'firebase-admin/app';
import { getFirestore, FieldValue } from 'firebase-admin/firestore';
import { getAuth } from 'firebase-admin/auth';
import crypto from 'node:crypto';

function init() {
  if (getApps().length) return getApps()[0];
  const projectId = process.env.FIREBASE_PROJECT_ID || process.env.GOOGLE_CLOUD_PROJECT || process.env.GCLOUD_PROJECT || 'jotpay-4be1e';
  process.env.GOOGLE_CLOUD_PROJECT = projectId;
  process.env.GCLOUD_PROJECT = projectId;
  const raw = process.env.FIREBASE_SERVICE_ACCOUNT_JSON;
  if (raw) {
    const c = JSON.parse(raw);
    if (!c.project_id || !c.client_email || !c.private_key) throw new Error('FIREBASE_SERVICE_ACCOUNT_JSON is missing project_id/client_email/private_key');
    return initializeApp({ credential: cert(c), projectId: c.project_id });
  }
  const clientEmail = process.env.FIREBASE_CLIENT_EMAIL;
  const privateKey = process.env.FIREBASE_PRIVATE_KEY?.replace(/\\n/g, '\n');
  if (clientEmail && privateKey) return initializeApp({ credential: cert({ project_id: projectId, client_email: clientEmail, private_key: privateKey }), projectId });
  return initializeApp({ credential: applicationDefault(), projectId });
}

const db = getFirestore(init());
const API_URL = 'https://api.nowpayments.io/v1/invoice';
const headers = {
  'content-type': 'application/json; charset=utf-8',
  'access-control-allow-origin': '*',
  'access-control-allow-headers': 'authorization,content-type',
  'access-control-allow-methods': 'POST,OPTIONS',
  'cache-control': 'no-store'
};
const out = (status, data) => ({ statusCode: status, headers, body: JSON.stringify(data) });

function siteUrl(event) {
  const configured = String(process.env.PUBLIC_SITE_URL || '').trim().replace(/\/+$/, '');
  if (configured) return configured;
  const host = String(event.headers?.host || '').trim();
  if (!host) throw Object.assign(new Error('PUBLIC_SITE_URL_REQUIRED'), { status: 500 });
  return `https://${host}`;
}

function safeId(value) {
  return String(value || '').replace(/[^A-Za-z0-9_-]/g, '_').slice(0, 100);
}

export async function handler(event) {
  if (event.httpMethod === 'OPTIONS') return out(204, {});
  if (event.httpMethod !== 'POST') return out(405, { ok: false, error: 'METHOD_NOT_ALLOWED' });

  try {
    const apiKey = String(process.env.NOWPAYMENTS_API_KEY || '').trim();
    if (!apiKey) throw Object.assign(new Error('NOWPAYMENTS_NOT_CONFIGURED'), { status: 503 });

    const token = String(event.headers.authorization || '').replace(/^Bearer\s+/i, '');
    if (!token) throw Object.assign(new Error('AUTH_REQUIRED'), { status: 401 });
    const decoded = await getAuth().verifyIdToken(token);
    const body = JSON.parse(event.body || '{}');
    const amount = Number(body.amount);
    const idempotencyKey = String(body.idempotencyKey || '').trim();

    if (!Number.isFinite(amount) || amount < 10 || amount > 100000) {
      throw Object.assign(new Error('TOPUP_AMOUNT_MUST_BE_BETWEEN_10_AND_100000'), { status: 400 });
    }
    if (idempotencyKey.length < 16 || idempotencyKey.length > 128) {
      throw Object.assign(new Error('IDEMPOTENCY_KEY_REQUIRED'), { status: 400 });
    }

    const userRef = db.doc(`users/${decoded.uid}`);
    const idemRef = db.doc(`nowpaymentsIdempotency/${decoded.uid}_${safeId(idempotencyKey)}`);
    const userSnap = await userRef.get();
    if (!userSnap.exists) throw Object.assign(new Error('USER_NOT_FOUND'), { status: 404 });
    const user = userSnap.data() || {};
    if (user.status === 'banned' && (!user.bannedUntil || user.bannedUntil.toMillis() > Date.now())) {
      throw Object.assign(new Error('ACCOUNT_BANNED'), { status: 403 });
    }

    const existing = await idemRef.get();
    if (existing.exists) {
      const d = existing.data() || {};
      if (d.status === 'created' && d.invoiceUrl && d.paymentId) {
        return out(200, { ok: true, replayed: true, paymentId: d.paymentId, invoiceUrl: d.invoiceUrl, amount: d.amount });
      }
      if (d.status === 'pending') throw Object.assign(new Error('PAYMENT_REQUEST_IN_PROGRESS'), { status: 409 });
    }

    const paymentRef = db.collection('nowPayments').doc();
    const orderId = `JOTPAY-${paymentRef.id}`;
    const base = siteUrl(event);
    const callbackUrl = String(process.env.NOWPAYMENTS_IPN_URL || `${base}/api/nowpayments-ipn`).trim();

    await paymentRef.set({
      paymentId: null,
      orderId,
      userId: decoded.uid,
      email: decoded.email || user.email || '',
      amount: Number(amount.toFixed(2)),
      currency: 'USD',
      status: 'pending',
      source: 'nowpayments',
      createdAt: FieldValue.serverTimestamp(),
      updatedAt: FieldValue.serverTimestamp()
    });
    await idemRef.set({
      userId: decoded.uid,
      paymentDocId: paymentRef.id,
      amount: Number(amount.toFixed(2)),
      status: 'pending',
      createdAt: FieldValue.serverTimestamp(),
      updatedAt: FieldValue.serverTimestamp()
    });

    const response = await fetch(API_URL, {
      method: 'POST',
      headers: { 'x-api-key': apiKey, 'content-type': 'application/json' },
      body: JSON.stringify({
        price_amount: Number(amount.toFixed(2)),
        price_currency: 'usd',
        order_id: orderId,
        order_description: `JoTPay wallet top-up ${orderId}`,
        ipn_callback_url: callbackUrl,
        success_url: `${base}/wallet?payment=success&payment_id=${encodeURIComponent(orderId)}`,
        cancel_url: `${base}/wallet?payment=cancelled&payment_id=${encodeURIComponent(orderId)}`
      })
    });

    const data = await response.json().catch(() => ({}));
    if (!response.ok || !data?.invoice_url) {
      await paymentRef.update({ status: 'failed', providerError: String(data?.message || data?.error || `HTTP_${response.status}`).slice(0, 500), updatedAt: FieldValue.serverTimestamp() });
      await idemRef.update({ status: 'failed', updatedAt: FieldValue.serverTimestamp() });
      throw Object.assign(new Error('NOWPAYMENTS_CREATE_FAILED'), { status: 502 });
    }

    await paymentRef.update({
      paymentId: String(data.id || ''),
      invoiceId: String(data.id || ''),
      invoiceUrl: String(data.invoice_url),
      providerStatus: String(data.payment_status || 'waiting'),
      updatedAt: FieldValue.serverTimestamp()
    });
    await idemRef.update({
      status: 'created',
      paymentId: String(data.id || ''),
      invoiceUrl: String(data.invoice_url),
      updatedAt: FieldValue.serverTimestamp()
    });

    return out(200, {
      ok: true,
      paymentId: String(data.id || ''),
      orderId,
      invoiceUrl: String(data.invoice_url),
      amount: Number(amount.toFixed(2))
    });
  } catch (e) {
    return out(e.status || 500, { ok: false, error: e.message || 'NOWPAYMENTS_CREATE_FAILED' });
  }
}
