import { getApps, initializeApp, cert, applicationDefault } from 'firebase-admin/app';
import { getFirestore, FieldValue } from 'firebase-admin/firestore';
import crypto from 'node:crypto';

function init() {
  if (getApps().length) return getApps()[0];
  const projectId = process.env.FIREBASE_PROJECT_ID || process.env.GOOGLE_CLOUD_PROJECT || process.env.GCLOUD_PROJECT || 'jotpay-4be1e';
  process.env.GOOGLE_CLOUD_PROJECT = projectId;
  process.env.GCLOUD_PROJECT = projectId;
  const raw = process.env.FIREBASE_SERVICE_ACCOUNT_JSON;
  if (raw) {
    const c = JSON.parse(raw);
    return initializeApp({ credential: cert(c), projectId: c.project_id });
  }
  const clientEmail = process.env.FIREBASE_CLIENT_EMAIL;
  const privateKey = process.env.FIREBASE_PRIVATE_KEY?.replace(/\\n/g, '\n');
  if (clientEmail && privateKey) return initializeApp({ credential: cert({ project_id: projectId, client_email: clientEmail, private_key: privateKey }), projectId });
  return initializeApp({ credential: applicationDefault(), projectId });
}

const db = getFirestore(init());
const headers = { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store' };
const out = (status, data) => ({ statusCode: status, headers, body: JSON.stringify(data) });

function sortValue(value) {
  if (Array.isArray(value)) return value.map(sortValue);
  if (value && typeof value === 'object') {
    return Object.keys(value).sort().reduce((acc, key) => {
      acc[key] = sortValue(value[key]);
      return acc;
    }, {});
  }
  return value;
}

function signature(payload, secret) {
  return crypto.createHmac('sha512', secret).update(JSON.stringify(sortValue(payload))).digest('hex');
}

function safeEqual(a, b) {
  const aa = Buffer.from(String(a || ''), 'utf8');
  const bb = Buffer.from(String(b || ''), 'utf8');
  return aa.length === bb.length && crypto.timingSafeEqual(aa, bb);
}

export async function handler(event) {
  if (event.httpMethod !== 'POST') return out(405, { ok: false, error: 'METHOD_NOT_ALLOWED' });
  try {
    const secret = String(process.env.NOWPAYMENTS_IPN_SECRET || '');
    if (!secret) throw Object.assign(new Error('NOWPAYMENTS_IPN_NOT_CONFIGURED'), { status: 503 });

    const received = String(event.headers?.['x-nowpayments-sig'] || event.headers?.['X-Nowpayments-Sig'] || '');
    const payload = JSON.parse(event.body || '{}');
    if (!received || !safeEqual(received, signature(payload, secret))) {
      return out(401, { ok: false, error: 'INVALID_IPN_SIGNATURE' });
    }

    const orderId = String(payload.order_id || '').trim();
    const providerPaymentId = String(payload.payment_id || payload.id || '').trim();
    const providerStatus = String(payload.payment_status || '').toLowerCase().trim();
    if (!orderId || !providerPaymentId) return out(400, { ok: false, error: 'INVALID_IPN_PAYLOAD' });

    const query = await db.collection('nowPayments').where('orderId', '==', orderId).limit(1).get();
    if (query.empty) return out(404, { ok: false, error: 'PAYMENT_NOT_FOUND' });
    const paymentRef = query.docs[0].ref;

    let result = 'updated';
    await db.runTransaction(async tx => {
      const snap = await tx.get(paymentRef);
      if (!snap.exists) throw Object.assign(new Error('PAYMENT_NOT_FOUND'), { status: 404 });
      const payment = snap.data() || {};
      const update = {
        paymentId: providerPaymentId,
        providerStatus,
        lastIPNAt: FieldValue.serverTimestamp(),
        updatedAt: FieldValue.serverTimestamp()
      };

      if (payment.creditedAt || payment.status === 'credited') {
        tx.update(paymentRef, update);
        result = 'already_credited';
        return;
      }

      const terminalSuccess = providerStatus === 'finished';
      const terminalFailure = ['failed', 'expired', 'refunded'].includes(providerStatus);

      if (!terminalSuccess) {
        update.status = terminalFailure ? providerStatus : 'pending';
        tx.update(paymentRef, update);
        result = 'status_updated';
        return;
      }

      const userRef = db.doc(`users/${payment.userId}`);
      const userSnap = await tx.get(userRef);
      if (!userSnap.exists) throw Object.assign(new Error('USER_NOT_FOUND'), { status: 404 });
      const user = userSnap.data() || {};
      const balanceBefore = Number(user.walletBalance || 0);
      const amount = Number(payment.amount || 0);
      if (!Number.isFinite(amount) || amount <= 0) throw Object.assign(new Error('INVALID_PAYMENT_AMOUNT'), { status: 500 });
      const balanceAfter = Number((balanceBefore + amount).toFixed(2));

      tx.update(userRef, { walletBalance: balanceAfter, updatedAt: FieldValue.serverTimestamp() });
      tx.update(paymentRef, {
        ...update,
        status: 'credited',
        creditedAmount: amount,
        creditedAt: FieldValue.serverTimestamp()
      });
      tx.create(db.collection('walletLedger').doc(), {
        userId: payment.userId,
        type: 'deposit',
        method: 'NOWPayments',
        amount,
        currency: 'USD',
        balanceBefore,
        balanceAfter,
        paymentId: providerPaymentId,
        depositId: paymentRef.id,
        createdAt: FieldValue.serverTimestamp()
      });
      result = 'credited';
    });

    return out(200, { ok: true, result });
  } catch (e) {
    return out(e.status || 500, { ok: false, error: e.message || 'IPN_FAILED' });
  }
}
