import { getApps, initializeApp, cert, applicationDefault } from 'firebase-admin/app';
import { getFirestore } from 'firebase-admin/firestore';

const CACHE = 'public, max-age=30, stale-while-revalidate=120';

function init() {
  if (getApps().length) return getApps()[0];
  const projectId = process.env.FIREBASE_PROJECT_ID || process.env.GOOGLE_CLOUD_PROJECT || process.env.GCLOUD_PROJECT || 'jotpay-4be1e';
  const raw = process.env.FIREBASE_SERVICE_ACCOUNT_JSON;
  if (raw) {
    const c = JSON.parse(raw);
    return initializeApp({ credential: cert(c), projectId: c.project_id || projectId }, 'jotpay-public-catalog');
  }
  const clientEmail = process.env.FIREBASE_CLIENT_EMAIL;
  const privateKey = process.env.FIREBASE_PRIVATE_KEY?.replace(/\\n/g, '\n');
  if (clientEmail && privateKey) {
    return initializeApp({ credential: cert({ project_id: projectId, client_email: clientEmail, private_key: privateKey }), projectId }, 'jotpay-public-catalog');
  }
  return initializeApp({ credential: applicationDefault(), projectId }, 'jotpay-public-catalog');
}

const db = getFirestore(init());

function json(data, status = 200) {
  return {
    statusCode: status,
    headers: {
      'content-type': 'application/json; charset=utf-8',
      'cache-control': CACHE,
      'access-control-allow-origin': '*',
      'access-control-allow-methods': 'GET,OPTIONS',
      'access-control-allow-headers': 'content-type',
    },
    body: JSON.stringify(data),
  };
}

function clean(value) {
  if (value?.toDate) return value.toDate().toISOString();
  if (Array.isArray(value)) return value.map(clean);
  if (value && typeof value === 'object') {
    const out = {};
    for (const [key, item] of Object.entries(value)) out[key] = clean(item);
    return out;
  }
  return value;
}


function publicCategory(c) {
  return {
    id: String(c.id || ''),
    name: String(c.name || ''),
    type: String(c.type || ''),
    parentId: String(c.parentId || ''),
    sortOrder: Number(c.sortOrder ?? 9999),
    active: c.active === true,
  };
}

function publicProduct(p) {
  const out = {
    id: String(p.id || ''),
    name: String(p.name || ''),
    description: String(p.description || ''),
    image: String(p.image || ''),
    price: Number(p.price || 0),
    currency: String(p.currency || '$') === 'USD' ? '$' : String(p.currency || '$'),
    active: p.active === true,
    featured: p.featured === true,
    popularity: Number(p.popularity || 0),
    rating: Number(p.rating || 0),
    sortOrder: Number(p.sortOrder ?? 9999),
    sectionId: String(p.sectionId || ''),
    categoryId: String(p.categoryId || ''),
    platform: String(p.platform || ''),
    unitLabel: String(p.unitLabel || ''),
    inputType: String(p.inputType || ''),
  };
  if (Array.isArray(p.topupPackages)) {
    out.topupPackages = p.topupPackages
      .filter(x => x && x.active !== false)
      .slice(0, 7)
      .map(x => ({
        id: String(x.id ?? x.price ?? ''),
        price: Number(x.price || 0),
        baseQuantity: Number(x.baseQuantity ?? x.quantity ?? 0),
        bonusPercent: Number(x.bonusPercent || 0),
        active: x.active !== false,
      }));
  }
  return out;
}

function publicBanner(b) {
  return {
    id: String(b.id || ''),
    title: String(b.title || ''),
    description: String(b.description || ''),
    image: String(b.image || ''),
    link: String(b.link || ''),
    cta: String(b.cta || ''),
    sortOrder: Number(b.sortOrder ?? 9999),
    active: b.active === true,
    translations: b.translations && typeof b.translations === 'object' ? clean(b.translations) : {},
  };
}

async function activeDocs(name, max = 200) {
  const snap = await db.collection(name).where('active', '==', true).limit(max).get();
  return snap.docs.map(d => ({ id: d.id, ...clean(d.data()) }));
}

export async function handler(event) {
  if (event.httpMethod === 'OPTIONS') return json({}, 204);
  if (event.httpMethod !== 'GET') return json({ ok: false, error: 'METHOD_NOT_ALLOWED' }, 405);
  try {
    const [categories, products, banners] = await Promise.all([
      activeDocs('categories', 300),
      activeDocs('products', 300),
      activeDocs('banners', 100),
    ]);

    const publicCategories = categories
      .filter(c => ['primary', 'secondary'].includes(String(c.type || '')))
      .map(publicCategory);
    const publicProducts = products
      .filter(p => String(p.sectionId || '') && (String(p.categoryId || '') || String(p.sectionId || '')))
      .map(publicProduct);

    publicCategories.sort((a, b) => Number(a.sortOrder ?? 9999) - Number(b.sortOrder ?? 9999));
    publicProducts.sort((a, b) =>
      Number(Boolean(b.featured)) - Number(Boolean(a.featured)) ||
      Number(b.popularity || 0) - Number(a.popularity || 0) ||
      Number(a.sortOrder ?? 9999) - Number(b.sortOrder ?? 9999)
    );
    const publicBanners = banners.map(publicBanner);
    publicBanners.sort((a, b) => Number(a.sortOrder ?? 9999) - Number(b.sortOrder ?? 9999));

    return json({ ok: true, categories: publicCategories, products: publicProducts, banners: publicBanners });
  } catch (error) {
    return json({ ok: false, error: 'PUBLIC_CATALOG_UNAVAILABLE' }, 503);
  }
}
